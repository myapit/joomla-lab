<?php
/**
* @version 1.0 $
* @package HelloWorld
* @copyright (C) 2005 Andrew Eddie
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
 
/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or
    die( 'Direct Access to this location is not allowed.' );
 
// COLLECT DATA
 
// assemble query
global $mosConfig_offset;
 
$now = date( 'Y-m-d H:i:s', time() + $mosConfig_offset * 3600 );
 
// Retreive parameters
 
$count = intval( $params->get( 'count', 10 ) );
$ordering = $params->get( 'ordering', 'hits' );
$skin = $params->get( 'skin', 'default' );
 
// Assign ordering
 
switch ($ordering) {
  case 'title':
    $orderBy = 'title ASC';
    break;
  case 'hits':
  default:
    $orderBy = 'hits DESC';
    break;
}
 
$query = '
  SELECT id, title, hits
  FROM #__content
  WHERE ( state = \'1\' AND checked_out = \'0\' )
    AND ( publish_up = \'0000-00-00 00:00:00\' OR publish_up <= \''
                . $now . '\' )
    AND ( publish_down = \'0000-00-00 00:00:00\' OR publish_down >= \''
                . $now . '\' )
      AND access <= \'' . $my->gid .'\'
  ORDER BY ' . $orderBy . '
  LIMIT ' . $count
;
 
// prepare the query in the database connector
$database->setQuery( $query );
 
// retrieve the rows as objects
$rows = $database->loadObjectList();
 
// DISPLAY DATA
 
// load the patTemplate library
require_once( $mosConfig_absolute_path . '/includes/patTemplate/patTemplate.php' );
 
// create the template
$tmpl =&amp; patFactory::createTemplate( '', false, false );
 
// set the path to look for html files
$tmpl->setRoot( dirname( __FILE__ ) . '/mod_helloworld' );
 
// load the template based on the selected skin
$tmpl->readTemplatesFromInput( $skin . '.html' );
 
// add the 'rows' to the rows template with a prefix
$tmpl->addObject( 'rows', $rows, 'row_' );
 
// output the template
$tmpl->displayParsedTemplate( 'helloworld' );
?>
