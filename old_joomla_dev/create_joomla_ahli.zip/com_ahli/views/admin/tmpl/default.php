<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>


		  <form name="senarai_ahli" method="POST" action="index.php?option=com_ahli&view=admin">

<p style="line-height: 150%"><font face="Verdana" size="2"><b>KEAHLIAN</b></font></p>
          <table border="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%" colspan="2">
                <font face="Verdana" size="2">Keahlian dibuka kepada bukan sahaja ahli-ahli yang telah
bersara secara wajib atau pilihan tetapi juga kepada mereka yang pernah
berkhidmat dengan Universiti Sains Malaysia</font>

              </td>
            </tr>
            <tr>
              <td width="49%">
              <font size="2" face="Arial">
              Jumlah ahli setakat ini  :<b><font color="#0000FF"> <?php echo $this->total; ?></font></b> orang</font>

              </td>
              <td width="51%">

                  <p style="line-height: 150%" align="right"><input type="text" name="carian" size="20"><input type="submit" value="Cari" name="B1"></p>
    
              </td>
            </tr>
            <tr>

            <center>
              <td width="100%" colspan="2">
                <div align="center">
                  <table border="0" cellpadding="2" cellspacing="0" width="100%" style="border-collapse: collapse" bordercolor="#111111" height="1">
                    <tr>
                      <td width="100%" style="border-top-style: none; border-top-width: medium" height="22">
                        <div align="center">
                        <table border="0" cellpadding="2" cellspacing="1" width="100%" style="border-top-width: 0; border-bottom-width: 0">
                             <tr>

                            <td width="5%" valign="top" style="border-style: solid; border-width: 1">
                              <b><font face="Verdana" size="2">Bil.</font></b></td>
								<td valign="top" style="border-style: solid; border-width: 1">
								<b><font face="Verdana" size="2">Nama Ahli</font></b></td>
								<td valign="top" style="border-style: solid; border-width: 1">
								<b><font face="Verdana" size="2">No KP</font></b></td>
								<td valign="top" style="border-style: solid; border-width: 1">
								<b><font face="Verdana" size="2"></font></b></td>
								<td valign="top" style="border-style: solid; border-width: 1">
								<b><font face="Verdana" size="2"></font></b></td>
                            </tr>
                            
							<?php
							$j=1;
							foreach($this->items as $item) {
							?>
                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2"><?php echo $this->pagination->getRowOffset($j-1); ?></font></td>

								<td valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="index.php?option=com_ahli&id=<?php echo $item->id; ?>" style="text-decoration: none"><?php echo $item->nama; ?></a></font></td>
								<td valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="index.php?option=com_ahli&id=<?php echo $item->id; ?>" style="text-decoration: none"><?php echo $item->nokp; ?></a></font></td>
								<td  valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="index.php?option=com_ahli&view=admin&layout=kemaskini&id=<?php echo $item->id; ?>" style="text-decoration: none">Kemaskini</a></font></td>
								<td valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="index.php?option=com_ahli&id=<?php echo $item->id; ?>" style="text-decoration: none">Padam</a></font></td>
                            </tr>
							<?php
							$j++;
							} 
							?>
							
                            

                          </table>
                        </div>
                      </center>
                      </td>

                    </tr>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <td width="100%" colspan="2">
          <table border="0" cellspacing="0" width="100%">
            <tr>

              <td width="52%">
        
              </td>
              <td width="32%">

            </center>
              </td>

              <td width="16%">

        

            <center>
            



              </td>
            </tr>
          </table>
              </td>
            </tr>
          </table>
            </td>
          </tr>

          
        </table>
	

<tfoot>
    <tr>
      <td colspan="9"><?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
  </tfoot>
  </form>