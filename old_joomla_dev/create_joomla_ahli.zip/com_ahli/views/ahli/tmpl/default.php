<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php 
$no_ahli = $this->item->noahli;
$nama_ahli =  $this->item->nama;
$alamat =  $this->item->alamat;
$poskod =  $this->item->poskos;
$fax =  $this->item->fax;
$telefon =  $this->item->tel;
$email = $this->item->email;
	if( $this->item->gambar!=""){
		$fail_gambar =  $this->item->gambar; 
	}else{
		$fail_gambar = "no_photo1.jpg"; 
	}
?>


<table border="0" width="100%" id="table1">
	<tr>
		<td width="118" rowspan="7" align="center" valign="top">
		
							
		
		</td>
		<td><font face="Arial" size="2"><img src="images/stories/ahli/<?php echo $fail_gambar; ?>" align="center">	 No.Ahli : <?php echo $no_ahli;  ?>       <br><br><b><?php echo $nama_ahli;  ?> </b></font></td>
	</tr>
	<tr>

		<td><font face="Arial" size="2"><?php echo $alamat;  ?> <br><?php echo $poskod;  ?> </font></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td><font face="Arial" size="2">No. Tel:</font></td>

	</tr>
	<tr>
		<td><font face="Arial" size="2">No. Tel. Bimbit: <?php echo $telefon;  ?> </font></td>
	</tr>
	<tr>
		<td><font face="Arial" size="2">Emel:<?php echo $email;  ?> </font></td>
	</tr>
	<tr>

		<td><font face="Arial" size="2">No. Faks: <?php echo $fax;  ?> </font></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
</table>