<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://dev.joomla.org/component/option,com_jd-wiki/Itemid,31/id,tutorials:components/
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the HelloWorld Component
 *
 * @package		Joomla.Tutorials
 * @subpackage	Components
 */
class AhliViewSenarai extends JView
{
	function display($tpl = null)
	{
	

		// Get data from the model
	 	$items =& $this->get('Data');
	 	$pagination =& $this->get('Pagination');
		$total =& $this->get('Total');
		
		// push data into the template
		$this->assignRef('items', $items);	
		$this->assignRef('pagination', $pagination);
		$this->assignRef('total', $total);


		parent::display($tpl);
	}
}
?>
