<?php
/**
 * Hello World default controller
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://dev.joomla.org/component/option,com_jd-wiki/Itemid,31/id,tutorials:components/
 * @license		GNU/GPL
 */

jimport('joomla.application.component.controller');

/**
 * Hello World Component Controller
 *
 * @package		HelloWorld
 */
class AhliController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}
	
	function save()
	{
		$model = $this->getModel('ahli');
 
		if ($model->store()) {		
			$msg = JText::_( 'Pendaftaran berjaya!' );
			// Check the table in so it can be edited.... we are done with it anyway
			$link = 'index.php?option=com_ahli&view=cetak';
			$this->setRedirect($link, $msg);
		} else {
			$msg = JText::_( 'Pendaftaran tidak berjaya. Sila hubungi pihak Kelab Jasa Budi.' );
		}
	 
		// Check the table in so it can be edited.... we are done with it anyway
		//$link = 'index.php?option=com_ahli&view=cetak';
		//$this->setRedirect($link, $msg);
	}
	
	function cetak()
	{
			parent::display();
	}
	
	function sah()
	{
		/*
		$model = $this->getModel('admin');
		$model->store()
		$msg = JText::_( 'Pengesahan Permohonan' );
		$link = 'index.php?option=com_ahli&view=admin&layout=sahsenarai';
		$this->setRedirect($link, $msg);
		*/
	}
}
?>
