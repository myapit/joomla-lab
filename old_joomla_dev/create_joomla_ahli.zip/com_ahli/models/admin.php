<?php
/**
 * Hello Model for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://dev.joomla.org/component/option,com_jd-wiki/Itemid,31/id,tutorials:components/
 * @license		GNU/GPL
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');


/**
 * Hello Model
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class AhliModelAdmin extends JModel
{
	
	/**
   * Items total
   * @var integer
   */
  var $_total = null;
  var $_dataAhli = null;
 
  /**
   * Pagination object
   * @var object
   */
  var $_pagination = null;
  
  function __construct()
  {
   	parent::__construct();
 
	$mainframe = JFactory::getApplication();
 
	// Get pagination request variables
	$limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
	$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
 
	// In case limit has been changed, adjust it
	$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

	$this->setState('limit', $limit);
	$this->setState('limitstart', $limitstart);
  }
  
  /**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery($filter)
	{
	
		$carian = JRequest::getVar('carian', '', 'post');
		if($carian==" "){
			$query = " SELECT * "
			. " FROM #__ahli WHERE status='1' ORDER BY nama";
		}else{
		$query = " SELECT * "
			. " FROM #__ahli"
			. " WHERE nama  like '%". $carian ."%'"
			. " AND status='1'  ORDER BY nama";
		}
		
		if($filter="senaraisah"){
			$query = " SELECT * "
			. " FROM #__ahli WHERE status IS NULL ORDER BY nama";
		}
		
		return $query;
	}
  
  function getData() 
  {
   	// if data hasn't already been obtained, load it
 	if (empty($this->_data)) {
 	    $query = $this->_buildQuery("senarai");
 	    $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));	
 	}
 	return $this->_data;
  }
  
  function getMaklumatAhli() 
  {	
		// Lets load the data if it doesn't already exist
        if (empty( $this->_dataAhli ))
        {
			$reqId = JRequest::getVar('id', '', 'get');			
			$row =& $this->getTable('Ahli');
			$row->load($reqId);
			$this->_dataAhli = $row;	
        }		
        return $this->_dataAhli;
	}
	
	
   function getSenaraiPermohonan() 
  {	
		// Lets load the data if it doesn't already exist
        // if data hasn't already been obtained, load it
		if (empty($this->_data)) {
			$query = $this->_buildQuery("senaraisah");
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));	
		}
		return $this->_data;
		}
  
  function getTotal()
  {
 	// Load the content if it doesn't already exist
 	if (empty($this->_total)) {
 	    $query = $this->_buildQuery("");
 	    $this->_total = $this->_getListCount($query);	
 	}
 	return $this->_total;
  }
  
    function getPagination()
  {
 	// Load the content if it doesn't already exist
 	if (empty($this->_pagination)) {
 	    jimport('joomla.html.pagination');
 	    $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
 	}
 	return $this->_pagination;
  }
}
