<?php
/**
 * Hello World table class
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Hello Table class
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class TableAhli extends JTable
{
	var $id = null;
	var $nama = null;
	var $alamat = null;
	var $nokp = null;
	var $jantina = null;
	var $trkh_lahir = null;
	var $tmpt_lahir = null;
	var $warganegara = null;
	var $poskod = null;
	var $hp = null;
	var $tel = null;
	var $fax = null;
	var $email = null;
	var $jawatanlps = null;
	var $jabatan = null;
	var $trkh_bersara = null;
	var $jawatanskrg = null;
	var $pejabat = null;
	var $poskodpej = null;
	var $telpej = null;
	var $faxpej = null;
	var $emailpej = null;
	var $byrn = null;
	var $nocek = null;
	var $gambar = null;
	var $trkh_rekod = null;
	var $status = null;
	var $gelaran = null;
	var $kepakaran = null;
	var $pasangan = null;
	var $nokp_psgn = null;
	var $noahli = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableAhli(& $db) {
		parent::__construct('#__ahli', 'id', $db);
	}
}