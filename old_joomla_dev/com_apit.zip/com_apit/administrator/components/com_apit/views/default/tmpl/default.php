<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('apit'), 'generic.png');
JToolBarHelper::preferences('com_apit');
?>
<!-- Deafult administrator message -->
This is the default administrator view of your component. To edit it please edit the file:<br />
/administrator/components/com_apit/views/default/tmpl/default.php