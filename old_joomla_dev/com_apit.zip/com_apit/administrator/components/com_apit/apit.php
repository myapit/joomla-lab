<?php
/**
 * Joomla! 1.5 component apit
 *
 * @version $Id: apit.php 2010-04-12 01:21:26 svn $
 * @author apit la sapa lagi
 * @package Joomla
 * @subpackage apit
 * @license Copyright (c) 2010 - All Rights Reserved
 *
 * apit punya component
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Define constants for all pages
 */
define( 'COM_APIT_DIR', 'images'.DS.'apit'.DS );
define( 'COM_APIT_BASE', JPATH_ROOT.DS.COM_APIT_DIR );
define( 'COM_APIT_BASEURL', JURI::root().str_replace( DS, '/', COM_APIT_DIR ));

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';

// Require the base controller
require_once JPATH_COMPONENT.DS.'helpers'.DS.'helper.php';

// Initialize the controller
$controller = new ApitController( );

// Perform the Request task
$controller->execute( JRequest::getCmd('task'));
$controller->redirect();
?>