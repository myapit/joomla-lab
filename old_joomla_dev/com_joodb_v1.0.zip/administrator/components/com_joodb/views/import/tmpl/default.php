<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<link href="templates/khepri/css/icon.css" rel="stylesheet" type="text/css" />
<link href="templates/khepri/css/rounded.css" rel="stylesheet" type="text/css" />
<div id="content-box" style="border: 1px solid #ccc; height: 300px;">
<div class="border">
<div class="padding">
<div id="toolbar-box">
	<div class="t">
		<div class="t">
			<div class="t" ></div>
		</div>
	</div>
	<div class="m">
		<div id="toolbar" class="toolbar">
			<table class="toolbar"><tbody><tr>
				<td id="toolbar-next" class="button">
					<a class="toolbar" onclick="javascript:doCheckout()" href="#">
						<span title="Next" class="icon-32-forward"></span><?php echo JText::_( "Continue" ); ?>
					</a>
				</td>
			</tr></tbody></table>
		</div>
		<div class="header icon-48-cpanel"><?php echo JText::_( "Not ready" ); ?></div>
		<div class="clr" ></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
<div id="element-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
	<div class="m" style="font-size: larger; font-weight: bolder; height: 180px;">
	Import is not implemented yet!
	<br/>
	<div class="clr"></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
</div>

</div>
</div>
<script type="text/javascript" language="JavaScript">
	function doCheckout() {
		document.adminForm.submit();
	}
</script>

