<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// no direct access
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

// edit or add a custom entry from a table
class JoodbViewAddmenuItem extends JView {

	function display($tpl = null) {
		$db			=& JFactory::getDBO();

		$cid	= JRequest::getVar( 'cid', array(), '', 'array' );
		$targetmenu	= JRequest::getVar( 'targetmenu');
		JArrayHelper::toInteger( $cid );
		$id = $cid[0];
		$jb =& JTable::getInstance( 'joodb', 'Table' );
		$jb->load( $joodbid );
		$jb->load( $id );

		if (!$targetmenu) { // display menu selector
		$query = 'SELECT menutype AS value, title AS text FROM `#__menu_types`';
		$menu[] = JHTML::_('select.option',  '0', '- '. JText::_( 'Select Menu' ) .' -' );
		$db->setQuery( $query );
		$menu = array_merge( $menu, $db->loadObjectList() );
		$menuselect	= JHTML::_('select.genericlist',  $menu, 'targetmenu', 'class="inputbox" size="1"' , 'value', 'text', $targetmenu);

		?>
		<form action="index3.php" method="post" name="adminForm">
			<fieldset>
				<legend><?php echo JText::_( 'Choose menu' ); ?> <b><?php echo $jb->name; ?></b></legend>
				<div style="float:left">
						<?php echo $menuselect; ?>
					<input type="submit" value="<?php echo JText::_( 'Go' ); ?>" class="button" />
					<input type="hidden" name="option" value="com_joodb" />
					<input type="hidden" name="cid" value="<?php echo $id; ?>" />
					<input type="hidden" name="view" value="AddmenuItem" />
				</div>
			</fieldset>
		</form>
	<?php } else { // add menu item

			$query = "SELECT id FROM #__components WHERE link = 'option=com_joodb'";
			$db->setQuery( $query );
			$comid = $db->loadResult();

			$query = "INSERT INTO `#__menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`,`ordering`, `params`) ";
			$query .= " VALUES ( NULL,'".$targetmenu."','".ucfirst($jb->name)."', '".JFilterOutput::stringURLSafe($jb->name)."','index.php?option=com_joodb&view=catalog','component','1','0','".$comid."','666','joobase=".$jb->id."\nlink_titles=1\norderby=ftitle\nordering=ASC\nlimit=5\n');";
			$db->setQuery( $query );
		    if (!$db->query()) {
		      echo "<script> alert('".$db->getErrorMsg()."'); window.history.go(-1); </script>\n";
		    }
			?>
			<fieldset>
				<legend><?php echo JText::_( 'Entry created' ); ?></legend>
				<div style="float:left"><?php echo JText::_( 'New entry created' ); ?></div>
			</fieldset>
		<?php
		}
	}

}