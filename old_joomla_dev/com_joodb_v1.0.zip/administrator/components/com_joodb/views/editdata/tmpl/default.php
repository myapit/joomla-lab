<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

$item = $this->item;
$jb = $this->joobase;

?>
<style>
	.invalid { background-color: #F9C4C0; }
</style>

<form action="index.php" method="post" name="adminForm" id="adminForm"  class="form-validate" enctype="multipart/form-data">
	<input type="hidden" name="option" value="com_joodb" />
	<input type="hidden" name="joodbid" value="<?php echo $jb->id; ?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="<?php echo $jb->fid; ?>" value="<?php echo $item->{$jb->fid} ?>" />
	<fieldset class="adminform">
		<legend><?php echo JText::_( "Editable fields" ); ?></legend>
		<table cellspacing="1" width="100%" class="paramlist admintable">
<?php
	$supported = array ("varchar"=>"yes","char"=>"yes","int"=>"yes","tinyint"=>"yes","smallint"=>"yes","mediumint"=>"yes","bigint"=>"yes","enum"=>"yes","set"=>"yes"
						,"text"=>"yes","tinytext"=>"yes","mediumtext"=>"yes","longtext"=>"yes","date"=>"yes","datetime"=>"yes","timestamp"=>"yes","year"=>"yes");

	foreach ($jb->fields as $fname=>$fcell) {
		$typearr = split("\(",$fcell->Type);
		$typevals = array();
		$required = ($fcell->Null=="NO") ? "required" :"";
		if (isset($typearr[1])) { $typevals =  split("','",trim($typearr[1],"')"));	}
		// get default value
		if (($this->id==0) && ($fcell->Default!=NULL)) { $item->{$fname} = $fcell->Default; }
		if (isset($supported[$typearr[0]]) && $fname!=$jb->fid) {
			echo '<tr><td width="200" class="paramlist_key">'.ucfirst($fname).'</td><td class="paramlist_value">';
			switch ($typearr[0]) {
				case 'varchar' :
				case 'char' :
				case 'tinytext' :
					echo '<input class="inputbox '.$required.'" type="text" name="'.$fname.'" value="'.str_replace("\'","\"",$item->{$fname}).'" maxlength="'.$typevals[0].'" size="80" style="width: '.(($typevals[0]<30) ? '300px' : '600px').'" />';
				break;
				case 'int' :
				case 'tinyint' :
				case 'smallint' :
				case 'mediumint' :
				case 'bigint' :
					echo '<input class="inputbox '.$required.'" type="text" name="'.$fname.'" value="'.str_replace("\'","\"",$item->{$fname}).'" maxlength="60" size="60" style="width: 200px" />';
				break;
				case 'tinyint' :
					echo '<input class="inputbox '.$required.'" type="text" name="'.$fname.'" value="'.str_replace("\'","\"",$item->{$fname}).'" maxlength="4" size="4" style="width: 50px" />';
				break;
				case 'datetime' :
				case 'timestamp' :
					echo JHTML::_('calendar', $item->{$fname} , $fname, $fname, '%Y-%m-%d %H:%M:%S', array('class'=>'inputbox', 'size'=>'25',  'maxlength'=>'19'));
					break;
				case 'date' :
					echo JHTML::_('calendar', $item->{$fname} , $fname, $fname, '%Y-%m-%d', array('class'=>'inputbox', 'size'=>'25',  'maxlength'=>'10'));
				break;
				case 'year' :
					echo '<input class="inputbox '.$required.'" type="text" name="'.$fname.'" value="'.str_replace("\'","\"",$item->{$fname}).'" maxlength="4" size="4" style="width: 50px" />';
				break;
				case 'text' :
				case 'tinyint' :
				case 'tinytext' :
				case 'mediumtext' :
				case 'longtext' :
					echo '<textarea class="'.$required.'" cols="80" rows="6" name="'.$fname.'" style="width: 600px">'.stripslashes($item->{$fname}).'</textarea>';
				break;
				// special handling for enum and set
				case 'enum' :
					echo '<select class="inputbox '.$required.'" type="text" name="'.$fname.'" style="width: 200px" />';
					echo '<option value="" >...</option>';
					foreach ($typevals as $value) {
						echo '<option value="'.$value.'" '.(($value==$item->{$fname}) ? 'selected' : '' ).'>'.$value.'</option>';
					}
					echo '</select>';
				break;
				case 'set' :
					echo '<select class="inputbox '.$required.'" type="text" multiple="multiple" name="'.$fname.'[]" style="width: 200px" />';
					$setarray = split(",",$item->{$fname});
					foreach ($typevals as $value) {
						echo '<option value="'.$value.'" '.(in_array($value,$setarray)? 'selected' : '' ).'>'.$value.'</option>';
					}
					echo '</select>';
				break;
			}
			echo '</td></tr>';
		}
	}
?>
		</table>
	</fieldset>
</form>
<script language="JavaScript">


	function submitbutton(pressbutton)
		{
			var form = document.adminForm;

			if (pressbutton == 'listdata') {
				submitform( pressbutton );
				return true;
			}

			// do field validation
			if (form.<?php echo $jb->ftitle; ?>.value == ""){
				alert('<?php echo JText::_( "Must have title" ); ?>');
				form.<?php echo $jb->ftitle; ?>.focus();
				return false;
			} else  {
		        if (document.formvalidator.isValid(form)) {
					submitform( pressbutton );
					return true;
	      		  } else {
	                alert('<?php echo JText::_( "Fillout required fields" ); ?>');
	       		 }
			}
		}

</script>
