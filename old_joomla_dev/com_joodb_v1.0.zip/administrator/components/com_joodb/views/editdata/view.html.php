<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// no direct access
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

// edit or add a custom entry from a table
class JoodbViewEditdata extends JView
{
	function display($tpl = null)
	{
		$db	=& JFactory::getDBO();
		JRequest::setVar( 'hidemainmenu', 1 );

		$cid = JRequest::getVar( 'cid', array(), '', 'array' );
		JArrayHelper::toInteger( $cid );
		$id = $cid[0];

		// load the jooDb object with table fiel infos
		$joodbid	= JRequest::getCmd( 'joodbid', int );
		$jb =& JTable::getInstance( 'joodb', 'Table' );
		$jb->load( $joodbid );
		$fields = $db->getTableFields($jb->table,false);
		$jb->fields = $fields[$jb->table];


		$text = ( $id ? JText::_( 'Edit' ) : JText::_( 'New' ) );
		JToolBarHelper::title(   $jb->name.': <small><small>['.$text.']</small></small>','joodb.png' );
		JToolBarHelper::save('savedata');
		JToolBarHelper::apply('applydata');
		JToolBarHelper::cancel('listdata');

		$db->setQuery("SELECT * FROM ".$jb->table." WHERE ".$jb->fid."=".$id,0,1);
		$item = $db->loadObject();

		$this->assignRef('joobase', $jb);
		$this->assignRef('item',$item);
		$this->assignRef('id',$id);
		// Load the form validation behavior
		JHTML::_('behavior.formvalidation');

		parent::display($tpl);
	}

}