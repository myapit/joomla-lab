<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// no direct access
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

class JoodbViewJoodbentry extends JView
{
	function display($tpl = null)
	{
		$db	=& JFactory::getDBO();

		$layout	= JRequest::getCmd('layout');
		if ($layout=="step1") {
			$this->assignRef('tables',$db->getTableList());
		} else if ($layout=="step2") {
			$table = JRequest::getVar('table');
			$this->assignRef('table',$table);
			$this->dbname =JRequest::getVar('dbname');
			$this->assignRef('fields', $db->getTableFields($table));
		} else if ($layout=="step3") {
			// Add new entry
			$db =& JFactory::getDBO();
			$post = JRequest::get( 'post' );
			$row =& JTable::getInstance('joodb', 'Table');
			if (!$row->save( $post )) {
				return JError::raiseWarning( 500, $row->getError() );
			}
		} else {
			$cid	= JRequest::getVar( 'cid', array(), '', 'array' );
			JArrayHelper::toInteger( $cid );
			$id = $cid[0];

			$text = ( $id ? JText::_( 'Edit' ) : JText::_( 'New' ) );
			JToolBarHelper::title(   JText::_( "JooDatabase" ).': <small><small>['.$text.']</small></small>','joodb.png' );
			JToolBarHelper::save();
			JToolBarHelper::apply();
			JToolBarHelper::cancel();
			$bar = & JToolBar::getInstance('toolbar');
			$bar->appendButton( 'Popup', 'help','Help', 'http://joodb.feenders.de', "980", "600" );

			$row =& JTable::getInstance( 'joodb', 'Table' );
			$row->load( $id );
			$this->assignRef('tables',$db->getTableList());
			$this->assignRef('fields', $db->getTableFields($row->table));
			$this->assignRef('item',$row);

			// activate tabswitcher
			$templatePath = JPATH_COMPONENT.DS.'tmpl'.DS;

			// Import javascript for tooltips
			JHTML::_('behavior.tooltip');

			// Import javascript for tab-switch support
			JHTML::_('behavior.switcher');

			// Load the sub-menu navigation template into the document
			ob_start();
			require JPATH_COMPONENT.DS.'views'.DS.'joodbentry'.DS.'tmpl'.DS.'navigation.php';
			$navigation = ob_get_contents();
			ob_end_clean();
			$document =& JFactory::getDocument();
			$document->setBuffer($navigation, 'modules', 'submenu');

		}
		parent::display($tpl);
	}

}