<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

$item = $this->item;
$fields =$this->fields[$item->table];
// 	Load the JEditor object
$editor =& JFactory::getEditor();

?>

<form action="index.php" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
	<input type="hidden" name="option" value="com_joodb" />
	<input	type="hidden" name="task" value="save" />
	<input type="hidden" name="operation" value=<?php echo ($item->id == null ? "'add'" : "'save'") ?> />
	<input type="hidden" name="view" value="joodb" />
	<input type="hidden" name="id" value="<?php echo $item->id; ?>" />
	<div id="config-document">
	<div id="page-general">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'General options' ); ?></legend>
		<table cellspacing="1" width="100%" class="paramlist admintable">
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( 'Database Name' ); ?>:</td>
				<td class="paramlist_value">
					<input class="inputbox" type="text" name="name" value='<?php echo str_replace("\'","\"",$item->name); ?>' maxlength="50" size="50" style="width: 400px" />
				</td>
			</tr>
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( 'Table' ); ?>:</td>
				<td class="paramlist_value">
					<select name="table" class="inputbox"  onchange="javascript: submitbutton('apply')" style="width: 400px" ><?php
						foreach ($this->tables as $table) {
							echo "<option".(($table==$item->table) ? " selected" : "").">".$table."</option>";
						}
					?></select>
				</td>
			</tr>
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( "Primary Index" ); ?>:</td>
				<td class="paramlist_value">
					<select name="fid"  class="inputbox"  style="width: 400px" ><?php
						foreach ($fields as $fname => $ftype) {
							echo "<option".(($fname==$item->fid) ? " selected" : "").">".$fname."</option>";
						}
					 ?>	</select>
				</td>
			</tr>
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( "Title or Headline" ) ?>:</td>
				<td class="paramlist_value">
					<select name="ftitle"  class="inputbox"  style="width: 400px" ><?php
						foreach ($fields as $fname => $ftype) {
							echo "<option".(($fname==$item->ftitle) ? " selected" : "").">".$fname."</option>";
						}
					 ?>	</select>
				</td>
			</tr>
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( "Main Content" ); ?>:</td>
				<td class="paramlist_value">
					<select name="fcontent"  class="inputbox"  style="width: 400px" ><?php
						foreach ($fields as $fname => $ftype) {
							echo "<option".(($fname==$item->fcontent) ? " selected" : "").">".$fname."</option>";
						}
					 ?>	</select>
				</td>
			</tr>
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( "Abstract" ); ?>:</td>
				<td class="paramlist_value">
					<select name="fabstract"  class="inputbox"  style="width: 400px" >
						 <option value="">...</option><?php
						foreach ($fields as $fname => $ftype) {
							echo "<option".(($fname==$item->fabstract) ? " selected" : "").">".$fname."</option>";
						}
					 ?>	</select>
				</td>
			</tr>
			<tr>
				<td width="250" class="paramlist_key"><?php echo JText::_( "Main Date" ); ?>:</td>
				<td class="paramlist_value">
					<select name="fdate"  class="inputbox"  style="width: 400px" >
					 	<option value="">...</option><?php
						foreach ($fields as $fname => $ftype) {
							echo "<option".(($fname==$item->fdate) ? " selected" : "").">".$fname."</option>";
						}
					 ?>	</select>
				</td>
			</tr>
		</table>
	</fieldset>
	</div>
	<div id="page-catalog">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Catalog template' ); ?></legend>
		<table cellspacing="1" width="750" class="paramlist admintable">
			<tr>
				<td class="paramlist_value">
				<?php
					echo $editor->display('tpl_list', $item->tpl_list, '750', '500', '40', '6',false);
				?>
				<br/>
				<?php JooDBAdminHelper::printTemplateFooter('tpl_list',$fields,'catalog');  ?>
				</td>
			</tr>
		</table>
	</fieldset>
	</div>
	<div id="page-single">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Singleview template' ); ?></legend>
		<table cellspacing="1" width="750" class="paramlist admintable">
			<tr>
				<td class="paramlist_value">
				<?php
					echo $editor->display('tpl_single', $item->tpl_single, '750', '500', '40', '6',false);
				?>
				<br/>
				<?php JooDBAdminHelper::printTemplateFooter('tpl_single',$fields,'single');  ?>
				</td>
			</tr>
		</table>
	</fieldset>
	</div>
	<div id="page-print">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Print template' ); ?></legend>
		<table cellspacing="1" width="750" class="paramlist admintable">
			<tr>
				<td class="paramlist_value">
				<?php	// 	Load the JEditor object
					echo $editor->display('tpl_print', $item->tpl_print, '750', '500', '40', '6',false);
				?>
				<br/>
				<?php JooDBAdminHelper::printTemplateFooter('tpl_print',$fields,'print');  ?>
				</td>
			</tr>
		</table>
	</fieldset>
	</div>
	</div>
</form>
<script language="JavaScript">

	function submitbutton(pressbutton)
		{
			var form = document.adminForm;

			if (pressbutton == 'cancel') {
				submitform( pressbutton );
			}

			// do field validation
			if (form.title.value == ""){
				alert('<?php echo JText::_( "Name Your DB" ); ?>');
				form.title.focus();
				return false;
			} else  {
				submitform( pressbutton );
			}
		}

</script>
