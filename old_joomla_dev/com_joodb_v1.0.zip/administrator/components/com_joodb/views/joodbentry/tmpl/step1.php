<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<link href="templates/khepri/css/icon.css" rel="stylesheet" type="text/css" />
<link href="templates/khepri/css/rounded.css" rel="stylesheet" type="text/css" />
<div id="content-box" style="border: 1px solid #ccc; height: 300px;">
<div class="border">
<div class="padding">
<div id="toolbar-box">
	<div class="t">
		<div class="t">
			<div class="t" ></div>
		</div>
	</div>
	<div class="m">
		<div id="toolbar" class="toolbar">
			<table class="toolbar"><tbody><tr>
				<td id="toolbar-next" class="button">
					<a class="toolbar" onclick="javascript:doCheckout()" href="#">
						<span title="Next" class="icon-32-forward"></span><?php echo JText::_( "Continue" ); ?>
					</a>
				</td>
			</tr></tbody></table>
		</div>
		<div class="header icon-48-cpanel"><?php echo JText::_( "Step1 choose Table" ); ?></div>
		<div class="clr" ></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
<div id="element-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
	<div class="m" style="font-size: larger; font-weight: bolder; height: 180px;">
	<form name="adminForm" action="index.php?option=com_joodb&tmpl=component&view=joodbentry&layout=step2&task=addnew" method="post">
		<br/>
		<table cellpadding="5">
		  <tr>
			<td><?php echo JText::_( "Name Your DB" ); ?></td>
			<td>
			<input type="text" name="dbname"  value="" />
			</td>
		  </tr><tr><td><?php echo JText::_( "Please choose table" ); ?></td>
		  <td>
			<select name="table" >
		 		<option>...</option>
				<?php
					foreach ($this->tables as $table) {
						echo "<option>".$table."</option>";
					}
				?>
			</select>
		   </td>
		</tr>
		</table>
	</form>
	<br/>
	<div class="clr"></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
</div>

</div>
</div>
<script type="text/javascript" language="JavaScript">
	function doCheckout() {
		if(document.adminForm.dbname.value==""){
			alert('<?php echo JText::_( "Name Your DB" ); ?>');
			return false;
		}

		if(document.adminForm.table.selectedIndex<=0){
			alert('<?php echo JText::_( "Please choose table" ); ?>');
			return false;
		}
		document.adminForm.submit();
	}
</script>

