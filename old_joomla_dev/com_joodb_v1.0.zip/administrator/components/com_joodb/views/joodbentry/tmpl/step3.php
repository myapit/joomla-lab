<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<link href="templates/khepri/css/icon.css" rel="stylesheet" type="text/css" />
<link href="templates/khepri/css/rounded.css" rel="stylesheet" type="text/css" />
<div id="content-box" style="border: 1px solid #ccc; height: 300px;">
<div class="border">
<div class="padding">
<div id="toolbar-box">
	<div class="t">
		<div class="t">
			<div class="t" ></div>
		</div>
	</div>
	<div class="m">
		<div id="toolbar" class="toolbar">
			<table class="toolbar"><tbody><tr>
				<td id="toolbar-next" class="button">
					<a class="toolbar" onclick="javascript:window.parent.location.reload();" href="#">
						<span title="Next" class="icon-32-cancel"></span><?php echo JText::_( "Close" ); ?>
					</a>
				</td>
			</tr></tbody></table>
		</div>
		<div class="header icon-48-cpanel"><?php echo JText::_( "Step3 no Step" ); ?></div>
		<div class="clr" ></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
<div id="element-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
	<div class="m" style="font-size: larger; font-weight: bolder; height: 180px;">

	<?php echo JText::_( "Step3 Help" );   ?>
	<br/><br/><br/><br/>
	<div class="clr"></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
</div>

</div>
</div>

