<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<link href="templates/khepri/css/icon.css" rel="stylesheet" type="text/css" />
<link href="templates/khepri/css/rounded.css" rel="stylesheet" type="text/css" />
<div id="content-box" style="border: 1px solid #ccc; height: 300px;">
<div class="border">
<div class="padding">
<div id="toolbar-box">
	<div class="t">
		<div class="t">
			<div class="t" ></div>
		</div>
	</div>
	<div class="m">
		<div id="toolbar" class="toolbar">
			<table class="toolbar"><tbody><tr>
				<td id="toolbar-next" class="button">
					<a class="toolbar" onclick="javascript:if(document.adminForm.fid.selectedIndex>=1 && document.adminForm.ftitle.selectedIndex>=1 && document.adminForm.fcontent.selectedIndex>=1){document.adminForm.submit();}else{alert('<?php echo JText::_( "Error" ).'\n'.JText::_( "Error define fields" ); ?>');}" href="#">
						<span title="Next" class="icon-32-forward"></span><?php echo JText::_( "Continue" ); ?>
					</a>
				</td>
			</tr></tbody></table>
		</div>
		<div class="header icon-48-cpanel"><?php echo JText::_( "Step2 define Fields" ); ?></div>
		<div class="clr" ></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
<div id="element-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
	<div class="m" style="font-size: larger; font-weight: bolder; height: 180px;">
	<form name="adminForm" action="index.php?option=com_joodb&tmpl=component&view=joodbentry&layout=step3&task=addnew" method="post">
		<input type="hidden" name="table" value="<?php echo $this->table; ?>"  />
		<input type="hidden" name="name" value="<?php echo $this->dbname; ?>"  />
		<br/>
		<table cellpadding="5"><tr><td>
		<?php echo JText::_( "Primary Index" ); ?>
		</td><td>
		<select name="fid" >
		 <option value="">...</option>
		<?php
			$fields =array_shift($this->fields);
			foreach ($fields as $fname => $ftype) {
				echo "<option>".$fname."</option>";
			}
		 ?>
		</select>
		</td></tr><tr><td>
		<?php echo JText::_( "Title or Headline" ); ?>
		</td><td>
		<select name="ftitle" >
		 <option value="">...</option>
		<?php
			foreach ($fields as $fname => $ftype) {
				echo "<option>".$fname."</option>";
			}
		 ?>
		</select>
		</td></tr><tr><td>
		<?php echo JText::_( "Main Content" ); ?>
		</td><td>
		<select name="fcontent" >
		 <option value="">...</option>
		<?php
			foreach ($fields as $fname => $ftype) {
				echo "<option>".$fname."</option>";
			}
		 ?>
		</select>
		</td></tr><tr><td>
		<?php echo JText::_( "Abstract" ); ?>
		</td><td>
		<select name="fabstract" >
		 <option value="">...</option>
		<?php
			foreach ($fields as $fname => $ftype) {
				echo "<option>".$fname."</option>";
			}
		 ?>
		</select>
		</td></tr><tr><td>
		<?php echo JText::_( "Main Date" ); ?>
		</td><td>
		<select name="fdate" >
		 <option value="">...</option>
		<?php
			foreach ($fields as $fname => $ftype) {
				echo "<option>".$fname."</option>";
			}
		 ?>
		</select>
		</td></tr></table>
	</form>
	<br/>
	<div class="clr"></div>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
</div>

</div>
</div>

