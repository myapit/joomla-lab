DROP TABLE IF EXISTS `#__joodb`;
DROP TABLE IF EXISTS `#__joodb_sample`;
