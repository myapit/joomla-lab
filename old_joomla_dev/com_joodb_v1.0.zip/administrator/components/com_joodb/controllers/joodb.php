<?php
/** part of JooBatabase component - see http://joodb.feenders.de */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.controller' );

/**
 * Main Contoller
 */
class JooDBControllerJooDB extends JController
{
	/**
	 * Constructor
	 */
	function __construct( $config = array() )
	{
		parent::__construct( $config );
		// Register Extra tasks
		$this->registerTask( 'add',			'edit' );
		$this->registerTask( 'apply',		'save' );
		$this->registerTask( 'applydata',		'savedata' );
	}

	/**
	 * Display a list of databases
	 */
	function display() {
		parent::display();
	}

	/** edit Database */
	function edit()
	{
		$document = &JFactory::getDocument();
		$vType		= $document->getType();
		$vName = JRequest::getCmd('view', 'joodbentry');
		$view = &$this->getView( $vName, $vType);
		$vLayout = JRequest::getCmd( 'layout', 'default' );
		$view->setLayout($vLayout);
		$view->display();
	}

	/** list Data of JooDatabase tables */
	function listdata()
	{
		$document = &JFactory::getDocument();
		$vType		= $document->getType();
		$view = &$this->getView( 'listdata', $vType);
		$vLayout = JRequest::getCmd( 'layout', 'default' );
		$view->setLayout($vLayout);
		$view->display();
	}

	/** edit Data of JooDatabase tables */
	function editdata() {
		$document = &JFactory::getDocument();
		$vType		= $document->getType();
		$view = &$this->getView( 'editdata', $vType);
		$vLayout = JRequest::getCmd( 'layout', 'default' );
		$view->setLayout($vLayout);
		$view->display();
	}

	/** add New entry */
	function addNew(){
		parent::display();
	}

	/**
	 * Save data
	 */
	function savedata()
	{
		$db		=& JFactory::getDBO();

		// load the jooDb object with table fiel infos
		$joodbid	= JRequest::getCmd( 'joodbid', int );
		$jb =& JTable::getInstance( 'joodb', 'Table' );
		$jb->load( $joodbid );
		$fields = $db->getTableFields($jb->table,false);
		$item=array();
		foreach ($fields[$jb->table] as $fname=>$fcell) {
			if (isset($_POST[$fname])) {
				$typearr = split("\(",$fcell->Type);
				switch ($typearr[0]) {
					case 'text' :
					case 'tinyint' :
					case 'tinytext' :
					case 'mediumtext' :
					case 'longtext' :
					$item[$fname] = $db->getescaped(JRequest::getVar($fname, '', 'post', 'string', JREQUEST_ALLOWHTML));
				break;
					case 'int' :
					case 'tinyint' :
					case 'smallint' :
					case 'mediumint' :
					case 'bigint' :
					case 'year' :
					$item[$fname] = JRequest::getInt($fname);
				break;
					case 'date' :
					case 'datetime' :
					case 'timestamp' :
					$item[$fname] = ereg_replace("[^0-9\: \-]","",JRequest::getVar($fname, '', 'post', 'string'));
				break;
					case 'set' :
					$values = JRequest::getVar($fname, '', 'post');
					$item[$fname] = join(",",$values);
				break;
					default:
					$item[$fname] = $db->getescaped(JRequest::getVar($fname));
				}
			} else {
				if ($fcell->Null=="YES") {
					$item[$fname] = "NULL";
				}
			}
		}

		if ($item[$jb->fid]>0) {
			// UPDATE
			$savestring = "";
			foreach ($item as $field => $value) {
					$savestring .= "`".$field."` = ".(($value=="NULL") ? "NULL," : "'".$value."',");
			}
			$db->setquery("UPDATE `".$jb->table."` SET " . substr($savestring,0,-1) . " WHERE ".$jb->fid." = ".$item[$jb->fid]." LIMIT 1;");
			if(!$db->query()){
				$msg = JText::_( 'Error' )." : ".$db->getErrorMsg();
			} else {
				$msg = JText::_( 'Item Saved' );
			}
			$id = $item[$jb->fid];
		} else {
			// INSERT
			$insert = "";	$values = "";
			foreach ($item as $field => $value) {
				$insert .= "`".$field."`,";
				$values .= ($value=="NULL") ? "NULL," : "'".$value."',";
			}
			$db->setquery("INSERT INTO `".$jb->table."` (".substr($insert,0,-1).") VALUES (".substr($values,0,-1)."); ");
			if(!$db->query()){
				$msg = JText::_( 'Error' )." : ".$db->getErrorMsg();
			} else {
				$id = mysql_insert_id();
				$mdg = JText::_( 'Item Saved' );
			}
			$id = mysql_insert_id();
		}

		$task = JRequest::getCmd( 'task' );
		$link = 'index.php?option=com_joodb&joodbid='.$jb->id.(($task=="applydata") ? "&view=editdata&cid[]=".$id : "&view=listdata");
		$this->setRedirect( $link, $msg );
	}

	/**
	 * Save method
	 */
	function save()
	{
		global $mainframe;

		// Initialize variables
		$row =& JTable::getInstance('joodb', 'Table');
		if (!$row->bind(JRequest::get('post',2))) {
			JError::raiseError(500, $row->getError() );
		}

		if (!$row->check()) {
			JError::raiseError(500, $row->getError() );
		}

		if (!$row->store()) {
			JError::raiseError(500, $row->getError() );
		}

		$row->checkin();

		$task = JRequest::getCmd( 'task' );
		switch ($task)
		{
			case 'apply':
				$link = 'index.php?option=com_joodb&task=edit&view=joodbentry&cid[]='. $row->id ;
				break;
			case 'save':
			default:
				$link = 'index.php?option=com_joodb';
				break;
		}

		$this->setRedirect( $link, JText::_( 'Item Saved' ) );
	}

	function cancel()
	{
		//cancel editing a record
		$this->setRedirect( 'index.php?option=com_joodb', JText::_( 'Edit canceled' ) );
	}

	function cancelEditData()
	{
		//cancel editing a record get database
		$this->setRedirect( 'index.php?option=com_joodb', JText::_( 'Edit canceled' ) );
	}

	function exitjoodb()
	{
		$this->setRedirect( 'index.php' );
	}

	/**
	 * Copy one or more databases
	 */
	function copy() {
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( 'index.php?option=com_joodb' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		=& JFactory::getDBO();
		$row =& JTable::getInstance('joodb', 'Table');
		$user	= &JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
					$table->id				= 0;
					$table->title			= 'Copy of ' . $table->name;

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}
				else {
					return JError::raiseWarning( 500, $table->getError() );
				}
			}
		}
		else {
			return JError::raiseWarning( 500, JText::_( 'No items selected' ) );
		}
		$this->setMessage( JText::sprintf( 'Items copied', $n ) );
	}

	function removedata() {
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$joodbid	= JRequest::getCmd( 'joodbid', int );

		$jb =& JTable::getInstance( 'joodb', 'Table' );
		$jb->load( $joodbid );

		$this->setRedirect( 'index.php?option=com_joodb&view=listdata&joodbid='.$jb->id );

		// Initialize variables
		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$n		= count( $cid );
		JArrayHelper::toInteger( $cid );

		if ($n)	{
			$query = 'DELETE FROM '.$jb->table
			. ' WHERE '.$jb->fid.' = ' . implode( ' OR id = ', $cid );
			$db->setQuery( $query );
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
			}
		}

		$this->setMessage( JText::sprintf( 'Items removed', $n ) );
	}

	/**
	* Remove item(s)
	*/
	function remove($view='joodb') {
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( 'index.php?option=com_joodb' );

		// Initialize variables
		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$n		= count( $cid );
		JArrayHelper::toInteger( $cid );

		if ($n)	{
			$query = 'DELETE FROM #__joodb'
			. ' WHERE id = ' . implode( ' OR id = ', $cid );
			$db->setQuery( $query );
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
			}
		}

		$this->setMessage( JText::sprintf( 'Items removed', $n ) );
	}


	/**
	* Un Publish item(s)
	*/
	function unpublish() {
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$n		= count( $cid );
		JArrayHelper::toInteger( $cid );

		if ($n) {
			$query = 'UPDATE #__joodb SET published=0 '
			. ' WHERE id = ' . implode( ' OR id = ', $cid );
			$db->setQuery( $query );
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
			} else {
				$msg = JText::sprintf( 'Items Unpublished', count( $cid ) );
			}
		}
		$this->setRedirect( 'index.php?option=com_joodb&task=view', $msg );
	}

	/**
	* Publish item(s)
	*/
	function publish()	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$n		= count( $cid );
		JArrayHelper::toInteger( $cid );

		if ($n) {
			$query = 'UPDATE #__joodb SET published=1 '
			. ' WHERE id = ' . implode( ' OR id = ', $cid );
			$db->setQuery( $query );
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
			} else {
				$msg = JText::sprintf( 'Items Published', count( $cid ) );
			}
		}
		$this->setRedirect( 'index.php?option=com_joodb&task=view', $msg );
	}


}
