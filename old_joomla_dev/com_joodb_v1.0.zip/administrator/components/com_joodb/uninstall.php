<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
function com_uninstall(){
   global $errors;

  $db =& JFactory::getDBO();
  $db->setQuery( "DROP TABLE #__joodb;" );
  $db->query();

?>
	<center>
	<h2>Thank you for using JooDatabase</h2>
	<p>The component JooDatabase and MYSQL-table was succesfully uninstalled!</p>
	</center>
	<br/>
<?php
}
?>
