<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
function com_install(){
?>
	<hr/>
	<h2>Thank you for using JooDatabase</h2>
	<h4>JooDatabase was made by</h4>
	<h3>Computer &sdot; Daten &sdot; Netze &bull; Feenders</h3>
	<ul>
		<li>Autor: Dirk Hoeschen (<a href="mailto:hoeschen@feenders.de">hoeschen@feenders.de</a>)</li>
	</ul>
	<p>Feenders does not offer free support for this version. However: If you need professional support or want individual modifications, ask for conditions.</p>
	<p>For more informations (user forum,help,FAQs and examples), look at <a href="http://joodb.feenders.de" target="_blank" title="joodb.feenders.de">joodb.feenders.de</a>.
	<br/>German support can be found at <a href="http://joodb.feenders.de/help/hilfe-ger.html" target="_blank">joodb.feenders.de/help/hilfe-ger.html</a></p>
	<p>Visit the <a href="http://joodb.feenders.de">JooDatabase site</a> for the lastest news and updates.</p>
	<br/>
<?php
  $db =& JFactory::getDBO();
  $query = "UPDATE `#__joodb` SET `table` = '".$db->getPrefix()."joodb_sample' WHERE `#__joodb`.`id` =1 LIMIT 1 ;";  
  $db->setQuery( $query );
  $db->query();


}
?>
