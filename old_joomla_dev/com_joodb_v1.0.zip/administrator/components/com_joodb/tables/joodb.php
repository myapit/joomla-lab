<?php
/**
* JooDB Table Definition
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**  */
class TableJooDB extends JTable
{
	/** @var int Primary key */
	var $id					= null;
	/** @var string */
	var $name				= null;
	/** @var string */
	var $table				= null;
	/** @var text */
	var $tpl_list		= null;
	/** @var text */
	var $tpl_single		= null;
	/** @var text */
	var $tpl_print			= null;
	/** @var string */
	var $fid				= null;
	/** @var string */
	var $ftitle				= null;
	/** @var string */
	var $fcontent			= null;
	/** @var string */
	var $fabstract			= null;
	/** @var string */
	var $fdate				= null;
	/** @var boolean */
	var $published				= 1;
	/** @var string */
	var $params				= null;
	/** @var date */
	var $created				= null;

	/**
	* @param database A database connector object
	*/
	function __construct( &$db ) {
		parent::__construct( '#__joodb', 'id', $db );
	}

	/**
	 * Overloaded check function
	 */
	function check()
	{
		if(empty($this->name)) {
			$this->setError(JText::_('Database must have a name'));
			return false;
		}
		if(empty($this->table)) {
			$this->setError(JText::_('Please choose Table'));
			return false;
		}
		if(empty($this->fid)) {
			$this->setError(JText::_('Error Define Fields'));
			return false;
		}
		if(empty($this->ftitle)) {
			$this->setError(JText::_('Error Define Fields'));
			return false;
		}
		if(empty($this->fcontent)) {
			$this->setError(JText::_('Error Define Fields'));
			return false;
		}
		/** load the default templates into field if empty */
		if(empty($this->tpl_list)) {
			$this->tpl_list = $this->getDefaultTemplate("listview");
		}
		if(empty($this->tpl_single)) {
			$this->tpl_single = $this->getDefaultTemplate("singleview");
		}
		if(empty($this->tpl_print)) {
			$this->tpl_print = $this->getDefaultTemplate("printview");
		}
		return true;
	}

	/**
	 * load the default templates into field
	 */
	function getDefaultTemplate($tname) {
		$tfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_joodb'.DS.'inc'.DS.$tname.".tpl";
		if (file_exists($tfile)) {
			$template = file_get_contents($tfile);
			// replace tag with table specific infos
			if ($tname=="listview") {
				$header = "<th width='50'>#</th><th>".JText::_('Title')."</th>\n";
				$loop = "<tr class='{joodb loopclass}'>\n<td valign='top'>\n{joodb ".$this->fid."}</td>\n<td><strong>{joodb ".$this->ftitle."}</strong>\n";
				if (!empty($this->fdate)) {
					$loop .= "\n<br/><span class='small'>".JText::_('Date').": {joodb ".$this->fdate."}</span>";
				}
				if (!empty($this->fabstract)) {
					$loop .= "\n<p>{joodb ".$this->fabstract."|120}</p>\n";
				} else {
					$loop .= "\n<p>{joodb ".$this->fcontent."|120}</p>\n";
				}
				$loop .= "</td>\n</tr>\n";
				$template = str_replace("#C_DEFAULT_HEADER", $header, $template);
				$template = str_replace("#C_DEFAULT_LOOP", $loop, $template);
			} else {
				$header = "<div class='componentheading'>{joodb ".$this->ftitle."}</div>\n";
				if (!empty($this->fdate)) {
					$header .= "<span class='small'>".JText::_('Date').": {joodb ".$this->fdate."}</span>\n";
				}
				$header .= "<p>{joodb ".$this->fcontent."}</p>\n";
				$template = str_replace("#S_DEFAULT_HEADER", $header, $template);
				$db	=& JFactory::getDBO();
				$fields = $db->getTableFields($this->table);
				$content = "<ul>\n";
				foreach ($fields[$this->table] as $fname => $ftype) {
					if (($fname!=$this->ftitle) && ($fname!=$this->fcontent) && ($fname!=$this->dabstract)) {
						if (($ftype == "text") || ($ftype == "varchar")) { $content .= "<li>{joodb ".$fname."}</li>\n";}
					}
				}
				$content .= "</ul>\n";
				$template = str_replace("#S_DEFAULT_FIELDS", $content, $template);
			}
		}
		return $template;
	}

}
