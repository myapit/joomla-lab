<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

class JooDBAdminHelper
{

	//  returns a list with all availiable functions
	function getFunctions($context) {
		$functions = array (
		"catalog" => array('pagenav','pagecount','resultcount','nodata','limitbox','searchbox','alphabox','readon'),
		"single" => array('printbutton'),
		"print" => array(),
		"general" => array('ifnot|FIELDNAME','ifis|FIELDNAME','endif') );
		return array_merge($functions[$context],$functions['general']);
	}

	//  returns a optionlist with all availiable functions
	function printTemplateFooter($editorid,$fieldlist,$context) {
		echo JText::_( 'Insert field' );
		echo '&nbsp;<select name="ifld_'.$editorid.'" onChange="jInsertEditorText(this.options[this.selectedIndex].value,\''.$editorid.'\');">';
		foreach ($fieldlist as $fname => $ftype) {
			echo "<option>{joodb ".$fname."}</option>\n";
		}
		echo '</select>&nbsp;';
		echo JText::_( 'Insert function' );
		echo '&nbsp;<select name="ifunc_'.$editorid.'" onChange="jInsertEditorText(this.options[this.selectedIndex].value,\''.$editorid.'\');">';
		$flist = JooDBAdminHelper::getFunctions($context);
		foreach ($flist as $f) {
			echo "<option>{joodb ".$f."}</option>\n";
		}
		echo '</select>';
	}



}
