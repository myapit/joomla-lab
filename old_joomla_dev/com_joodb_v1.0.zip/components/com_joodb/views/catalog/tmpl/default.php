<?php // no direct acces
defined('_JEXEC') or die('Restricted access'); ?>
<?php if ($this->params->get('show_page_title', 1)) : ?>
	<div class="componentheading<?php echo $this->params->get('pageclass_sfx')?>"><?php echo $this->escape($this->params->get('page_title')); ?></div>
<?php endif; ?>
<table width="100%" class="contentpane<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
<?php if ( $this->params->get( 'show_description' ) ) : ?>
<tr>
	<td valign="top">
	<?php if ($this->params->get('image')!="-1") : ?>
		<img src="<?php echo $this->baseurl . '/images/stories/'. $this->params->get('image');?>" align="<?php echo $this->params->get('image_align');?>" hspace="6" alt="<?php echo $this->params->get('image');?>" />
	<?php endif; ?>
		<?php echo nl2br($this->params->get('description')); ?>
	</td>
</tr>
</table>
<?php endif; ?>
<?php

	$pageparts = preg_split("!{joodb loop}!", $this->joobase->tpl_list);
	if (count($pageparts)<3) {
		echo "<p class='error'>Error in catalog template. Remember 2 loop declarations must be found inside catalog template!</p>";
	} else {

	$pageloop = "";
	if ($this->items) {
	 foreach ( $this->items as $item ) {
			$loopclass = ($loopclass=="even") ? "odd" : "even";

			$pageitem = JoodbHelper::parseTemplate($this->joobase,$pageparts[1],$item,$this->params->get('link_titles','1'));

			// replace class information with wildcard for row patterns
			$pageitem = str_replace("{joodb loopclass}" ,$loopclass,$pageitem);
			$pageloop .= $pageitem."\n";
			$n++;
		}
	}

	$pageparts[1] = $pageloop;

	$pagetext = join("",$pageparts);

	if ($pageloop=="") {
		$pagetext = str_replace("{joodb nodata}" , JText::_('No data found') ,$pagetext);
	}
	// replace wildcards with page navigation elements
	preg_match_all('/\{joodb ([^}]+)\}/U',$pagetext, $matches);
   	foreach( $matches[1] as $wildcard ) {
   		switch ($wildcard) {
   			case ('pagenav'):
   				$pagetext = str_replace("{joodb pagenav}",$this->pagination->getPagesLinks(),$pagetext);
   				break;
   			case ('pagecount'):
   				$pagetext = str_replace("{joodb pagecount}",$this->pagination->getPagesCounter(),$pagetext);
   				break;
   			case ('resultcount'):
   				$pagetext = str_replace("{joodb resultcount}",$this->total,$pagetext);
   				break;
   			case ('limitbox'):
   				$pagetext = str_replace("{joodb limitbox}","<form name='limitForm' method='post' action='".JoodbHelper::_findItem($this->joobase,'&task=limit')."' >".$this->pagination->getLimitBox()."</form>",$pagetext);
   				break;
   			case ('searchbox'):
   				$pagetext = str_replace("{joodb searchbox}",JoodbHelper::printSearchbox($this->search,$this->joobase),$pagetext);
   				break;
   			case ('alphabox'):
   				$pagetext = str_replace("{joodb alphabox}",JoodbHelper::printAlphabox($this->alphachar,$this->joobase),$pagetext);
   				break;
   			default:
				$pagetext = str_replace("{joodb ".$wildcard."}","",$pagetext);
   				break;
   		}
   	}

	// print out the whole text
	echo $pagetext;
	}
?>
