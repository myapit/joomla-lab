<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the JooDatabase cataloges
 */
class JoodbViewCatalog extends JView
{
	function display($tpl = null)
	{
		global $mainframe;

		// Load the menu object and parameters
		// Get some objects from the JApplication
		$pathway  =& $mainframe->getPathway();
		$document =& JFactory::getDocument();

		// Get the current menu item
		$menus	= &JSite::getMenu();
		$menu	= $menus->getActive();
		$params	= &$mainframe->getParams();

		// read database configuration from joobase table
		$joobase =& $this->get('joobase');

		//get the data page
		$items =& $this->get('data');

		// because the application sets a default page title, we need to get it
		// right from the menu item itself
		if (is_object( $menu )) {
			$menu_params = new JParameter( $menu->params );
			if (!$menu_params->get( 'page_title')) {
				$params->set('page_title',	JText::_( $joobase->name ));
			}
		} else {
			$params->set('page_title',	JText::_( $joobase->name ));
		}

		$document->setTitle( $params->get( 'page_title' ) );

		$pagination = & $this->get('pagination');

		$this->assignRef('items', $items);
		$this->assignRef('total', $this->get('total'));
		$this->assignRef('joobase', $joobase);
		$this->assignRef('params', $params);
		$this->assignRef('pagination', $pagination);
		$this->assignRef('search', $this->get('search'));
		$this->assignRef('alphachar', $this->get('alphachar'));
		parent::display($tpl);
	}
}
?>
