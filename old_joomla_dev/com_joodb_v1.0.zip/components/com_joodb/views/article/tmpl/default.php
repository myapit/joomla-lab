<?php // no direct access
defined('_JEXEC') or die('Restricted access');

	// get the whole text
	$pagetext = JoodbHelper::parseTemplate($this->joobase,$this->joobase->tpl_single,$this->item,$this->param);

	// replace wildcards with page navigation elements
	preg_match_all('/\{joodb ([^}]+)\}/U',$pagetext, $matches);
   	foreach( $matches[1] as $wildcard ) {
   		switch ($wildcard) {
   			case ('printbutton'):
				$pagetext = str_replace("{joodb printbutton}", JoodbHelper::printPopup($this->item,$this->params,$this->joobase),$pagetext);
   				break;
   			default:
				$pagetext = str_replace("{joodb ".$wildcard."}","",$pagetext);
   				break;
   		}
	}

	echo $pagetext;


?>

