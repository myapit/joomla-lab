<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the JooDatabase singel element
 */
class JoodbViewArticle extends JView
{
	function display($tpl = null)
	{
		global $mainframe;

		// Load the menu object and parameters
		// Get some objects from the JApplication
		$pathway  =& $mainframe->getPathway();
		$document =& JFactory::getDocument();

		// Get the current menu item
		$menus	= &JSite::getMenu();
		$menu	= $menus->getActive();
		$params	= &$mainframe->getParams();

		//get the data page
		$item =& $this->get('data');

		// read database configuration from joobase table
		$joobase = $this->get('joobase');

		// because the application sets a default page title, we need to get it
		// right from the menu item itself
		if (is_object( $menu )) {
			$menu_params = new JParameter( $menu->params );
			if (!$menu_params->get( 'page_title')) {
				$params->set('page_title',	JText::_( $joobase->name ));
			}
		} else {
				$params->set('page_title',	JText::_( $joobase->name ));
		}


		$document	= &JFactory::getDocument();
		$document->setTitle(  $joobase->name." - ".$item->{$joobase->ftitle} );

		$this->assignRef('item',		$item);
		$this->assignRef('joobase',		$joobase);
		$this->assignRef('params',		$params);

		parent::display($tpl);
	}
}
?>
