<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * JooDatabase Component Controller
 */
class JoodbController extends JController
{
	/**
	 * Method to show a view
	 */
	function display()
	{
		// Set a default view if none exists
		if ( ! JRequest::getCmd( 'view' ) ) {
			JRequest::setVar('view', 'catalog' );
		}

		parent::display();
	}

	/**
	 * Search a item in database
	 */
	function search()
	{
		$stext = JRequest::getVar('search');
		$joobase->id = JRequest::getInt( 'joobase' );
		$this->setRedirect(JoodbHelper::_findItem($joobase,"&search=".$stext));
		return;
	}

	/**
	 * Set the output limit
	 */
	function limit()
	{
		$limit = JRequest::getVar('limit');
		$joobase->id = JRequest::getInt( 'joobase' );
		$this->setRedirect(JoodbHelper::_findItem($joobase,"&limit=".$limit));
		return;
	}


}

?>
