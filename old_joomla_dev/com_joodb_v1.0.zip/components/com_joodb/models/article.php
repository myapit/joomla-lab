<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.model');

/**
 * JooDatabase Component single item Model
 */
class JoodbModelArticle extends JModel
{
	/**
	 * Entry Item Object
	 *
	 * @var array
	 */
	var $_data = null;

	/**
	 * Database Object
	 *
	 * @var object
	 */
	var $_joobase = null;

	/**
	 * Constructor
	 */
	function __construct()
	{
		parent::__construct();
		global $mainframe;
		$params	= &$mainframe->getParams();
		$joobase = $params->get("joobase", 0);
		if ($joobase==0) $joobase = JRequest::getInt('joobase', 1);
		// Load the Database parameters
		$this->_db->setQuery( "SELECT * FROM #__joodb WHERE id='".$joobase."' " );
		$this->_joobase = $this->_db->loadObject();
		// get the table field list
		$this->_joobase->fields = $this->_db->getTableFields($this->_joobase->table);
		$this->_joobase->fields = $this->_joobase->fields[$this->_joobase->table];
		$id = $params->get("id", 0);
		if ($id==0) $id = JRequest::getInt('id', 1);
		$this->setId((int)$id);
	}

	/**
	 * Method to set the article id
	 *
	 * @access	public
	 * @param	int	Article ID number
	 */
	function setId($id)
	{
		// Set new article ID and wipe data
		$this->_id		= $id;
		$this->_article	= null;
	}

	/**
	 * Get Object from JooDB table
	 *
	 * @access public
	 * @return single object
	 */
	function getJoobase()
	{
		return	$this->_joobase;
	}

	/**
	 * Method to get Data from table in Database
	 *
	 * @access public
	 * @return array
	 */
	function getData()
	{
		// Lets load the content if it doesn't already exist
		if (empty($this->_data))
		{
		/* Query single object. */
		$this->_db->setQuery('SELECT a.* FROM '.$this->_joobase->table.' AS a'
							. ' WHERE a.'.$this->_joobase->fid.'='.$this->_id.' LIMIT 1;');
		$this->_data = $this->_db->loadObject();

		}

		return $this->_data;
	}

}
?>
