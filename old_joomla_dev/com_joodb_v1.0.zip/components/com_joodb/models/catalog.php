<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.model');

/**
 * JooDatabase Component Catalog Model
 */
class JoodbModelCatalog extends JModel
{
	/**
	 * Frontpage data array
	 *
	 * @var array
	 */
	var $_data = null;

	/**
	 * Frontpage total
	 *
	 * @var integer
	 */
	var $_total = null;

	/**
	 * Database Object
	 *
	 * @var object
	 */
	var $_joobase = null;

	/**
	 * Where Statemant
	 *
	 * @var string
	 */
	var $_where = null;

	/**
	 * Constructor
	 */
	function __construct()
	{
		parent::__construct();
		global $mainframe;
		$params	= &$mainframe->getParams();

		$joobase = $params->get("joobase",0);
		if ($joobase==0) $joobase = JRequest::getInt('joobase', 1);
		// Load the Database parameters
		$this->_db->setQuery( "SELECT * FROM #__joodb AS a WHERE id='".$joobase."' " );
		$this->_joobase = $this->_db->loadObject();

		// get the table field list
		$this->_joobase->fields = $this->_db->getTableFields($this->_joobase->table);
		$this->_joobase->fields = $this->_joobase->fields[$this->_joobase->table];

		// Get the pagination request variables
		$this->setState('limit', $mainframe->getUserStateFromRequest('com_joodb.limit', 'limit', $params->get('limit','10'), 'int'));
		$this->setState('limitstart', JRequest::getVar('limitstart', 0, '', 'int'));
		$orderby = $params->get('orderby','fid');
		$this->setState('orderby',$this->_joobase->{$orderby});
		$this->setState('ordering',$params->get('ordering','DESC'));
		$this->setState('search',JRequest::getVar('search'));
		$this->setState('alphachar', JRequest::getVar('letter'));

		$where = array();
		if ($params->get("where_statement")!="") {
			 $where[] = ' ('.$params->get("where_statement").')';
		}

		//build search string
		if ($this->getState('alphachar')!="") {
			if (JRequest::getVar('letter')) {
				$this->setState('search','');
			}
			$where[] .= " (a.".$this->_joobase->ftitle." LIKE '".substr($this->getState('alphachar'),0,1)."%' )";
		} else if ($this->getState('search')!="") {
			if (strlen($this->getState('search'))>=3) {
				$search = substr($this->getState('search'),0,40);
				$where[] .= " (a.".$this->_joobase->ftitle." LIKE '%".$search."%' ".
				            " OR a.".$this->_joobase->fcontent." LIKE '%".$search."%' ) ";
			}
		}
		if (count($where)>=1) $this->_where = " WHERE ".join(" AND ", $where);
	}

	/**
	 * Get Object from JooDB table
	 *
	 * @access public
	 * @return single object
	 */
	function getJoobase()
	{
		return	$this->_joobase;
	}

	/**
	 * Method to get Data from table in Database
	 *
	 * @access public
	 * @return array
	 */
	function getData()
	{
		// Lets load the content if it doesn't already exist
		if (empty($this->_data))
		{
			$query = $this->_buildQuery();
			$this->_data = $this->_getList($query);

		}

		return $this->_data;
	}

	/**
	 * Method to get the total number of items in the Database
	 *
	 * @access public
	 * @return integer
	 */
	function getTotal()
	{
		// Get total if not exits
		if (empty($this->_total))
		{
			$query = 'SELECT '.$this->_joobase->fid.' AS numlinks FROM '.$this->_joobase->table." AS a ".$this->_where;
			$this->_total = $this->_getListCount($query);
		}

		return $this->_total;
	}

	/**
	 * Method to get a pagination object
	 *
	 * @access public
	 * @return integer
	 */
	function getPagination()
	{
		// Lets load the content if it doesn't already exist
		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination( $this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_pagination;
	}

	/**
	 * Method to get a search value
	 *
	 * @access public
	 * @return string
	 */
	function getSearch()
	{
		return $this->getState('search');
	}

	/**
	 * Method to get a search value
	 *
	 * @access public
	 * @return string
	 */
	function getAlphachar()
	{
		return $this->getState('alphachar');
	}

	/**
	 * Build query string
	 *
	 * @access non-public
	 * @return string
	 */
	function _buildQuery()
	{
		$pagination = & $this->getPagination();
		/* Query table ant return the relevant fields. */
		$query = 'SELECT a.* AS numlinks'
			. ' FROM '.$this->_joobase->table.' AS a'
			. $this->_where
			. ' GROUP BY a.'.$this->_joobase->fid
			. ' ORDER BY a.'.$this->getState('orderby')
			. ' '.$this->getState('ordering').' LIMIT '.$pagination->limitstart.','.$pagination->limit;
			return $query;
	}
}
?>
