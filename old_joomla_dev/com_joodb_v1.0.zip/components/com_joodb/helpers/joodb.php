<?php
/**
* @package		JooDatabase - http://joodb.feenders.de
* @copyright	Copyright (C) Computer - Daten - Netze : Feenders. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @author		Dirk Hoeschen (hoeschen@feenders.de)
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// Component Helper
jimport('joomla.application.component.helper');

/**
 * JooDB Component Helper
 */
class JoodbHelper
{

	/**
 	* Parse template for wildcards and return text
 	*
 	* @access public
 	* @param JooDB-Objext with fieldnames, String with template, Object with Item-Data
 	* @return The parsed output
 	*
 	*/
	function parseTemplate($joobase, $template, $item, $linktitle=false) {

	   $template = JoodbHelper::parseConditions($joobase, $template, $item);
	   // generate link to the item
	   $itemlink = JRoute::_('index.php?option=com_joodb&view=article&joobase='.$joobase->id.'&id='.$item->{$joobase->fid}.':'.JFilterOutput::stringURLSafe($item->{$joobase->ftitle}),false);
		// replace item content with wildcards
		preg_match_all('/\{joodb ([^}]+)\}/U',$template, $matches);
    	foreach( $matches[1] as $wildcard ) {
    		// split the wildcard into fieldname and parameter like maxlen
    		$parameter = split("\|",$wildcard);
			$command = array_shift($parameter);

				// only replace exisiting fields
	   		if (isset($joobase->fields[$command])) {
				if (($linktitle) && ($command==$joobase->ftitle)) {
					$item->{$command} = "<a href='".$itemlink."' title='".Jtext::_('Read more...')."' class='joodb_titletink'>".$item->{$command}."</a>";
				}
				if ($item->{$command}) {
					// convert some of the fieldtypes
					switch(strtolower($joobase->fields[$command])) {
						case "date":
							$item->{$command} = JHTML::_('date', $item->{$command}, JText::_('DATE_FORMAT_LC3'));
						break;
						case "datetime":
							$item->{$command} = JHTML::_('date', $item->{$command}, JText::_('DATE_FORMAT_LC2'));
						break;
						case "timestamp":
							$item->{$command} = JHTML::_('date', $item->{$command}, JText::_('DATE_FORMAT_LC2'));
						break;
						case "varchar":
						case "tinytext":
							// try to detect and link urls ans emails
							if (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $item->{$command})) {
								$item->{$command} = JHtml::_('email.cloak', $item->{$command});
							} else if (strtolower(substr($item->{$command},0,4))=="www.") {
								$item->{$command} = '<a href="http://'.$item->{$command}.'" target"_blank">'.$item->{$command}.'</a>';
							}
						break;
					}
					// shorten a text for abscracts
					if (($parameter[0]) && ($parameter[0]>1)) {
						$item->{$command} = JoodbHelper::wrapText($item->{$command},$parameter[0]);
					}
				}
				$template = str_replace("{joodb ".$wildcard."}" ,$item->{$command},$template);
    		} else if ($command=="readon") { // replace readon filed
				$template = str_replace("{joodb readon}" ,"<a class='readon' href='".$itemlink."'>".Jtext::_('Read more...')."</a>",$template);
    		}
  	 	}
  	 	return $template;

	}

	/**
 	* Recursive parse the template fpr loops and conditions
 	*
 	* @access public
 	* @param JooDB-Objext with fieldnames, String with template, Object with Item-Data
 	* @return The parsed output
 	*
 	*/
	function parseConditions($joobase, $template, $item) {
		$pos = strpos($template,"{joodb");
		while ($pos!==false) {
			$oldpos = $pos+6;
			$endpos = strpos($template,"}",$oldpos);
    		$parameter = trim(substr($template,$oldpos,($endpos-$oldpos)));
    		$parameter = split("\|",$parameter);
			$command = array_shift($parameter);
			if (($command == "ifis") || ($command == "ifnot"))  {
				/* todo: this is not a real parser */
				if (($command == "ifis" && (!$item->{$parameter[0]})) || ($command == "ifnot" && $item->{$parameter[0]})){
					$endpos = strpos($template,"endif}",$oldpos);
					if ($endpos!==false) {
						$template = substr($template,0,$pos).substr($template,$endpos+6);
					}
				}
			} else if ($command="endif")  {
				$output=true;
			}
			$pos = strpos($template,"{joodb",$oldpos);
		}

  	 	return $template;
	}

	/**
 	* Shorten a text
 	*
 	* @access public
 	* @param String with text, Integer with maximum length
 	*/
	function wrapText($text,$maxlen=120) {
		if (strlen($text)>$maxlen) {
			$text = strip_tags($text);
			$len = strpos($text," ",$maxlen);
			if ($len) $text = substr($text,0,$len).' &hellip;';
		}
		return $text;
	}

	/**
 	* Returns popup link for printview as Icon or Text
 	*
 	* @access public
 	* @param Item, Params
 	*/

	function printPopup($item, $params, $joobase, $attribs = array())
	{
		$url  = 'index.php?option=com_joodb&view=article&joobase='.$joobase->id.'&id='.$item->{$joobase->fid}.'&layout=print&tmpl=component&print=1';

		$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';

		// checks template image directory for image, if non found default are loaded
		if ( $params->get( 'show_icons', '1' ) ) {
			$text = JHTML::_('image.site',  'printButton.png', '/images/M_images/', NULL, NULL, JText::_( 'Print' ) );
		} else {
			$text = JText::_( 'ICON_SEP' ) .'&nbsp;'. JText::_( 'Print' ) .'&nbsp;'. JText::_( 'ICON_SEP' );
		}

		$attribs['title']	= JText::_( 'Print' );
		$attribs['onclick'] = "window.open(this.href,'win2','".$status."'); return false;";
		$attribs['rel']     = 'nofollow';

		return JHTML::_('link', JRoute::_($url), $text, $attribs);
	}


	/**
 	* Returns Search box for catalog view
 	*
 	* @access public
 	* @param  current Searchstring, Joobase
 	*/
	function printSearchbox($search="",$joobase)
	{
		$stext = JText::_('search...');
		$sval = ($search!="") ? $search : $stext;
		$searchform =  "<form name='searchForm' method='post' action='".JoodbHelper::_findItem($joobase)."' >"
					   ."<input class='joodb_searchword' class='inputbox' type='text' onfocus='if(this.value==\"".$stext."\") this.value=\"\";' onblur='if(this.value==\"\") this.value=\"".$stext."\";' value='".$sval."'' size='20'' alt='".$stext."' maxlength='20' name='search'/>"
					   ."<input class='joodb_searchbutton' type='submit' value='".$stext."' >"
					   ."<input class='joodb_searchbutton' type='submit' value='".JText::_( 'Reset...' )."' onmousedown='document.searchForm.search.value=\"\";' >"
					   ."<input type='hidden' name='task' value='search'> "
					   ."</form>";
		return $searchform;
	}


	/**
 	* Returns a roman alphabet to select the first letters ot the title
 	*
 	* @access public
 	* @param current Alphachar
 	*/
	function printAlphabox($alphachar,$joobase)
	{
		$alphabox = "<div style='width:auto;text-align:center;' class='pagination alphabox'>";
		$alphabet= array ('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
		foreach ($alphabet as $achar) {
			if ($achar==$alphachar) {
				$alphabox .= "<span class='active'>".ucfirst($achar)."</span>";
			} else {
				$alphabox .= "<a href='".JoodbHelper::_findItem($joobase,"&letter=".$achar)."'>".ucfirst($achar)."</a>";
			}
		}
		$alphabox .=  "<a href='".JoodbHelper::_findItem($joobase)."'>&raquo;".JText::_('All')."</a></div>";
		return $alphabox;
	}

	/**
 	* Try to find menuitem for the database
 	*
 	* @access private
 	* @param id of the referring database
 	*/
	function _findItem($joobase,$params="")
	{
			return JRoute::_("index.php?option=com_joodb&view=catalog&joobase=".$joobase->id.$params);

	}

}
?>
