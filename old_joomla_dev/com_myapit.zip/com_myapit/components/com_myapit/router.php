<?php
/**
 * Joomla! 1.5 component myAPIT
 *
 * @version $Id: router.php 2010-04-12 23:14:49 svn $
 * @author apit
 * @package Joomla
 * @subpackage myAPIT
 * @license GNU/GPL
 *
 * nothing special... just some fakap
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Function to convert a system URL to a SEF URL
 */
function MyapitBuildRoute(&$query) {

}
/*
 * Function to convert a SEF URL back to a system URL
 */
function MyapitParseRoute($segments) {

}
?>