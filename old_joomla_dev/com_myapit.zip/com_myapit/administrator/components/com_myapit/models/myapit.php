<?php
/**
 * Joomla! 1.5 component myAPIT
 *
 * @version $Id: myapit.php 2010-04-12 23:14:49 svn $
 * @author apit
 * @package Joomla
 * @subpackage myAPIT
 * @license GNU/GPL
 *
 * nothing special... just some fakap
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport('joomla.application.component.model');

class MyapitModelMyapit extends JModel {
    function __construct() {
		parent::__construct();
    }
}
?>