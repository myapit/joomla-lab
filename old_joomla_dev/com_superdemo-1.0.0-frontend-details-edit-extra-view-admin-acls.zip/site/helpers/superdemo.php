<?php

/**
 * @version     1.0.0
 * @package     com_superdemo
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      RN kushwaha <rn.kushwaha022@gmail.com> - http://a2znotes.blogspot.com
 */
defined('_JEXEC') or die;

class SuperdemoFrontendHelper {
    
}
