<?php
/**
 * @version     1.0.0
 * @package     com_superdemo
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      RN kushwaha <rn.kushwaha022@gmail.com> - http://a2znotes.blogspot.com
 */
// no direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_superdemo.' . $this->item->id);
if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_superdemo' . $this->item->id)) {
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>
<?php if ($this->item) : ?>

    <div class="item_fields">
        <table class="table">
            <tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_ID'); ?></th>
			<td><?php echo $this->item->id; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_STATE'); ?></th>
			<td>
			<i class="icon-<?php echo ($this->item->state == 1) ? 'publish' : 'unpublish'; ?>"></i></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_CREATED_BY'); ?></th>
			<td><?php echo $this->item->created_by_name; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_PROJECT'); ?></th>
			<td><?php echo $this->item->project; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_SD'); ?></th>
			<td><?php echo $this->item->sd; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_SHOW_ON'); ?></th>
			<td><?php echo $this->item->show_on; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_CATEGORY_ID'); ?></th>
			<td><?php echo $this->item->category_id; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_SHOW_IT'); ?></th>
			<td><?php echo $this->item->show_it; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_DESCRIPTION'); ?></th>
			<td><?php echo $this->item->description; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_AUTHOR_EMAIL'); ?></th>
			<td><?php echo $this->item->author_email; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_AUTHOR_PASS'); ?></th>
			<td><?php echo $this->item->author_pass; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_RANGE'); ?></th>
			<td><?php echo $this->item->range; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_DATE'); ?></th>
			<td><?php echo $this->item->date; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_PARENT_ID'); ?></th>
			<td><?php echo $this->item->parent_id; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_TAGS'); ?></th>
			<td><?php echo $this->item->tags; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_IMAGE'); ?></th>
			<td><?php echo $this->item->image; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_FILES'); ?></th>
			<td>
			<?php $uploadPath = 'administrator' . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_superdemo' . DIRECTORY_SEPARATOR . '/' . DIRECTORY_SEPARATOR . $this->item->files; ?>
			<a href="<?php echo JRoute::_(JUri::base() . $uploadPath, false); ?>" target="_blank"><?php echo $this->item->files; ?></a></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_USERIS'); ?></th>
			<td><?php echo $this->item->useris_name; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_SUPERDEMO_FORM_LBL_SUPERDEMO_PROJECTS_DATETIME'); ?></th>
			<td><?php echo $this->item->datetime; ?></td>
</tr>

        </table>
    </div>
    <?php if($canEdit && $this->item->checked_out == 0): ?>
		<a class="btn" href="<?php echo JRoute::_('index.php?option=com_superdemo&task=superdemo_projects.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_SUPERDEMO_EDIT_ITEM"); ?></a>
	<?php endif; ?>
								<?php if(JFactory::getUser()->authorise('core.delete','com_superdemo.superdemo_projects.'.$this->item->id)):?>
									<a class="btn" href="<?php echo JRoute::_('index.php?option=com_superdemo&task=superdemo_projects.remove&id=' . $this->item->id, false, 2); ?>"><?php echo JText::_("COM_SUPERDEMO_DELETE_ITEM"); ?></a>
								<?php endif; ?>
    <?php
else:
    echo JText::_('COM_SUPERDEMO_ITEM_NOT_LOADED');
endif;
?>
