<?php

/**
 * @version     1.0.0
 * @package     com_superdemo
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      RN kushwaha <rn.kushwaha022@gmail.com> - http://a2znotes.blogspot.com
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Superdemo helper.
 */
class SuperdemoHelper {

    /**
     * Configure the Linkbar.
     */
    public static function addSubmenu($vName = '') {
        		JHtmlSidebar::addEntry(
			JText::_('COM_SUPERDEMO_TITLE_SUPERDEMO_PROJECTSS'),
			'index.php?option=com_superdemo&view=superdemo_projectss',
			$vName == 'superdemo_projectss'
		);
		JHtmlSidebar::addEntry(
			JText::_('COM_SUPERDEMO_TITLE_GALLERYS'),
			'index.php?option=com_superdemo&view=gallerys',
			$vName == 'gallerys'
		);

    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return	JObject
     * @since	1.6
     */
    public static function getActions() {
        $user = JFactory::getUser();
        $result = new JObject;

        $assetName = 'com_superdemo';

        $actions = array(
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        );

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }


}
