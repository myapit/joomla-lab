<?php
/**
 * @version     1.0.0
 * @package     com_superdemo
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      RN kushwaha <rn.kushwaha022@gmail.com> - http://a2znotes.blogspot.com
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Superdemo_projects controller class.
 */
class SuperdemoControllerSuperdemo_projects extends JControllerForm
{

    function __construct() {
        $this->view_list = 'superdemo_projectss';
        parent::__construct();
    }

}