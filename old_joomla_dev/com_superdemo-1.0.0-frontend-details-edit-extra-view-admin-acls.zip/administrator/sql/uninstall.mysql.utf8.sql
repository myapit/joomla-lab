DROP TABLE IF EXISTS `#__superdemo_projects`;
