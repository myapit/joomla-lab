<?php
/**
 * Joomla! 1.5 component pestahoki online reg
 *
 * @version $Id: pestahokionlinereg.php 2012-06-12 02:29:36 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage pestahoki online reg
 * @license GNU/GPL
 *
 * Pestahoki USM online registration
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

/**
 * pestahoki online reg Component pestahoki online reg Model
 *
 * @author      notwebdesign
 * @package		Joomla
 * @subpackage	pestahoki online reg
 * @since 1.5
 */
class PestahokionlineregModelPestahokionlinereg extends JModel {
    /**
	 * Constructor
	 */
	public  $_countries = array();
	
	public $_pincode = '';
	public $_name = '';
	public $_email ='';
	  
	function __construct() {
		parent::__construct();
    }
    
    function ph_get_list($id)
    {
    	
    }
    
    function get_basic_info($email)
    {
    	$db = &JFactory::getDBO();
    	$db->setQuery("select * from #__phpin where email = '".$email."'");
        $res = $db->loadAssocList();
        if(count($res)==0) 
        {
        	return false;
        }else{
        	foreach($res as $row)
        	{
				$this->_email= $row['email'];
				$this->_pincode = $row['pin_id'];
				$this->_name = $row['name'];
        	}
        	return true;	
        }	
    }
    
    function checkpin($pin)
    {
     	$db = &JFactory::getDBO();
    	$db->setQuery("select * from #__phpin where pin_id = '".$pin."'");
        $res = $db->loadAssocList();
        if(count($res)==0) 
        {
        	return false;
        }else{
        	return true;	
        }	
    }
    
    function checkteam($id)
    {
     	$db = &JFactory::getDBO();
    	$db->setQuery("select * from #__phteam where team_id = '".$id."'");
        $res = $db->loadAssocList();
        if(count($res)==0) 
        {
        	return false;
        }else{
        	return true;	
        }	
    }
    
    function checkemail($email)
    {
     	$db = &JFactory::getDBO();
    	$db->setQuery("select * from #__phpin where email = '".$email."'");
        $res = $db->loadAssocList();
        if(count($res)==0) 
        {
        	return false;
        }else{
        	return true;	
        }	
    }
    
    function save_account()
    {
    	$db =& JFactory::getDBO();
    	
    	$items_model =& JModel::getInstance( 'general', 'PestahokionlineregModel' );
    	
    	$name  = JString::strtoupper(JRequest::getString("name",null,'POST'));
		$email = JString::strtolower(JRequest::getString("email",null,'POST'));
		
		$address  = JString::strtoupper(JRequest::getString("address",null,'POST'));
		$postcode = JString::strtoupper(JRequest::getString("postcode",null,'POST'));
		$town     = JString::strtoupper(JRequest::getString("town",null,'POST'));
		$state    = JString::strtoupper(JRequest::getString("state",null,'POST'));
		$country  = JString::strtoupper(JRequest::getString("country",null,'POST'));
		
		$office    =  JString::strtoupper(JRequest::getString("office",null,'POST'));
		$mobile    =  JString::strtoupper(JRequest::getString("mobile",null,'POST'));
		$residence =  JString::strtoupper(JRequest::getString("residence",null,'POST'));
		$fax       =  JString::strtoupper(JRequest::getString("fax",null,'POST'));
		
		$check_input = "";
		empty($name) || is_null($name)? $check_input   .= "Name, ":'';
		empty($email) || is_null($email)? $check_input .= "Email, ":'';
		
		empty($address) || is_null($address)? $check_input   .= "Address, ":'';
		empty($postcode) || is_null($postcode)? $check_input .= "Postcode, ":'';
		empty($town) || is_null($town)? $check_input         .= "Town, ":'';
		empty($state) || is_null($state)? $check_input       .= "State, ":'';
		empty($country) || is_null($country)? $check_input   .= "Country, ":'';
		
		//empty($office) || is_null($office)? $check_input       .= "Office, ":'';
		empty($mobile) || is_null($mobile)? $check_input       .= "Mobile, ":'';
		//empty($residence) || is_null($residence)? $check_input .= "Residence, ":'';
		//empty($fax) || is_null($fax)? $check_input             .= "Fax, ":'';
		
		//$return_url = JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=registe');
		
		
		if (!empty($check_input))
		{
			//$controller = & JController::setRedirect($url,$msg = 'Record Saved.',$msgType = 'message');
        	//$controller = & JController::redirect();
        	//JError::raiseError(100, "Please fill ".$check_input);
        	return $check_input;
		}
		if (!$items_model->validate_email($email))
		{	
			return "email";	
		}
		
		$pin_id = $items_model->generate_autoid();
		$exist = false;
		/* begin check pin -- should not execute */
		if ($this->checkpin($pin_id)==false)
		{
			$exist = false;
		}else{
			//exist
			$exist = true;
		}
		/* end check pin */
		
		if ($this->checkemail($email)==false)
		{
			$exist = false;
		}else{
			//exist
			$exist = true;
		}
		
       
		if ($exist == false)
		{
			$data = new stdClass();
	        $data->pin_id = $pin_id;
	        $data->email  = $email;
	        $data->name   = $name;
	        
	        $data->address  = $address;
	        $data->postcode = $postcode;
	        $data->state = $state;
	        $data->town     = $town;
	        $data->country  = $country;
	        
	        $data->tel_office    = $office;
	        $data->tel_mobile    = $mobile;
	        $data->tel_residence = $residence;
	        $data->fax           = $fax;
	        
	        $data->pin_log = date("Y-m-d H:i:s")."|".$_SERVER['REMOTE_ADDR']."|".$_SERVER['HTTP_USER_AGENT'];
	                
	        $simpan = $db->insertObject( '#__phpin', $data);
	        $_SESSION['PINID'] = $pin_id;
	        $session = JFactory::getSession();
	        $session->set('PIN', $pin_id);
	        $session->set('NAME', $name);
	        $session->set('EMAIL', $email);
	        return "success";
		} else {
			return "failed";
		}
        
		
    }
}
?>