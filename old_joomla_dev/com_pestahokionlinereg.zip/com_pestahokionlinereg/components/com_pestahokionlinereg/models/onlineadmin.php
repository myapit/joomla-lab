<?php

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

      //pestahokionlineregModelOnlinesystem 
class PestahokionlineregModelOnlineadmin extends JModel 
{
	
	function __construct()
	{	
		parent::__construct();
	}
		
	function get_team_manager()
	{
		$db = & JFactory::getDBO();
		$sql = "SELECT * FROM #__phpin ORDER BY name ASC";
		$db->setQuery($sql);
		$result = $db->loadAssocList();
		return $result;
	}
	
	function get_team($pin)
	{
		$db = & JFactory::getDBO();
		$sql = "SELECT T.*, C.* 
				FROM #__phteam AS T
				LEFT JOIN #__phcategory AS C
				ON T.cat_id = C.cat_id
				WHERE pin_id='$pin' ORDER BY team_name ASC";
		$db->setQuery($sql);
		$result = $db->loadAssocList();
		return $result;
	}
	
	function get_category()
	{
		$db = &JFactory::getDBO();
		$query = "select * from #__phcategory";
		$db->setQuery($query);
		$res = $db->loadAssocList();
		return $res;
	}
	
	function getnum($type='team', $pin_id)
	{
		$db = & JFactory::getDBO();
		
		switch($type)
		{
			case "paid":
				$sql = "SELECT * FROM #__phteam WHERE pin_id='$pin_id' AND team_status='1' AND payment='1'";
				break;
			case "unpaid":
				$sql = "SELECT * FROM #__phteam WHERE pin_id='$pin_id' AND team_status='1' AND payment='0'";
				break;
			case "team":
				$sql = "SELECT * FROM #__phteam WHERE pin_id='$pin_id' AND team_status='1'";
				break;
			default:
				$sql = "0";
		}
		
		if ($sql != "0")
		{
			$db->setQuery($sql);
			$res = $db->loadAssocList();
			return count($res);
		} else {
			return "0";
		}
	}
	
	function get_team_all()
	{
		$db = &JFactory::getDBO();
		$query = "SELECT M.*, C.*, E.*    	         
    	          		FROM #__phpin AS M
						RIGHT JOIN #__phteam AS E
						ON M.pin_id = E.pin_id
						RIGHT JOIN #__phcategory AS C
						ON C.cat_id = E.cat_id
						WHERE M.pin_status='1'
						AND E.team_status = '1'
                  		ORDER BY M.name ASC";
    	    	
    	$db->setQuery($query);
        $res = $db->loadAssocList();
        return $res;
	}
	
	function array_category()
	{
		$db = &JFactory::getDBO();
		$query = "SELECT * FROM #__phcategory";
    	    	
    	$db->setQuery($query);
        $res = $db->loadAssocList();
        $result = array();
        foreach($res as $row)
        {
        	$result[strtoupper($row['cat_id'])] = $row['cat_name'];
        }
        return $result;
	}
	
	function array_price()
	{
		$db = &JFactory::getDBO();
		$query = "SELECT * FROM #__phcategory";
    	    	
    	$db->setQuery($query);
        $res = $db->loadAssocList();
        $result = array();
        foreach($res as $row)
        {
        	$result[strtoupper($row['cat_id'])] = $row['cat_price_myr'];
        }
        return $result;
	}
	
}
?>