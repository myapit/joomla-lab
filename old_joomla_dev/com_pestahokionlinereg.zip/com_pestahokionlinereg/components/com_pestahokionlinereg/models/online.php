<?php

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

      //pestahokionlineregModelOnlinesystem 
class PestahokionlineregModelOnline extends JModel 
{
	
	function __construct()
	{	
	}
	
	
	function get_team_fullinfo($pinid, $teamid)
	{
		$db = &JFactory::getDBO();
    	$query = "SELECT T.*, M.*, C.*, E.*    	         
    	          FROM #__phtransaction AS T
    	          
    	          	RIGHT JOIN #__phpin AS M
					ON T.pin_id = M.pin_id
					
					RIGHT JOIN #__phteam AS E
					ON T.pin_id = M.pin_id
					
					RIGHT JOIN #__phcategory AS C
					ON C.cat_id = E.cat_id
                  
                  WHERE T.pin_id = '".$pinid."' AND E.team_id='".$teamid."'";
    	
    	    	$query = "SELECT M.*, C.*, E.*    	         
    	          		FROM #__phpin AS M
						RIGHT JOIN #__phteam AS E
						ON M.pin_id = E.pin_id
						RIGHT JOIN #__phcategory AS C
						ON C.cat_id = E.cat_id
                  		WHERE M.pin_id = '".$pinid."' 
                  		AND E.team_id='".$teamid."'";
    	    	
    	$db->setQuery($query);
        $res = $db->loadAssocList();
        return $res;
	}
	
	function get_info($pin)
	{
		$db = & JFactory::getDBO();
    	$db->setQuery("select * from #__phpin where pin_id = '".$pin."'");
        $res = $db->loadAssocList();
        return $res;
	}
	
	function get_team($pin)
	{
		$db = &JFactory::getDBO();
    	$query = "SELECT a.*, b.*    	         
    	          FROM #__phteam AS a
                  Left Join #__phcategory AS b
                  ON a.cat_id=b.cat_id
                  WHERE a.pin_id = '".$pin."' AND team_status='1'";
    	$db->setQuery($query);
        $res = $db->loadAssocList();
        //$res = $query;
        return $res;
	}
	
	function check_pay($id, $pinid)
	{
		$db = & JFactory::getDBO();
		$sql = "SELECT * FROM #__phpayment WHERE team_id='".$id."' AND pin_id='".$pinid."'";
		$db->setQuery($sql);
		$res = $db->loadAssocList();
		return $res;
		
	}
	function get_category($type="all")
	{
		$db = &JFactory::getDBO();
		if ($type == "all") 
		{
			$query = "select * from #__phcategory";
		} else {
			$query = "SELECT C.*, COUNT(T.cat_id) AS maxcount  
			FROM #__phcategory AS C 
			LEFT JOIN (SELECT * from #__phteam where team_status='1') AS T 
			ON C.cat_id = T.cat_id  
			GROUP BY C.cat_id
			ORDER BY C.cat_auto ASC";
		}
		$db->setQuery($query);
		$res = $db->loadAssocList();
		
		if ($type != "all") 
		{
			$data = array();			
			foreach ($res as $row)
			{
				$max = $row['maxcount'];
				$limit = $row['cat_limit'];
				$std = array();
				 
				$std['cat_name']      = $row['cat_name'];
				$std['cat_price_myr'] = $row['cat_price_myr'];
				$std['cat_price_usd'] = $row['cat_price_usd'];
				$std['cat_limit']     = $row['cat_limit'];
				$std['cat_status']    = $row['cat_status'];
				$std['cat_log']       = $row['cat_log'];
				
				if (  $max < $limit )
				{
					$std['cat_id']        = $row['cat_id'];  
					$std['cat_full']      = "";					
				}else{
					$std['cat_id']        = ""; 
					$std['cat_full']      = " FULL ->";
				}
				$data[] = $std;
			}
			return $data;
		} else {		
			return $res;
		}
	}
	
	function clear_session()
	{
		$session = JFactory::getSession();
		$session->clear('PIN');
		$session->clear('NAME');
		$session->clear('EMAIL');
		return true;
	}
	
	
	function save_new_team()
	{
		$team_name = JString::strtoupper(JRequest::getString("team_name",null,'POST'));
		$team_cat  = JString::strtoupper(JRequest::getCmd("team_category",null,'POST'));
		$db = &JFactory::getDBO();
				
		$model =& JModel::getInstance( 'general', 'PestahokionlineregModel' );	
		$gen_id = $model->gen_md5();
		$session = JFactory::getSession();
		$pin = $session->get('PIN');
		
		$sql = "SELECT COUNT(team_id) AS maxteam FROM #__phteam WHERE cat_id='$team_cat' AND pin_id='$pin' AND team_status='1'";
		$db->setQuery($sql);
		$res = $db->loadAssocList();
		foreach($res as $row);
		$count = $row['maxteam'];
		if ($count>= 2)
		{
			return false;
		}
		
		$data = new stdClass();
        $data->team_id     = $gen_id;
        $data->team_name   = $team_name;
        $data->cat_id      = $team_cat;
        $data->pin_id      = $session->get('PIN');
        $data->team_status = '1';
        $data->team_log    = date("Y-m-d H:i:s")."|".$_SERVER['REMOTE_ADDR']."|".$_SERVER['HTTP_USER_AGENT'];

        $db = &JFactory::getDBO();       
        $simpan = $db->insertObject( '#__phteam', $data);
        if ($simpan)
        {
        	return true;
        }else{
        	return false;
        }
	}
	
	function save_transaction($obj_trans)
	{
		$db = & JFactory::getDBO();
				
		if (is_object($obj_trans))
		{
			$sql = "SELECT COUNT(team_id) AS JUM FROM #__phtransaction 
					WHERE team_id='".$obj_trans->team_id."' AND pin_id = '".$obj_trans->pin_id."' LIMIT 1";
			$db->setQuery($sql);
			$res = $db->loadAssocList();
			foreach($res as $row);
			$count = $row['JUM'];
			
			if ($count == '0')
			{
				$simpan = $db->insertObject('#__phtransaction', $obj_trans);
			}
			
			if ($simpan)
			{
				$phteam = new stdClass();
				$phteam->team_id = $obj_trans->team_id;
				$phteam->pin_id = $obj_trans->pin_id;
				$phteam->payment = '1';
				
				// $db->updateObject('#__phteam', $phteam, array('team_id', 'pin_id'));
				$sql = "UPDATE #__phteam SET payment = '1' 
						WHERE team_id = '".$phteam->team_id."' AND pin_id ='".$phteam->pin_id."'";
				$db->setQuery($sql);
				$db->query($sql);
				return true;
			} else {
				return false;
			}
		}else{
			return false;
		}
	}
	
	function get_transaction($pinid, $teamid)
	{
		$db = &JFactory::getDBO();
    	$query = "SELECT T.*, M.*, C.*, E.*    	         
    	          FROM #__phtransaction AS T
    	          
    	          	RIGHT JOIN #__phpin AS M
					ON T.pin_id = M.pin_id
					
					RIGHT JOIN #__phteam AS E
					ON T.pin_id = M.pin_id
					
					RIGHT JOIN #__phcategory AS C
					ON C.cat_id = E.cat_id
                  
                  WHERE T.pin_id = '".$pinid."' AND E.team_id='".$teamid."' AND E.payment='1'";
    	
    	$db->setQuery($query);
        $res = $db->loadAssocList();
        return $res;
	}
	
	function assign_transaction($obj_trans)
	{
		$model = & JModel::getInstance('general','PestahokionlineregModel');
		$modelonline = & JModel::getInstance('online','PestahokionlineregModel');
		$modeldefault = & JModel::getInstance('Pestahokionlinereg', 'PestahokionlineregModel');
		
		
		$result_payment = $this->get_info($obj_trans->pin_id);
		foreach($result_payment as $row);
			$trans_name = $row['name'];
			
		$result_detail_team = $this->get_transaction($obj_trans->pin_id, $obj_trans->team_id);
		foreach($result_detail_team as $datarow);
			$trans_team_name = $datarow['team_name'];
			$trans_team_cat = $datarow['cat_name'];
			$trans_team_price = $datarow['cat_price_myr'];
			$trans_date = (string) $datarow['trans_date'];
			
			$trans_desc = $trans_team_name . " - " . $trans_team_cat . " ( RM " . $trans_team_price . " )";	
			
			$trans_managername = $datarow['name'];
			$trans_address = $datarow['address'].", "
        	                            .$datarow['postcode']." "
        	                            .$datarow['town'].", "
        					            .$datarow['state'].","
        					            .$datarow['country'];
			$trans_contact = $datarow['tel_mobile'];
			
			$trans_code = $datarow['trans_approvecode'];
			$trans_status = $datarow['trans_status'];
			$trans_message = $datarow['trans_message'];
			$receipt_num = $datarow['trans_ref1'];
			
		JRequest::setVar('trans_date',  $trans_date);
		JRequest::setVar('trans_received', $trans_name);
		JRequest::setVar('trans_amount', $datarow['trans_amount']);
		JRequest::setVar('trans_desc', $trans_desc);
		
		
		JRequest::setVar('receipt_num', $receipt_num);
		JRequest::setVar('trans_managername', $trans_managername);
		JRequest::setVar('trans_address', $trans_address);
		JRequest::setVar('trans_contact', $trans_contact);
		JRequest::setVar('trans_code', $trans_code);
	}
	
	function get_payment_detail($idteam, $pinid)
	{
		$db = &JFactory::getDBO();
		$query = "SELECT a.*, b.*    	         
    	          FROM #__phteam AS a
                  Left Join #__phcategory AS b
                  ON a.cat_id=b.cat_id
                  WHERE a.pin_id = '".$pinid."' AND a.team_id = '".$idteam."'";
		$db->setQuery($query);
		$res = $db->loadAssocList();
		return $res;
	}

	function remove_team($pin_id, $team_id)
	{
		$db = & JFactory::getDBO();
		$sql = "SELECT COUNT(team_id) FROM #__phteam WHERE pin_id='$pin_id' AND team_id='$team_id'";
		$db->setQuery($sql);
		$db->query($sql);
		if ($db->getNumRows($res) > 0)
		{
			$sql = "UPDATE #__phteam SET team_status = '0' WHERE pin_id='$pin_id' AND team_id='$team_id'";
			$db->setQuery($sql);
			$db->query($sql);
			return true;
		}else{
			return false;
		}
	}
}

?>