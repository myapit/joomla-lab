<?php

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');


class PestahokionlineregModelGeneral extends JModel 
{
	
	function __construct()
	{	
	}
	function validate_email($email)
	{
	    jimport('joomla.mail.helper');
	
	    $valid = true;
	
	     if (!JMailHelper::isEmailAddress($email))
	    {                               
	         $valid = false;           
	    }   
	    return $valid; 
	}
	function generate_autoid()
	{
		$model = JModel::getInstance( 'pestahokionlinereg','PestahokionlineregModel' );
		$autonum = substr('000000' . mt_rand(1, 999999), -6);
		while($model->checkpin($autonum) == true)
		{
			$autonum = substr('000000' . mt_rand(1, 999999), -6);
		}
		return $autonum;
	}
	
	function clear_session()
	{
		$session = JFactory::getSession();
		$session->clear('PIN');
		$session->clear('NAME');
		$session->clear('EMAIL');
		return true;
	}
	
	function gen_md5()
	{
		//$date = new DateTime();
		//$date = $date->getTimestamp();
		//$key = md5($date.substr('000000' . mt_rand(1, 999999), -6));
		//$key = substr('000000' . mt_rand(1, 999999), -6);
		//return substr('000000' . mt_rand(1, time()), -6);
		
		$model = & JModel::getInstance( 'pestahokionlinereg','PestahokionlineregModel' );
		$autonum = substr('000000' . mt_rand(1, time()), -6);
		while($model->checkteam($autonum) == true)
		{
			$autonum = substr('000000' . mt_rand(1, time()), -6);
		}
		return $autonum;
	}
	
	function check_config()
	{
		$current_date = strtotime(date('Y-m-d'));
		$db = & JFactory::getDBO();
		$sql = "SELECT * FROM #__phconfig ORDER BY id ASC";
		$db->setQuery($sql);
		$result = $db->loadObjectList();
		
		$begin  = strtotime($result[0]->cfgvalue);
		$expire = strtotime($result[1]->cfgvalue);
		if ($expire > $current_date)
		{
			return true;
		} else {
			return false;
		}
		
		//die();
		//var_dump($result);
		//return false;
	}
	
	
	function send_email($email, $pin, $name)
	{
		/** SEND EMAIL **/
		$mailer =& JFactory::getMailer();
		
		//SENDER
		//$config =& JFactory::getConfig();
		//$sender = $paramSendFrom;		 
		//$mailer->setSender($sender);
		//$paramSendFrom  = "pestahoki@usm.my";
		//$mailer->setSender($paramSendFrom);
		
		//RECIPIENT
		$recipient = array($email);
 		$mailer->addRecipient($recipient);
 		
 		//SUBJECT
 		$mailSubject  = "PESTA HOKI USM PENANG INTERNATIONAL 2012 - REGISTRATION INFORMATION";
		$mailer->setSubject($mailSubject);
 
 		
 		//BODY
 		$body   = "<p>Thank you for registering with us.<p>"
			    ."<p>Your can now login into system area using the details below :</p>"
			    ."<br/>"
			    ."<p>Name: <strong>".$name."</strong><br/>"	
			    ."Email address : <strong>".$email."</strong><br/>"	
 				."PIN code : <strong>".$pin."</strong></p>"
 				."<br/>"
		    	."<p>Please keep it safe.<br/>
		    	  Use this PIN code to access your information at www.pestahoki.usm.my -> Get Involved -> Team Registration</p>"
		    	."<p>&nbsp;</p>"
		    	."<p>Regards</p>"
		    	."<p>---</p>"
		    	."<p>Secretariat<br/>
					Pesta Hoki USM-Penang International 2012<br/>
					Sports and Recreation Centre<br/>
					Universiti Sains Malaysia<br/>
					11800, Penang, Malaysia<br/>
					Tel : 604-653 3268    Fax : 604-657 0302<br/>
					Email : pestahoki@usm.my<br/>
					Website : www.pestahoki.usm.my</p>";
		$mailer->isHTML(true);
		$mailer->setBody($body);
		
		$send =& $mailer->Send();
		//SEND
		$sendResult = false;		
		
		if ( $send !== true ) {
		   $sendResult = false;
		} else {
		   $sendResult = true;
		}	

		return sendResult;
	}
	
	function send_forgot_email($email, $pin, $name)
	{
		/** SEND EMAIL **/
		$mailer =& JFactory::getMailer();
		
		//SENDER
		//$config =& JFactory::getConfig();
		//$sender = $paramSendFrom;		 
		//$mailer->setSender($sender);
		//$paramSendFrom  = "pestahoki@usm.my";
		//$mailer->setSender($paramSendFrom);
		
		//RECIPIENT
		$recipient = array($email);
 		$mailer->addRecipient($recipient);
 		
 		//SUBJECT
 		$mailSubject  = "PESTA HOKI USM PENANG INTERNATIONAL 2012 - FORGOT PIN";
		$mailer->setSubject($mailSubject);
 
 		
 		//BODY
 		$body   = "<p>Dear ". $name. ",<p>"
			    ."<p>You have requested to recover your PIN code. Please check below your PIN code.</p>"
			    ."<br/>"
			    ."Email address : <strong>".$email."</strong><br/>"	
 				."PIN code : <strong>".$pin."</strong></p>"
 				."<br/>"
		    	."<p>&nbsp;</p>"
		    	."<p>Regards</p>"
		    	."<p>---</p>"
		    	."<p>Secretariat<br/>
					Pesta Hoki USM-Penang International 2012<br/>
					Sports and Recreation Centre<br/>
					Universiti Sains Malaysia<br/>
					11800, Penang, Malaysia<br/>
					Tel : 604-653 3268    Fax : 604-657 0302<br/>
					Email : pestahoki@usm.my<br/>
					Website : www.pestahoki.usm.my</p>";
		$mailer->isHTML(true);
		$mailer->setBody($body);
		
		$send =& $mailer->Send();
		//SEND
		$sendResult = false;		
		
		if ( $send !== true ) {
		   $sendResult = false;
		} else {
		   $sendResult = true;
		}	

		return sendResult;
	}
	
}

?>