<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * pestahoki online reg Component Controller
 * Registered
 * Author
 * Editor
 * Publisher
 * 
 * Manager
 * Administrator
 * Super Administrator
 */
class PestahokionlineregControllerOnlinesystemadmin extends JController 
{	
	private $_arr_level = array(
							'Author',
							'Editor',
							'Publisher',
							'Manager',
							'Administrator',
							'Super Administrator'
						);
					
	function __construct()
	{
		parent::__construct();
		$ctl_user    = JFactory::getUser();
		$ctl_type    = $ctl_user->usertype;
		$var_userid  = $ctl_user->id;
		
		if(!in_array($ctl_type, $this->_arr_level)) 
		{
			$url = JRoute::_('index.php?option=com_user&view=login');
        	$this->setRedirect($url,$msg = '',$msgType = 'message');
        	$this->redirect();
		}
	}
	
	function display() 
	{         
        if( !JRequest::getVar( 'view' )) {
		    JRequest::setVar('view', 'onlinesystemadmin' );
        }
        $model = & JModel::getInstance('onlineadmin', 'PestahokionlineregModel');
        $result = $model->get_team_manager();
        JRequest::setVar('result',$result);
		 parent::display();  	

	}
	
	function view_detail()
	{
		$pin = JRequest::getCmd('id');
        $model =& JModel::getInstance( 'online', 'PestahokionlineregModel' );
		$res = $model->get_info($pin);
        foreach ($res as $row)
        {
        	$arr_data = array();
        	$arr_data['team_manager'] = $row['name'];
        	$arr_data['team_email']   = $row['email'];
        	$arr_data['team_address'] = $row['address'].", "
        	                            .$row['postcode']." "
        	                            .$row['town'].", "
        					            .$row['state'].","
        					            .$row['country'];
        	
        	$arr_data['office'] = $row['tel_office'];
        	$arr_data['mobile'] = $row['tel_mobile'];
        	$arr_data['residence'] = $row['tel_residence'];
        	$arr_data['fax'] =$row['fax'];
        	
        	JRequest::setVar('data', $arr_data);
        }
        
        $res = "";
        $res = $model->get_team($pin);
        JRequest::setVar('data_team', $res); 
        $cat = $model->get_category();
        JRequest::setVar('data_category', $cat);
        /* End */
         JRequest::setVar('layout', 'view_detail' );
		 parent::display();  	
		
	}
	
	
	function paid()
	{
		$this->__process();
	}
	
	
	function __process()
	{
		$model = & JModel::getInstance('general','PestahokionlineregModel');
		$modelonline = & JModel::getInstance('online','PestahokionlineregModel');
		$modeldefault = & JModel::getInstance('Pestahokionlinereg', 'PestahokionlineregModel');

		$id = JRequest::getCmd('id', null, 'GET');
		$id = base64_decode($id);
		$id = explode("|",$id);
		
		$pinid = $id[0];
		$teamid= $id[1];

		$prince = $id[2];
		
		$ctl_user    = JFactory::getUser();
		$user_name   = $ctl_user->name;
		$ctl_type    = $ctl_user->usertype;
		$var_userid  = $ctl_user->id;


		$trans = new stdClass();
		$trans->trans_id = $model->gen_md5();
		$trans->team_id = $teamid;
		$trans->pin_id = $pinid;
		$trans->trans_approvecode = "N/A (MONEY ORDER/POSTAL ORDER/BANK CHEQUE)"; //trans code receipt
		$trans->trans_ref1 = $trans->trans_id;
		$trans->trans_epnum = "N/A";;
		$trans->trans_amount = $prince;
		$trans->trans_status ="MONEY ORDER/POSTAL ORDER/BANK CHEQUE";
		$trans->trans_message = "MONEY ORDER/POSTAL ORDER/BANK CHEQUE";
		$trans->trans_date = date("Y-m-d H:i:s");
		$trans->trans_log = date("Y-m-d H:i:s")."|".$_SERVER['REMOTE_ADDR'] . "|" . $user_name;
		
		$modelonline->save_transaction($trans);
		
		$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystemadmin&task=view_detail&id='.$pinid);
        $this->setRedirect($url,$msg = 'Status Changed',$msgType = 'message');
        $this->redirect();
				
	}
	
	function output_excel()
	{
		$model = & JModel::getInstance('onlineadmin','PestahokionlineregModel');
		
		$result = $model->get_team_all();
		
		$category = $model->array_category();
		$price = $model->array_price();
		
		
		JRequest::setVar('category', $category);
		JRequest::setVar('price', $price);
		JRequest::setVar('result', $result);
		JRequest::setVar('layout', 'excel_format' );
		parent::display();
	}
}
?>