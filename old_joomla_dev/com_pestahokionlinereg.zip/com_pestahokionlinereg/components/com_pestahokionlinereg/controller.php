<?php
/**
 * Joomla! 1.5 component pestahoki online reg
 *
 * @version $Id: controller.php 2012-06-12 02:29:36 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage pestahoki online reg
 * @license GNU/GPL
 *
 * Pestahoki USM online registration
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * pestahoki online reg Component Controller
 */
class PestahokionlineregController extends JController 
{	
	function display() {
        // Make sure we have a default view
        if( !JRequest::getVar( 'view' )) {
		    JRequest::setVar('view', 'pestahokionlinereg' );
        }
        if (JRequest::getCmd('validate', null, 'POST'))
        {
        	$pincode = JRequest::getCmd('pin', null, 'POST');
        	$proceed = false;
        	$model = $this->getModel('Pestahokionlinereg');
        	if (isset($pincode)  && strlen($pincode) > 6)
        	{
        		JFactory::getApplication()->enqueueMessage( JText::_( 'Some error occurred' ), 'error' );
        		
        		JRequest::setVar('view', 'pestahokionlinereg' );
        		JError::raiseNotice('100', 'Invalid PIN code. Try again._');
        		$proceed = false;	
        		 parent::display();
        	}else{
        		if ($model->checkpin($pincode)==true)
        		{
        			$session = & JFactory::getSession();
        			$session->set('PIN', $pincode);
        			$session->set('VALIDATE', TRUE);
        			$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=font');
        			$this->setRedirect($url,$msg = '',$msgType = 'message');
        			$this->redirect();
        			$proceed = true;	       			
        		}else{
        			JRequest::setVar('view', 'pestahokionlinereg' );
        			JError::raiseNotice('100','Invalid PIN code. Try again.--');
        			parent::display();
        		}
        	}
        }else{
        	$session = & JFactory::getSession();
        	$check_pin = $session->get('PIN');
        	if ( $check_pin && !empty($check_pin) && !is_null($check_pin) )
        	{
        		$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=font');
        		$this->setRedirect($url,$msg = '',$msgType = 'message');
        		$this->redirect();
        	}
        	 parent::display();
        }
	}
	
	function register2()
	{
		$config = & JModel::getInstance('general','PestahokionlineregModel');
		if ( $config->check_config() == false)
		{
			$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=closed');
			$this->setRedirect($url,$msg = '',$msgType = 'message');
			$this->redirect();	
		}
		
		JRequest::setVar('layout','term_of_service');
		parent::display();
	}
	function register()
	{
		$config = & JModel::getInstance('general','PestahokionlineregModel');
		if ( $config->check_config() == false)
		{
			$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=closed');
			$this->setRedirect($url,$msg = 'Registration Closed',$msgType = 'message');
			$this->redirect();	
		}
		
		$session = JFactory::getSession();
		if (JRequest::getVar("submit",null, 'POST'))
		{
			$model = $this->getModel('Pestahokionlinereg');
			$status = $model->save_account();
			$number = $session->get("PIN");
			$name = $session->get("NAME");
			$email = $session->get("EMAIL");			
			//$session->clear('PIN');
			if ($status=="success")
			{
				$items_model =& JModel::getInstance( 'general', 'PestahokionlineregModel' );
				JRequest::setVar('PIN', $number);
				JRequest::setVar('NAME', $name);
				JRequest::setVar('EMAIL', $email);
				JRequest::setVar('layout','register_success');	
				$items_model->send_email($email, $number, $name);
				parent::display();
				$items_model->clear_session();
			}else if ($status == "failed") {
				//JError::customErrorHandler("1","Failed" );
				JRequest::setVar('layout','register_failed');
				parent::display();
			}else if ($status == "email") {
				//JError::customErrorHandler("1","Failed" );
				JRequest::setVar('layout','register');
				JError::raiseWarning('200', 'Invalid email format');
				parent::display();	
			} else {
				JRequest::setVar('layout','register');
				JError::raiseWarning('200', 'Please fill '.$status);
				parent::display();	
			}
		} else {
			JRequest::setVar('layout','register');
			parent::display();
		}
	}
	
	function forgot()
	{
		$model = $this->getModel('Pestahokionlinereg');
		if (JRequest::getVar("submit_forgot",null, 'POST'))
		{
			$email = JString::strtolower(JRequest::getString("email_forgot",null,'POST'));
			if ($model->checkemail($email) == true)
			{
				$items_model =& JModel::getInstance( 'general', 'PestahokionlineregModel' );
				$get_basic_info = $model->get_basic_info($email);
				if ($get_basic_info == true)
				{
					$name = $model->_name;
					$pin = $model->_pincode;
					$items_model->send_forgot_email($email, $pin, $name);
					$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');
        			$this->setRedirect($url,$msg = 'Email send.',$msgType = 'message');
        			$this->redirect();	
				} else {
					// something wrong, this should not happen becoz email already validate above.
				}
				
			}else{
				
				JRequest::setVar('layout','forgot');
				JError::raiseWarning('200','E-mail invalid.');
				parent::display();
			}
		}else{
			JRequest::setVar('layout','forgot');
			parent::display();
		}		
	}
	
	/*
	 * list team based on PIN granted.
	 */
	function list_team()
	{
		JRequest::setVar( 'layout', 'list_team'  );
		parent::display();
	}
	
	function register_team()
	{
		JRequest::setVar('layout','form_register_team');
		parent::display();
	}
	
	function closed()
	{
		JRequest::setVar('layout','closed');
		parent::display();	
	}
	
	function test()
	{
		JRequest::setVar('PIN', "123456");
		JRequest::setVar('NAME', "MOTOROLA TESTER");
		JRequest::setVar('EMAIL', "TESTER@MOTOR.NET");
		JRequest::setVar('layout','register_success');
		parent::display();		
	}
}
?>