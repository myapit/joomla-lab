<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * pestahoki online reg Component Controller
 */
class PestahokionlineregControllerOnlinesystem extends JController 
{	
	function __construct()
	{
		parent::__construct();

	}
	
	function display() 
	{         
        if( !JRequest::getVar( 'view' )) {
		    JRequest::setVar('view', 'onlinesystem' );
        }
         $sess = & JFactory::getSession();
         if (!$sess->get('PIN'))
         {
         	$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');
        	$this->setRedirect($url,$msg = '',$msgType = 'message');
        	$this->redirect();
         }
        
         /* Begin */
                 $model =& JModel::getInstance( 'online', 'PestahokionlineregModel' );
		//$models = & $this->getModel('online');
	
		$session = JFactory::getSession();
        $res = $model->get_info($session->get('PIN'));
        foreach ($res as $row)
        {
        	$arr_data = array();
        	$arr_data['team_manager'] = $row['name'];
        	$arr_data['team_email']   = $row['email'];
        	$arr_data['team_address'] = $row['address'].", "
        	                            .$row['postcode']." "
        	                            .$row['town'].", "
        					            .$row['state'].","
        					            .$row['country'];
        	
        	$arr_data['office'] = $row['tel_office'];
        	$arr_data['mobile'] = $row['tel_mobile'];
        	$arr_data['residence'] = $row['tel_residence'];
        	$arr_data['fax'] =$row['fax'];
        	
        	JRequest::setVar('data', $arr_data);
        }
        
        $res = "";
        $res = $model->get_team($session->get('PIN'));
        JRequest::setVar('data_team', $res); 
        $cat = $model->get_category("filter");
        JRequest::setVar('data_category', $cat);
        /* End */
		 parent::display();  	

		 //JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print_receipt&type=raw&print=1&tmpl=component&printid='.$id);
	}
	
	function delteam()
	{
		$id = JRequest::getCmd('id', null, 'GET');
		$sess = & JFactory::getSession();
		$pin_id = $sess->get('PIN');
		$model = & JModel::getInstance('online','PestahokionlineregModel');
		if (isset($id) && strlen($id)==6)
		{
			$model->remove_team($pin_id, $id);
		}else{
			JError::raiseNotice(200,'Delete Failed.');
		}
			
			JRequest::setVar('view','onlinesystem');
			parent::display();
	}
	
	function addteam()
	{
		$config = & JModel::getInstance('general','PestahokionlineregModel');
		if ( $config->check_config() == false)
		{
			$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=closed');
			$this->setRedirect($url,$msg = 'Registration Closed.',$msgType = 'message');
			$this->redirect();	
		}	
		
		if (JRequest::getCmd('submit', null, 'POST'))
		{
			$action = JRequest::getCmd('action', null, 'POSTT');
			$team_name = JRequest::getString('team_name', null, 'POST');
			$team_cat  = JRequest::getCmd('team_category', null, 'POST');
			
			if ($action == "save" && !empty($team_name) && !empty($team_cat))
			{
				$model =& JModel::getInstance( 'online', 'PestahokionlineregModel' );
				if ($model->save_new_team() == true)
				{
					$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=font');
        			$this->setRedirect($url,$msg = 'Record Saved.',$msgType = 'message');
        			$this->redirect();
				}else {
					JError::raiseNotice(110,'Maximum 2 Teams Per Category Only.');
					JRequest::setVar('view','onlinesystem');
					parent::display();
				}
				
			}else{
				JError::raiseNotice(100,'Please fill-in all fields.');
				JRequest::setVar('layout', 'addteam' );
				JRequest::setVar('view','onlinesystem');
				parent::display();
			}
		}else{
			JRequest::setVar('layout', 'addteam' );
			JRequest::setVar('view','onlinesystem');
			parent::display();	
		}	
	}
	
	
	function paynow()
	{
		$id = JRequest::getCmd('id', null, 'GET');
		if (!$id || strlen($id)!=6)
		{
			JError::raiseError('304','Forbidden Technique!');
		}else{
			$model = & JModel::getInstance('online','PestahokionlineregModel');
			$sess = & JFactory::getSession();
			$pinid = $sess->get('PIN');
			if ($model->check_pay($id, $pinid))
			{
				JRequest::setVar('layout','alreadypay');
				display::parent();
			}else{
				$res = $model->get_info($pinid);
				foreach ($res as $row)
				{
					$name = $row['name'];
				}
				$result = $model->get_payment_detail($id, $pinid);
				$payment_code = "OTH1006"; // PESTAHOKI CODE
				foreach ($result as $row) {
					//$team_id = $row['team_id'];
					$pin_id = $sess->get('PIN');
					$price = $row['cat_price_myr']; 
				}
				$id_epay = $id.$pin_id;
				$url_payment = "sInvType=$payment_code&strRef1=$id_epay&strRef3=$name&strAmt=$price";
				$url = JRoute::_('https://epayment.usm.my/main/ecom/ecom_session.aspx?'.$url_payment);

				$this->setRedirect($url);
        		$this->redirect();
				//JRequest::setVar('data_payment', $result);
				//JRequest::setVar('layout','paymeny_detail');
				//display::parent();
			}
		}
	}
	
	function process()
	{
		$model = & JModel::getInstance('general','PestahokionlineregModel');
		$modelonline = & JModel::getInstance('online','PestahokionlineregModel');
		$modeldefault = & JModel::getInstance('Pestahokionlinereg', 'PestahokionlineregModel');
		/*IOie2rGdGBqq7hgbqv34icm8ERlzECrP0IX/Yr/%2bFu3CfmVN9VziLQM%2bzBowPXDg/IpItaj7G/shhdrhE2oRaoVnhRSbknUuwd%2bWWpn2jW7I68HuVenE%2brCyuUGFfYTSxiR0qG5x4kn0cjwNKRy7YC3Rd%2bJyNajT%2b5mduyTxFC7HgkG6G0daIAHqTeLwsN/o*/
		/* sInvType=OTH1003&strApprovedCode=791024075562&strRef1=1107191556340286&strEPNum=EP25119&strAmt=0.10&strStatus=TRANSACTION SUCCESSFUL&strMessage=APPROVED
		 *  'sInvType = OTH1003&
            'strApprovedCode = 791024075562&
            'strRef1 = 1107191556340286&
            'strEPNum = EP25119&
            'strAmt=0.10&
            'strStatus=TRANSACTION SUCCESSFUL&
            'strMessage = APPROVED
       */
		
		$id = JRequest::getCmd('id', null, 'GET');
		$id = base64_decode($id);
		$id = explode("&",$id);
		//var_dump($id);
		
		$sInvType   = explode("=", $id[0]);
		$strAppCode = explode("=", $id[1]);
		$strRef1    = explode("=", $id[2]);
		$strEPNum   = explode("=", $id[3]);
		$strAmt     = explode("=", $id[4]);
		$strStatus  = explode("=", $id[5]);
		$strMessage = explode("=", $id[6]);
		
		//$strRef1_ex = explode("|", $strRef1);
		$strRef1_ex = str_split($strRef1[1],6);
		/*
		 * array(7) { [0]=> string(16) "sInvType=OTH1003" 
		 * [1]=> string(28) "strApprovedCode=791024075562" 
		 * [2]=> string(24) "strRef1=1107191556340286" 
		 * [3]=> string(16) "strEPNum=EP25119" 
		 * [4]=> string(11) "strAmt=0.10" 
		 * [5]=> string(32) "strStatus=TRANSACTION SUCCESSFUL" 
		 * [6]=> string(19) "strMessage=APPROVED" } 
		 * */
		
		$trans = new stdClass();
		$trans->trans_id = $model->gen_md5();
		$trans->team_id = $strRef1_ex[0];
		$trans->pin_id = $strRef1_ex[1];
		$trans->trans_approvecode = $strAppCode[1];
		$trans->trans_ref1 = $strRef1[1];
		$trans->trans_epnum = $strEPNum[1];
		$trans->trans_amount = $strAmt[1];
		$trans->trans_status = $strStatus[1];
		$trans->trans_message = $strMessage[1];
		$trans->trans_date = date("Y-m-d H:i:s");
		$trans->trans_log = date("Y-m-d H:i:s")."|".$_SERVER['REMOTE_ADDR'];
		
		$team_pin = base64_encode($trans->pin_id."|".$trans->team_id);
		JRequest::setVar('printid', $team_pin);
				
		switch ($strStatus[1])
		{
			case "TRANSACTION SUCCESSFUL":
			case "0": 				
				JRequest::setVar('layout','payment_success');
				$modelonline->save_transaction($trans);
				$modelonline->assign_transaction($trans);
				break;
				
			default:
				if ($id[0] == "Intruders detected. Decryption Error!!!")
				{
					JRequest::setVar('trans_status', "Intruders detected. Decryption Error!!!");
					JRequest::setVar('trans_message', "Intruders detected. Decryption Error!!!");
				} else {
					JRequest::setVar('trans_status', $trans->trans_status);
					JRequest::setVar('trans_message', $trans->trans_message);
				}
				JRequest::setVar('layout','payment_failed');		
		}
		parent::display();
		
	}
	
	
	function print_receipt()
	{
		$id = JRequest::getCmd('printid');
		
		$id = explode("|", base64_decode($id));
		
		$modelonline = & JModel::getInstance('online','PestahokionlineregModel');
		
		$trans = new stdClass();
		$trans->team_id = $id[1];
		$trans->pin_id = $id[0];
		
		$modelonline->assign_transaction($trans);
		
		JRequest::setVar('layout','recipe');
		parent::display();	
	}
	
	function printdetail()
	{
		$id = JRequest::getCmd('id');
		$id = explode("|",base64_decode($id));
		
		$pinid = $id[0];
		$teamid = $id[1];
		
		$db = & JModel::getInstance('online','PestahokionlineregModel');
		$result = $db->get_team_fullinfo($pinid, $teamid);
		foreach ($result as $row)
        {
        	$arr_data = array();
        	$arr_data['xteam_manager'] = $row['name'];
        	$arr_data['xteam_email']   = $row['email'];
        	$arr_data['xteam_address'] = $row['address'];
        	$arr_data['xpostcode']	  = $row['postcode'];
        	$arr_data['xtown']		  = $row['town'];
        	$arr_data['xstate']        = $row['state'];
        	$arr_data['xcountry']      = $row['country'];
        	
        	/*$arr_data['team_fulladdress'] = $row['address'].", "
        	                            .$row['postcode']." "
        	                            .$row['town'].", "
        					            .$row['state'].","
        					            .$row['country'];*/
        	
        	$arr_data['xoffice']    = $row['tel_office'];
        	$arr_data['xmobile']    = $row['tel_mobile'];
        	$arr_data['xresidence'] = $row['tel_residence'];
        	$arr_data['xfax']       =$row['fax'];
        	
        	$arr_data['xteam_name']     = $row['team_name'];
        	$arr_data['xteam_category'] = $row['cat_name'];
        	$arr_data['xteam_pricemyr'] = $row['cat_price_myr'];
        	$arr_data['xteam_priceusd'] = $row['cat_price_usd'];
        	
        	if ($row['payment'] == '1')
        	{
        		$arr_data['xteam_payment'] = "ePayment";
        	} else {
        		$arr_data['xteam_payment'] = "MONEY ORDER/POSTAL ORDER/BANK CHEQUE";
        	}
        	
        	JRequest::setVar('xdata', $arr_data);
        }
		
		JRequest::setVar('layout','print_detail');
		parent::display();	
	}
	
	function closed()
	{
		JRequest::setVar('layout','closed');
		parent::display();	
	}
	
	function logoff()
	{
		$model =& JModel::getInstance( 'general', 'PestahokionlineregModel' );
		$model->clear_session();
		$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem');
        $this->setRedirect($url,$msg = 'Logoff',$msgType = 'message');
        $this->redirect();
	}
}
?>