<h3>Registration Section - Add New Team</h3>
<script>
function ph_cancel()
{
	window.location.href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=font'); ?>";
}
</script>
<hr/>
<?php $data = JRequest::getVar('data'); ?>
<table width="100%" cellspacing="3" cellpadding="4">
<tr>
	<th>Team Manager's Name</th>
	<td style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_manager']; ?></td>
	<th>E-mail</th>
	<td style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_email']; ?></td>
</tr>
<tr>
	<th>Address</th>
	<td colspan="3" style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_address']; ?></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td colspan="3">
		<table width="100%" cellspacing="2" cellpadding="2">
		<tr>
			<th>Office</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['office'])?'-':$data['office']; ?></td>
			<th>Mobile</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['mobile'])?'-':$data['mobile']; ?></td>
			<th>Residence</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['residence'])?'-':$data['residence']; ?></td>
			<th>Fax</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['fax'])?'-':$data['fax']; ?></td>
		</tr>
		</table>
	</td>
</tr>
</table>

<br/>
<table width="100%" cellspacing="4" cellpadding="4" border="1">
	<thead>
	<tr>
		<th width="2%" style="background-color:#FFE773">No.</th>
		<th style="background-color:#FFE773">Team's Name</th>
		<th style="background-color:#FFE773">Category</th>
		<th style="background-color:#FFE773">Price (RM)</th>
		<th style="background-color:#FFE773">Payment Status &nbsp;&nbsp;| &nbsp;&nbsp; Action</th>
		<th style="background-color:#FFE773">Print Entry Form</th>
	</tr>
	</thead>
	<tbody>
	<?php 
	$counter = 1;
	$data_team = JRequest::getVar('data_team');
	if (!$data_team)
	{
		echo "<tr><td colspan=5> No Record(s)</td></tr>";
	}else{
		foreach ($data_team as $row)
		{
			$team_id = $row['team_id'];
			$pin_id = $row['pin_id'];
			$printid = base64_encode($pin_id . "|" . $team_id);
			
			$url_print = JRoute::_("index.php?options=com_pestahokionlinereg&view=onlinesystem&id=$printid&task=printdetail&type=raw&print=1&tmpl=component");
			$url_print = '<a href="'.$url_print.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow"> Print </a>';
			
			if ($row['payment'] == '1')
			{
				$receipt = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print_receipt&type=raw&print=1&tmpl=component&printid='.$printid);
				//$receipt = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print&id='.$row['team_id']);
				$btn = '<span style="background-color:green; padding:2px; color:white;">PAID</span>';
				$btn .= '&nbsp;&nbsp;| &nbsp;&nbsp;';
				$btn .= '<a href="'.$receipt.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow"> Print Receipt</a>';
			}else{
				$del = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=delteam&id='.$row['team_id']);
				$pay = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=paynow&id='.$row['team_id']);
				$btn = '<span style="background-color:red; padding:2px; color:white;">UNPAID</span>';
				$btn .= ' &nbsp;&nbsp;| &nbsp;&nbsp;<a href="'.$pay.'">Pay Now</a>';
				$btn .= ' &nbsp;&nbsp;| &nbsp;&nbsp;<a href="'.$del.'" onclick="return confirm(\'are you sure to delete this team ?\');"> Delete Team</a>';
			}
		?>
		<tr>
			<td><?php echo $counter; ?>.</td>
			<td><?php echo $row['team_name'];?></td>
			<td><?php echo $row['cat_name'];?></td>
			<td align="center"><?php echo $row['cat_price_myr'];?></td>
			<td>&nbsp;&nbsp;<?php echo $btn;?></td>
			<td>&nbsp;<?php echo $url_print; ?>&nbsp;</td>
		</tr>
		<?php 
		$counter++;
		}
	}
	?>
	</tbody>
</table>


<p>&nbsp;</p>
<blockquote style="background-color:#FFE773">
Maximum two (2) teams per category.
</blockquote>


<form method="post" action="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=addteam'); ?>">
<input type="hidden" name="action" value="save">
<table width="100%" cellpadding="2" cellspacing="2">
<tr>
	<th>Team's Name</th>
	<td><input type="text" name="team_name" value="" size="50" maxlength="15"></td>
</tr>
<tr>
	<th>Category</th>
	<td>
	<select name="team_category" style="font-family:verdana;">
	<option value=""> - Choose -</option>
	<?php 
	  foreach (JRequest::getVar('data_category') as $row)
	  {
	  	if ($row['cat_id']== '1fd4d4ba89460b43afc94752d4a80144' || $row['cat_id']== '6a524ef2a870efaffdb50451db86edca')
	  	{
		  	if (!empty($row['cat_full']))
		  	{
		  		$disable = ' disabled="disabled"';
		  	}else{
		  		$disable ='';
		  	}
		  	
			echo "<option value=\"".$row['cat_id']."\" $disable>". 
		  	$row['cat_full'] ." ".$row['cat_name']." ( RM ".$row['cat_price_myr']." / USD".
		  	$row['cat_price_usd']." )</option>";
	  	}
	  	

	  }
	?>
	</select>
</td>
</tr>
<tr>
	<td></td>
	<td>
		<input onclick="javascript: ph_cancel();" type="button" name="cancel" value="Cancel">
		<input type="submit" name="submit" value="Submit">
	</td>
</tr>
</table>

</form>