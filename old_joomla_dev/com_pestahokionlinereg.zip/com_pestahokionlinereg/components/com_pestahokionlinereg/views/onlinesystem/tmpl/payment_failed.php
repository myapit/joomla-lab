<h3>Payment Failed</h3>
<br/>
<h5>Payment For Pesta Hoki USM-Penang International 2012</h5>

<table cellpadding="4" cellspacing="4" border="0">
<tr>
	<td>Transaction Status</td>
	<td> : <strong><?php echo JRequest::getVar('trans_status'); ?></strong></td>
</tr>
<tr>
	<td>Transaction Message</td>
	<td> : <strong><?php echo JRequest::getVar('trans_message'); ?></strong></td>
</tr>
</table>
<br/>
<div>
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');?>" 
title="Cancel"><span class="icon print">Return</span></a>
</div>
