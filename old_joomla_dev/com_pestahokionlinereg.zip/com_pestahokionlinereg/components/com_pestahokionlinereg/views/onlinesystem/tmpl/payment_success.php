<?php 
$id = JRequest::getVar('printid');

?>
<h3>Registration - Payment Success</h3>
<br/>
<div style="width:600px; float:left; border:solid 1px #CCCCCC;">
<h5>Payment Details</h5>
<table cellpadding="4" cellspacing="4" border="0" width="100%">
<tr>
	<td>Date</td>
	<td><strong><?php echo JRequest::getVar('trans_date'); ?></strong></td>
</tr>
<tr>
	<td>Received From</td>
	<td><strong><?php echo JRequest::getVar('trans_received'); ?></strong></td>
</tr>
<tr>
	<td>Amount</td>
	<td><strong>RM <?php echo JRequest::getVar('trans_amount'); ?></strong></td>
</tr>
<tr>
	<td>Description</td>
	<td><strong><?php echo JRequest::getVar('trans_desc'); ?></strong></td>
</tr>
</table>
</div>

<div style="width:240px; float:left; text-align:center;">
<h5>&nbsp;</h5>

<strong>Please print payment receipt</strong>
<br/>
<br/>
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print_receipt&type=raw&print=1&tmpl=component&printid='.$id);?>" 
title="Print" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no'); return false;"
rel="nofollow"><span class="icon print">Print Receipt</span></a>
<br/><br/>
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');?>" 
title="Cancel"><span class="icon print">Return</span></a>
</div>


