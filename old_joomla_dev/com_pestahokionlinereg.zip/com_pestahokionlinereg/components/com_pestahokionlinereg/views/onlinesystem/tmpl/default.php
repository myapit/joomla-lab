<h3>Registration Section - Team Management</h3>
<?php 
$data = JRequest::getVar('data');
$add_url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=addteam');
$logoff_url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=logoff');

$printid = base64_encode(JRequest::getVar('pin_id'));
$url_print = JRoute::_("index.php?options=com_pestahokionlinereg&view=onlinesystem&id=$printid&task=printdetail&type=raw&print=1&tmpl=component");
$url_print = '<a href="'.$url_print.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow" style="margin-right:10px;background-color:#FFE773;border:solid 2px #cc9900; padding:4px; margin-bottom:5px; font-weight:bold; font-size:12px;"> Print Details</a>';
?>
<hr/>
<div style="text-align: right;">
<a href="<?php echo $logoff_url;?>" style="font-weight:bold; font-size:12px;">&raquo; Log Off</a>
</div>

<table width="100%" cellspacing="3" cellpadding="4">
<tr>
	<th>Team Manager's Name</th>
	<td style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_manager']; ?></td>
	<th>E-mail</th>
	<td style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_email']; ?></td>
</tr>
<tr>
	<th>Address</th>
	<td colspan="3" style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_address']; ?></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td colspan="3">
		<table width="100%" cellspacing="2" cellpadding="2">
		<tr>
			<th>Office</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['office'])?'-':$data['office']; ?></td>
			<th>Mobile</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['mobile'])?'-':$data['mobile']; ?></td>
			<th>Residence</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['residence'])?'-':$data['residence']; ?></td>
			<th>Fax</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['fax'])?'-':$data['fax']; ?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<div>
	<div style="margin-bottom:5px;">
		 
	<?php $url_print; ?>	 
	
	<a href="<?php echo $add_url; ?>"
	style="background-color:#FFE773;border:solid 2px #cc9900; padding:4px; margin-bottom:5px; font-weight:bold; font-size:12px;">
	 Add New Team </a>
	 
	 </div>
	 <br/>
<table width="100%" cellspacing="4" cellpadding="4" border="1">
	<thead>
	<tr>
		<th width="2%" style="background-color:#FFE773">No.</th>
		<th style="background-color:#FFE773">Team's Name</th>
		<th style="background-color:#FFE773">Category</th>
		<th style="background-color:#FFE773">Price (RM)</th>
		<th style="background-color:#FFE773">Payment Status &nbsp;&nbsp;| &nbsp;&nbsp; Action</th>
		<th style="background-color:#FFE773">Print Entry Form</th>
	</tr>
	</thead>
	<tbody>
	<?php 
	$counter = 1;
	$data_team = JRequest::getVar('data_team');
	if (!$data_team)
	{
		echo "<tr><td colspan=5> No Record(s)</td></tr>";
	}else{
		foreach ($data_team as $row)
		{
			$team_id = $row['team_id'];
			$pin_id = $row['pin_id'];
			$printid = base64_encode($pin_id . "|" . $team_id);
			
			$url_print = JRoute::_("index.php?options=com_pestahokionlinereg&view=onlinesystem&id=$printid&task=printdetail&type=raw&print=1&tmpl=component");
			$url_print = '<a href="'.$url_print.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow"> Print </a>';
			
			if ($row['payment'] == '1')
			{
				$receipt = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print_receipt&type=raw&print=1&tmpl=component&printid='.$printid);
				//$receipt = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print&id='.$row['team_id']);
				$btn = '<span style="background-color:green; padding:2px; color:white;">PAID</span>';
				$btn .= '&nbsp;&nbsp;| &nbsp;&nbsp;';
				$btn .= '<a href="'.$receipt.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow"> Print Receipt</a>';
			}else{
				$del = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=delteam&id='.$row['team_id']);
				$pay = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=paynow&id='.$row['team_id']);
				$btn = '<span style="background-color:red; padding:2px; color:white;">UNPAID</span>';
				$btn .= ' &nbsp;&nbsp;| &nbsp;&nbsp;<a href="'.$pay.'">Pay Now</a>';
				$btn .= ' &nbsp;&nbsp;| &nbsp;&nbsp;<a href="'.$del.'" onclick="return confirm(\'are you sure to delete this team ?\');"> Delete Team</a>';
			}
		?>
		<tr>
			<td><?php echo $counter; ?>.</td>
			<td><?php echo $row['team_name'];?></td>
			<td><?php echo $row['cat_name'];?></td>
			<td align="center"><?php echo $row['cat_price_myr'];?></td>
			<td>&nbsp;&nbsp;<?php echo $btn;?></td>
			<td>&nbsp;<?php echo $url_print; ?>&nbsp;</td>
		</tr>
		<?php 
		$counter++;
		}
	}
	?>
	</tbody>
</table>

<br/>
<br/>
<div style="font-family:verdana; font-size:11px;">
<blockquote>Note :</blockquote>
	<ul>
		<li> Click <strong>Add New Team</strong> to add new team.</li>
		<li> Click <strong>Delete Team</strong> to remove current registered team and add new team.</li>
		<li> 
		If you have <span style="background-color:red; padding:2px; color:white;">UNPAID</span>, 
		kindly click <strong>Pay Now</strong> to make online payment.</li>
		<li> 
		The team which have made the payment 
		( <span style="background-color:green; padding:2px; color:white;">PAID</span> )
		 could not remove the team and undo the payment.
		</li>
	</ul>

</div>

</div>


