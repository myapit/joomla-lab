<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PESTA HOKI USM-PENANG INTERNATIONAL 2012</title>
<style type="text/css"> 
<!--
body {
	padding:0px;
	margin:0px;
}

.style7 {
	font-size: 12px;
	font: arial;
}

.print-table {
	font-size:12px;
	font:arial;
}
.gap {
	/*background:url(<?php echo $black; ?>) repeat-x;
	*/height:10px;
}
.gap1 {}

.err {
	display:none; 
	visibility:hidden;
	font-family:Verdana, Geneva, sans-serif;
	font-size:14px;
	font-weight:bold;
	color:#F00; 
	text-align:center; 
	padding:20px; 
	border:solid 1px #F33; 
	background-color:#FCC;
}

.succ {
	display:none; 
	visibility:hidden;
	font-family:Verdana, Geneva, sans-serif;
	font-size:14px;
	font-weight:bold;
	color:#3F0; 
	text-align:center; 
	padding:20px; 
	border:solid 1px #030; 
	background-color:#000;
}
-->
</style>
<script>
function printMe() {
	hideErr();
	hideSuc();
	if(window.print()) {
		showSuc();
	}
}

function hideErr(){
  document.getElementById('error').style.display='none';
	document.getElementById('error').style.visibility='hidden';
}

function showErr() {
  document.getElementById('error').style.display='block';
	document.getElementById('error').style.visibility='visible';
}

function hideSuc() {
	document.getElementById('success').style.display='none';
	document.getElementById('success').style.visibility='hidden';
}

function showSuc() {
	document.getElementById('success').style.display='block';
	document.getElementById('success').style.visibility='visible';

}

function returnHome() {
	window.location='http://www.pestahoki.usm.my/';
}

</script>
</head>
 <?php 
 
$data = JRequest::getVar('xdata');
$add_url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=addteam');
$logoff_url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=logoff');

$printid = base64_encode(JRequest::getVar('pin_id'));
$url_print = JRoute::_("index.php?options=com_pestahokionlinereg&view=onlinesystem&id=$printid&task=printdetail&type=raw&print=1&tmpl=component");
$url_print = '<a href="'.$url_print.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow" style="margin-right:10px;background-color:#FFE773;border:solid 2px #cc9900; padding:4px; margin-bottom:5px; font-weight:bold; font-size:12px;"> Print Details</a>';

$logo = JRoute::_('components/com_pestahokionlinereg/assets/logoph.png');

$logopesta = JRoute::_('components/com_pestahokionlinereg/assets/logopesta.png');
$logomilo = JRoute::_('components/com_pestahokionlinereg/assets/logomilo.png');
$logokpt = JRoute::_('components/com_pestahokionlinereg/assets/loggokpt.png');

$logousm = JRoute::_('components/com_pestahokionlinereg/assets/logousm.png');

$black = JRoute::_('components/com_pestahokionlinereg/assets/bg_black.jpg');
?>
<body onload="window.print();">
<table width="862" border="0" align="center" cellpadding="2" cellspacing="4" class="print-table">
  <tr>
  	<td colspan="4">
  		<table width="100%" cellpadding="0" cellspacing="0">
  			<tr>
  				<td width="25%" align="left">
  					<img style="margin-left:5px;" src="<?php echo $logousm; ?>" height="75" width="150" alt="pestahokilogo"/>
  				</td>
  				<td width="25%" align="center">
  					<img style="margin-left:5px;" src="<?php echo $logokpt; ?>" height="75" width="150" alt="pestahokilogo"/>
  				</td>
  				<td width="25%" align="center">
  					<img style="margin-left:5px;" src="<?php echo $logomilo; ?>" height="75" width="150" alt="pestahokilogo"/>
  				</td>
  				<td width="25%" align="right">
  					<img src="<?php echo $logopesta; ?>" height="75" width="80" alt="pestahokilogo"/>
  				</td>
  			</tr>
  		</table>  		
  	</td>
  </tr>
  <tr>
    <td align="center" style="font-size:14px; color:#000; font-weight:bold;" colspan="4">
    	ENTRY FORM FOR PESTA HOKI USM-PENANG INTERNATIONAL 2012  7<sup>th</sup> - 9<sup>th</sup> DECEMBER 2012    
    </td>  
  </tr>
    <tr>
    <td colspan="4" class="gap"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></td>
  </tr>
  <tr>
    <td width="217"><span class="style7">NAME OF TEAM :</span></td>
    <td colspan="3">&nbsp;<strong><?php echo $data['xteam_name']; ?></strong></td>
  </tr>
  <tr>
    <td><span class="style7">TEAM MANAGER'S NAME :</span></td>
    <td colspan="3">&nbsp;<strong><?php echo $data['xteam_manager']; ?></strong></td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></td>
  </tr>
  <tr>
    <td colspan="4"><span class="style7">CORRESPONDENCE ADDRESS :</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $data['xteam_address']; ?></strong></td>
  </tr>
  <tr>
    <td><span class="style7">POSTCODE :</span></td>
    <td width="224">&nbsp;<strong><?php echo $data['xpostcode']; ?></strong></td>
    <td width="120"><span class="style7">TOWN : </span></td>
    <td width="265">&nbsp;<strong><?php echo $data['xtown']; ?></strong></td>
  </tr>
  <tr>
    <td><span class="style7">STATE:</span></td>
    <td>&nbsp;<strong><?php echo $data['xstate']; ?></strong></td>
    <td><span class="style7">COUNTRY :</span></td>
    <td>&nbsp;<strong><?php echo $data['xcountry']; ?></strong></td>
  </tr>
  <tr>
    <td><span class="style7">EMAIL :</span></td>
    <td colspan="2">&nbsp;<strong><?php echo $data['xteam_email']; ?></strong></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><span class="gap1"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></span></td>
  </tr>
  <tr>
    <td><span class="style7"> CONTACT NUMBERS </span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style7">OFFICE :</span></td>
    <td>&nbsp;<strong><?php echo empty($data['xoffice'])?'-':$data['xoffice']; ?></strong></td>
    <td><span class="style7">MOBILE :</span></td>
    <td>&nbsp;<strong><?php echo empty($data['xmobile'])?'-':$data['xmobile']; ?></strong></td>
  </tr>
  <tr>
    <td><span class="style7">RESIDENCE :</span></td>
    <td>&nbsp;<strong><?php echo empty($data['xresidence'])?'-':$data['xresidence']; ?></strong></td>
    <td><span class="style7">FAX :</span></td>
    <td>&nbsp;<strong><?php echo empty($data['xfax'])?'-':$data['xfax']; ?></strong></td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><span class="gap1"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></span></td>
  </tr>
  <tr>
    <td colspan="4"><span class="style7">CATEGORY : <strong><?php echo $data['xteam_category']; ?> (RM <?php echo $data['xteam_pricemyr']; ?> / USD <?php echo $data['xteam_priceusd']; ?>)</strong></span></td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><span class="gap1"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></span></td>
  </tr>
  <tr>
    <td colspan="2"><span class="style7"> MODE OF PAYMENT : <strong><?php echo $data['xteam_payment']; ?></strong></span></td>
    <td colspan="2"><span class="style7">( PAYABLE TO : ' UNIVERSITI SAINS MALAYSIA ' )</span></td>
  </tr>
	  <tr>
    <td colspan="4"><span class="style7"> CHEQUE /MONEY ORDER NUMBER : <strong>____________________</strong></span></td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><span class="gap1"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></span></td>
  </tr>
  
	
  <tr>
    <td height="20" colspan="4" align="center"><strong>CONFIRMATION BY TEAM MANAGER</strong></td>
  </tr>
  <tr>
    <td colspan="4">
    <div style="padding:2px 12px 2px 12px; text-align:justify;">
    By signing below, I agree to abide by all rules and regulations laid down by the organizing committee of PESTA HOKI USM-PENANG INTERNATIONAL 2012.     I will not hold the organizers, sponsors and Universiti Sains Malaysia responsible for any mishaps that may occur before,during or after the tournament. I also hereby agree to obtain permission from parents/guardians of the participants who are below 18 years of ages. </div>    </td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td align="center" valign="bottom">_______________________________</td>
    <td>&nbsp;</td>
    <td valign="bottom">____________________</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center"><span class="style7">SIGNATURE</span></td>
    <td>&nbsp;</td>
    <td><span class="style7" style="padding-left:50px;">DATE</span></td>
  </tr>
  <tr>
    <td colspan="4"><span class="style7">&nbsp;&nbsp;NAME : <strong><?php echo $data['xteam_manager']; ?></strong></span></td>
  </tr>
  <tr>
    <td colspan="4"><span class="style7">* Identity Card    No./Passport No. :</span></td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><span class="gap1"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></span></td>
  </tr>
  <tr>
    <td height="20" colspan="4" align="center"><strong>CONFIRMATION BY THE ASSOCIATION/INSTITUTION OF HIGHER LEARNING/SCHOOL/CLUB</strong></td>
  </tr>
  <tr>
    <td colspan="4">
    <div style="padding:2px 10px; text-align:center;">
    I Confirm that the team is from this organization and the information given above is true.I agree to the team's participation in the tournament.    </div>    </td>
  </tr>
  <tr>
    <td colspan="2" height="40">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center" valign="top"><span class="style7">Signature    of President/Secretary/ Headmaster/Principal/<br />
    Head of Department
    </span></td>
    <td colspan="2" align="center" valign="top"><span class="style7">Official Stamp Of Organization</span></td>
  </tr>
    <tr>
    <td colspan="2" height="20">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style7">Name:</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style7">*Identity Card No./Passport No.</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style7">Designation:</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" class="gap"><span class="gap1"><img src="<?php echo $black; ?>" height="7" width="862" alt="" /></span></td>
  </tr>
  <tr>
    <td colspan="4" align="center" height="20"><strong>FOR OFFICIAL USE</strong></td>
  </tr>
  <tr>
    <td><span class="style7">Date Received:</span></td>
    <td>&nbsp;</td>
    <td><span class="style7">Confirmed by:</span></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style7">Payment: </span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><span class="style7">*Money Order/Postal    Order/Bank Draft No:</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="4" align="center">
		<!--
		<img src="images/Banerbwh.gif" alt="footer" width="850" height="72"  />
		-->		</td>
  </tr>
</table>
 
</body>
</html>
