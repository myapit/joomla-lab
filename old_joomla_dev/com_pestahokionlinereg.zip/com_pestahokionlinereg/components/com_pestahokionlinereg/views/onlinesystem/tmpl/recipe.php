<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <title>Pesta Hoki USM-Penang International 2012</title>
  <style>

  body { font-family:arial; font-size:11px;}
  </style>
</head>
<body onload="window.print();">

<?php 
$logo = JRoute::_('components/com_pestahokionlinereg/assets/logoph.png');
?>
<table>
  <tr>
    <td>
		<img src="<?php echo $logo; ?>" height="75" width="150">
    </td>
    <td>
   	 <h3>Pesta Hoki USM-Penang International 2012</h3>
    </td>
  </tr>
</table>
<div style="text-align:center;padding-bottom:5px; border-bottom:solid 1px #ccc;"></div>
<br/>
<h4>Payment Receipt</h4>
<table cellpadding="4" cellspacing="4" border="0">
<tr>
	<td valign="top">Receipt Number</td>
	<td><strong> : <?php echo JRequest::getVar('receipt_num'); ?></strong></td>
</tr>
<tr>
	<td valign="top">Transaction Code</td>
	<td><strong> : <?php echo JRequest::getVar('trans_code'); ?></strong></td>
</tr>
<tr>
	<td valign="top">Transaction Date</td>
	<td><strong> : <?php echo JRequest::getVar('trans_date'); ?></strong></td>
</tr>
<tr>
	<td valign="top">Description</td>
	<td><strong> : <?php echo JRequest::getVar('trans_desc'); ?></strong><br/>
	</td>
</tr>
<tr>
	<td valign="top">Amount</td>
	<td><strong> : RM <?php echo JRequest::getVar('trans_amount'); ?></strong></td>
</tr>
<tr>
	<td valign="top">Received From</td>
	<td> <strong> : <?php echo JRequest::getVar('trans_received'); ?></strong>		
		<div style="fon-size:11px;">
		<?php  JRequest::getVar('trans_managername'); ?>
		&nbsp;&nbsp;<?php echo JRequest::getVar('trans_address'); ?><br/>
		&nbsp;&nbsp;<?php echo JRequest::getVar('trans_contact'); ?>
		</div>
	</td>
</tr>
</table>

<br/>
<br/>

<div style="font-size:11px; font-family:verdana;">
Note: <i>This receipt is computer generated and no signature is required.</i>
</div>

<div style="text-align:center; border-bottom:solid 1px #CCCCCC;">&nbsp;</div>

<div style="font-size:9px; font-family:verdana; text-align:center;">
Secretariat, 
Pesta Hoki USM-Penang International 2012, 
Sports and Recreation Centre,<br/> 
Universiti Sains Malaysia
11800, Penang, Malaysia<br/>
Tel : 604-653 3268 / 6014-905 5040 / 6016-457 3120
Fax : 604-657 0302<br/>
Email : pestahoki@usm.my     Website : www.pestahoki.usm.my
</div>
</body>
</html>