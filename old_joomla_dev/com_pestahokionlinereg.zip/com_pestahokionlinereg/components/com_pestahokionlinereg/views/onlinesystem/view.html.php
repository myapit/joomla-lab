<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the pestahoki online reg component
 */
class PestahokionlineregViewOnlinesystem extends JView 
{
	function display($tpl = null) 
	{
        
		$model =& JModel::getInstance( 'online', 'PestahokionlineregModel' );
		//$models = & $this->getModel('online');
	
		$session = JFactory::getSession();
        $res = $model->get_info($session->get('PIN'));
        foreach ($res as $row)
        {
        	$arr_data = array();
        	$arr_data['team_manager'] = $row['name'];
        	$arr_data['team_email']   = $row['email'];
        	$arr_data['team_address'] = $row['address'].", "
        	                            .$row['postcode']." "
        	                            .$row['town'].", "
        					            .$row['state'].","
        					            .$row['country'];
        	
        	$arr_data['office'] = $row['tel_office'];
        	$arr_data['mobile'] = $row['tel_mobile'];
        	$arr_data['residence'] = $row['tel_residence'];
        	$arr_data['fax'] =$row['fax'];
        	
        	JRequest::setVar('data', $arr_data);
        }
        
        $res = "";
        $res = $model->get_team($session->get('PIN'));
        JRequest::setVar('data_team', $res); 
        $cat = $model->get_category("filter");
        JRequest::setVar('data_category', $cat);
        
        JRequest::setVar('pin_id',$session->get('PIN') );
                
        
        parent::display($tpl);
    }
}
?>