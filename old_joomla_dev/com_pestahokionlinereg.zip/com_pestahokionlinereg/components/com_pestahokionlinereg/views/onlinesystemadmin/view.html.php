<?php

defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the pestahoki online reg component
 */
class PestahokionlineregViewOnlinesystemadmin extends JView {
	function display($tpl = null) {
        parent::display($tpl);
    }
}
?>