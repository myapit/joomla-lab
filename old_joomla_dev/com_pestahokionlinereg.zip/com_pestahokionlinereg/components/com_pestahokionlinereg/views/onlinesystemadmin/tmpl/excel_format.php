<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=output.xls");
$result  = JRequest::getVar('result');

$category = JRequest::getVar('category');
$price = JRequest::getVar('price');

?>
<table border="1">
<tr>
	<th>No.</th>
	<th>Team Manager</th>
	<th>Email</th>
	<th>Address</th>
	<th>Office</th>
	<th>Mobile</th>
	<th>Residence</th>
	<th>Fax</th>
	<th>Team Name</th>
	<th>Category</th>
	<th>Price(RM)</th>
	<th>Payment Status</th>
</tr>
<?php 
$count = 1;
foreach ($result as $row)
{
?>
<tr>
	<td><?php echo $count; ?></td>
	<td><?php echo $row['name'];?></td>
	<td><?php echo $row['email'];?></td>
	<td><?php echo $row['address'].",".$row['postcode'].",".$row['town'].",".$row['state'].",".$row['country']; ?></td>
	<td><?php echo empty($row['tel_office'])?'-':$row['tel_office']; ?></td>
	<td><?php echo empty($row['tel_mobile'])?'-':$row['tel_mobile']; ?></td>
	<td><?php echo empty($row['tel_residence'])?'-':$row['tel_residence']; ?></td>
	<td><?php echo empty($row['fax'])?'-':$row['fax']; ?></td>
	<td><?php echo $row['team_name'];?></td>
	<td><?php echo $category[$row['cat_id']];?></td>
	<td><?php echo $price[$row['cat_id']];?></td>
	<td><?php echo ($row['payment']=='1')?'PAID':'UNPAID'; ?></td>
</tr>
<?php  
++$count;
} 
?>
</table>