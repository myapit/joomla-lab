<h3>Registration Section - Team Management</h3>
<?php 
$data = JRequest::getVar('data');
?>
<hr/>

<table width="100%" cellspacing="3" cellpadding="4">
<tr>
	<th>Team Manager's Name</th>
	<td style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_manager']; ?></td>
	<th>E-mail</th>
	<td style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_email']; ?></td>
</tr>
<tr>
	<th>Address</th>
	<td colspan="3" style="border-bottom:solid 1px #ccc;">  <?php echo $data['team_address']; ?></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td colspan="3">
		<table width="100%" cellspacing="2" cellpadding="2">
		<tr>
			<th>Office</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['office'])?'-':$data['office']; ?></td>
			<th>Mobile</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['mobile'])?'-':$data['mobile']; ?></td>
			<th>Residence</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['residence'])?'-':$data['residence']; ?></td>
			<th>Fax</th>
			<td style="border-bottom:solid 1px #ccc;"><?php echo empty($data['fax'])?'-':$data['fax']; ?></td>
		</tr>
		</table>
	</td>
</tr>
</table>
<div>

	 <br/>
<table width="100%" cellspacing="4" cellpadding="4" border="1">
	<thead>
	<tr>
		<th width="2%" style="background-color:#FFE773">No.</th>
		<th style="background-color:#FFE773">Team's Name</th>
		<th style="background-color:#FFE773">Category</th>
		<th style="background-color:#FFE773">Price (RM)</th>
		<th style="background-color:#FFE773">Payment Status</th>
	</tr>
	</thead>
	<tbody>
	<?php 
	$counter = 1;
	$data_team = JRequest::getVar('data_team');
	if (!$data_team)
	{
		echo "<tr><td colspan=5> No Record(s)</td></tr>";
	}else{
		foreach ($data_team as $row)
		{
			$team_id = $row['team_id'];
			$pin_id = $row['pin_id'];
			$price = $row['cat_price_myr'];
			$printid = base64_encode($pin_id . "|" . $team_id . "|".$price);
			if ($row['payment'] == '1')
			{
				$team_id = $row['team_id'];
				$pin_id = $row['pin_id'];
				$printid = base64_encode($pin_id . "|" . $team_id);
				$receipt = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print_receipt&type=raw&print=1&tmpl=component&printid='.$printid);
				//$receipt = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=print&id='.$row['team_id']);
				$btn = '<span style="background-color:green; padding:2px; color:white;">PAID</span>';
				$btn .= '&nbsp;&nbsp;| &nbsp;&nbsp;';
				$btn .= '<a href="'.$receipt.'" title="Print" onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no\'); return false;"
rel="nofollow"> Print Receipt</a>';
			}else{
				$topaid= JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystemadmin&task=paid&id='.$printid);
				//$pay = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystem&task=paynow&id='.$row['team_id']);
				$btn = '<span style="background-color:red; padding:2px; color:white;">UNPAID</span>';
				//$btn .= ' &nbsp;&nbsp;| &nbsp;&nbsp;<a href="'.$pay.'">Pay Now</a>';
				$btn .= ' &nbsp;&nbsp;| &nbsp;&nbsp;<a href="'.$topaid.'" onclick="return confirm(\'Are you sure to change status to PAID ?\');"> CHANGE TO PAID</a>';
			}
		?>
		<tr>
			<td><?php echo $counter; ?>.</td>
			<td><?php echo $row['team_name'];?></td>
			<td><?php echo $row['cat_name'];?></td>
			<td align="center"><?php echo $row['cat_price_myr'];?></td>
			<td>&nbsp;&nbsp;<?php echo $btn;?></td>
		</tr>
		<?php 
		$counter++;
		}
	}
	?>
	</tbody>
</table>


</div>


