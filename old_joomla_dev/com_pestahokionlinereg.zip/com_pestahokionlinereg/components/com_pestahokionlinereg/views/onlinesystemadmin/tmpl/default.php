<h2>Secretariat Section</h2>
<p>
<a target="_kosong" href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystemadmin&task=output_excel&type=raw&print=1&tmpl=component'); ?>">Output To Excel</a>
</p>
<table cellpadding="2" cellspacing="2" width="100%" border="1">
	<tr style="background-color:#FFE773;border:solid 2px #cc9900; padding:4px; margin-bottom:5px; font-weight:bold; font-size:12px;">
		<td>No.</td>
		<td style="white-space: wrap">Team manager</td>
		<td style="white-space: nowrap">Email</td>
		<td style="white-space: wrap">Address</td>
		<td style="white-space: nowrap" colspan="3">Status</td>
		<td style="white-space: nowrap">[ Actions ]</td>
	</tr>
	<?php 
	$count = 1;
	$result = JRequest::getVar('result');

	foreach($result as $row)
	{
		$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=onlinesystemadmin&task=view_detail&id='.$row['pin_id']);
		
		$model = & JModel::getInstance('onlineadmin', 'PestahokionlineregModel');
        $result = $model->get_team_manager();
        
        $team = $model->getnum('team', $row['pin_id']);
        $paid = $model->getnum('paid', $row['pin_id']);
        $unpaid = $model->getnum('unpaid', $row['pin_id']);
        
		echo "<tr>";
		echo "<td valign=top>$count</td>";
		echo "<td valign=top>". $row['name'] ."</td>";
		echo "<td valign=top>". $row['email'] ."</td>";
		echo "<td valign=top>". $row['address'] ."</td>";
		echo "<td style=\"white-space: nowrap\"> TEAM ( <span style='color:blue'>". $team ."</span> )
			</td><td style=\"white-space: nowrap\">
		  PAID ( <span style='color:green'>". $paid ."</span> )</td><td style=\"white-space: nowrap\">
		 UPAID ( <span style='color:red'>". $unpaid ."</span> )</td>";
		echo "<td><a href=\"". $url ."\">View Detail</a></td>";
		echo "</tr>";
		++$count;
	}
	?>
</table>