<h3>Registration Section - Team Information</h3>
<div style="background-color:#FFC373; padding:5px;">
This is one-time submission form , any changes can be made via secretariat only. <br/>
<span style="color:red; font-weight:bold;">* </span> Compulsory Field
</div>
<form id="registration" name="registration"
method="post" 
action="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=register'); ?>">


<input style="text-transform:uppercase"  type="hidden" name="action" value="save">

<table width="100%" cellspacing="4" cellpadding="4">
<tr>
	<td>Team Manager's Name</td>
	<td> <input style="text-transform:uppercase"  type="text" name="name" value="<?php echo @JRequest::getString('name'); ?>" size="60" maxlength="200"> <span style="color:red; font-weight:bold;">*</span>  </td>
</tr>
<tr>
	<td>E-mail</td>
	<td> <input style="text-transform:lowercase"  type="text" name="email" value="<?php echo @JRequest::getString('email'); ?>" size="40" maxlength="150"> <span style="color:red; font-weight:bold;">*</span> </td>
</tr>
<tr>
	<th colspan=2" style="background-color:#FF9900;">Correspondence Address</th>
</tr>
<tr>
	<td>Address</td>
	<td><input style="text-transform:uppercase"  type="text" name="address" id="address" size="60" maxlength="200" value="<?php echo @JRequest::getString('address'); ?>"> <span style="color:red; font-weight:bold;">*</span> </td>
</tr>
<tr>
	<td>Postcode</td>
	<td><input style="text-transform:uppercase;"  type="text" name="postcode" id="postcode" size="30" maxlength="10" value="<?php echo @JRequest::getString('postcode'); ?>"> 
	<small>Number only</small>
	<span style="color:red; font-weight:bold;">*</span> </td>
</tr>
<tr>
	<td>Town</td>
	<td><input style="text-transform:uppercase"  type="text" name="town" id="town" size="30" maxlength="50" value="<?php echo @JRequest::getString('town'); ?>"> <span style="color:red; font-weight:bold;">*</span> </td>
</tr>
<tr>
	<td>State</td>
	<td><input style="text-transform:uppercase"  type="text" name="state" id="state" size="30" maxlength="50" value="<?php echo @JRequest::getString('state'); ?>"> <span style="color:red; font-weight:bold;">*</span> </td>
</tr>
<tr>
	<td>Country</td>
	<td><input style="text-transform:uppercase"  type="text" name="country" id="country" size="30" maxlength="50" value="<?php echo @JRequest::getString('country'); ?>"> <span style="color:red; font-weight:bold;">*</span> </td>
</tr>
<tr>
	<th colspan="2" style="background-color:#FF9900;">Contact Number</th>
</tr>
<tr>
	<td>Office</td>
	<td><input style="text-transform:uppercase"  type="text" name="office" id="office" 
	value="<?php echo @JRequest::getString('office'); ?>">
	<small>Number only without "-"</small></td>
</tr>
<tr>
	<td>Mobile</td>
	<td>
	<input style="text-transform:uppercase"  type="text" name="mobile" id="mobile"
	value="<?php echo @JRequest::getString('mobile'); ?>"> 
	<span style="color:red; font-weight:bold;">*</span> 
	<small>Number only without "-"</small></td>
</tr>
<tr>
	<td>Residence</td>
	<td><input style="text-transform:uppercase"  type="text" name="residence" id="residence"
	value="<?php echo @JRequest::getString('residence'); ?>">
	<small>Number only without "-"</small></td>
</tr>
<tr>
	<td>Fax</td>
	<td><input style="text-transform:uppercase"  type="text" name="fax" id="fax"
	value="<?php echo @JRequest::getString('fax'); ?>">
	<small>Number only without "-"</small></td>
</tr>
<tr>
	<td></td>
	<td>
		<input type="submit" name="submit" id="submit" value=" Submit Form" style="padding:5px;">&nbsp;&nbsp;
		<input type="reset" value=" Reset Form "  style="padding:5px;">
		<input type="button" name="cancel" value=" Cancel " style="padding:5px;"
		 onclick="javascript: window.location.href='<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg'); ?>'">
		
	</td>
</tr>
</table>
</form>