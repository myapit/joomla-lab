<h3>Registration Section - Team Information</h3>
<div style="font-size:14px; border:solid 1px #ccc; padding:10px;">
Registration <span style="color:red">Failed.</span> <strong>E-mail already exists.</strong>
<br/>
If you forgot your PIN, 
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=forgot');?>">
 click here </a>.
</div>
<p>
<a href="#" onclick="javascript: history.go(-2);"> Back to form </a>
</p>