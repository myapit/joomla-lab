<?php defined('_JEXEC') or die('Restricted access'); ?>
<h3>Online Registration</h3>

<div style="background-color:#FFC373; width:400px; padding:30px; float: left;">
<h4>Login</h4>
<form method="post" action="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');?>">

		<div style="font-weight:bold;">Enter PIN code to proceed to manage your team</div>
		<input type="text" name="pin" id="pin" style="font-size:16px;" maxlength="6">
		<small>(example : 091211)</small>

		<input type="submit" name="validate" value="Validate PIN" style="display:block; padding:6px; font-wieght:bold;" />
</form>
</div>

<div style="float:right; width:300px;">
<div style="font-size:14px;">
You need to get the PIN code to register and manage your team.
<br/>
<br/>
</div>
<div style="float:left; width:140px; border-right:solid 2px #ccc; padding-right:4px;">
Forgot your PIN code ?
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=forgot');?>"
style="font-size: 12px; padding:5px; font-weight:bold;"> 
click here</a> to get it back.
</div>

<div style="float:right; width:140px; padding-left:4px;">
Don't have PIN code yet ? 
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=register2');?>"
style="font-size: 12px; padding:5px; font-weight:bold;"> 
register here</a>.
</div>

</div>

<div style="clear:both;"></div>
<div style="font-family:verdana; font-size:11px; width:100%;">
<blockquote>Note :</blockquote>
	<ul>
		<li> Step 1: Register as team's manager to get PIN code.</li>
		<li> Step 2: Login using the PIN code to add your team(s).</li>
	</ul>

</div>



<script>
window.onload = function({
	document.getElementById('pin').focus();	
});
</script>