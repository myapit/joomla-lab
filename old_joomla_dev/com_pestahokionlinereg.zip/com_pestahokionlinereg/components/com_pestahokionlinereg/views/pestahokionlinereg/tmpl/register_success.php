<h3>Registration Section - Team Information</h3>
<div style="background-color:green; padding:10px; font-size:14px; color:#fff; font-weight:bold;">
You registration is successful.
</div>
<p style="font-size:14px;">
<br/>
Please KEEP this PIN in secure place, as it is your identification to login to registration system.
</p>

<table cellpadding="4" cellspacing="4" style="font-size:14px; background-color:#FFE773" border="1">
<tr>
	<td>Name</td>
	<td><strong><?php echo JText::_(JRequest::getVar('NAME'));?></strong></td>
</tr>
<tr>
	<td>PIN Code</td>
	<td><strong><?php echo JText::_(JRequest::getVar('PIN'));?></strong></td>
</tr>
<tr>
	<td>Email</td>
	<td><strong><?php echo JText::_(JRequest::getVar('EMAIL'));?></strong></td>
</tr>
</table>
<br/>
<?php 
$url = JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');
?>
<p>
<a style="font-size:13px" href="<?php echo $url; ?>"> Click here to continue </a>.
</p>

<div style="font-family:verdana; font-size:12px;">
<blockquote>Note :</blockquote>
	<ul>
		<li> Please use the <span style="background-color:green; padding:2px; color:white;">PIN CODE</span> to login and 
		<span style="background-color:green; padding:2px; color:white;"> ADD </span> your team(s).</li>

	</ul>

</div>
