<h3>Registration Section - Forgot PIN</h3>
<div style="background-color:#FFC373; width:400px; padding:30px; float: left;">
<div style="font-weight:bold;">
Please enter the email address you used to regsiter your account, and we will send you an email contain PIN code.
</div>
<form name="forgot" method="post" action="">
<input type="text" name="email_forgot" value="" maxlength="250" size="30" style="display:block; padding:6px; font-wieght:bold;">
<input type="submit" name="submit_forgot" value=" Send PIN to my email">
</form>
</div>