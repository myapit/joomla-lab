<h3>Registration - Terms and Conditions</h3>
<!-- BEGIN -->


<strong>PESTA HOKI USM-PENANG INTERNATIONAL 2012<br/>
(7TH - 9TH DECEMBER 2012)</strong><br/>
<br/>
Basic Rule/requirement/Instruction<br/>

<ol>
	<li>Please write in capital letters.<br/><br/></li>

	<li>This form is to be completed by the Manager of the participating team.<br/><br/></li>

	<li>This tournament is open to <strong>all registered hockey teams</strong>. The team should be registered under an 
	established organization such as the <strong>District/State Hockey Association ,PDRM ,ATM, 
	Institution of Higher Learning or Club</strong>.<br/><br/>
	</li>

	<li>The number of players are as follows :-
		<ul>
			<li>8 players per team for all six-a-side men's and boy's categories.</li>
			<li>9 players per team for all seven-a-side women's and girl's categories.</li>
		</ul>
		<br/><br/>
	</li>

	<li>
	Participants' age will be determined as of 1st January 2012
		<ul>
			<li>Under - 12 born on or after 1st January 2000</li>
			<li>Under - 15 born on or after 1st January 1997</li>
			<li>Under - 18 born on or after 1st January 1994</li>
		</ul>
		<br/>
	</li>

	<li>Please be informed that the players must produce the <strong>certified true copy of the
	 Identity Card/Birth Certificate/Passport for Junior Categories</strong>.
	 <br/><br/>
	 </li>

	<li>Name list of players must be handed in on the day of registration. The entry fee must be enclosed 
	with the entry form. Entry fee is not refundable.<br/><br/>
	</li>

	<li>
	<strong>Teams without an affiliation stamp will not be accepted.</strong> For teams from schools,<br/> 
    	colleges or universities the affiliation is done by the Head of Institution or Department.
    <br/><br/>
    	UPON REGISTERING ONLINE, KINDLY PRINT THE FORM AND GET THE AFFILIATION STAMP. <br/>
    	<span style="color:red">THE ENTRY FEE MUST BE ENCLOSED WITH THE ENTRY FORM. ENTRY FEE IS NOT REFUNDABLE.</span><br/>
    	YOUR TEAM(S) IS NOT CONFIRMED UNTIL WE RECEIVE A HARD COPY OF YOUR REGISTRATION FORM <br/>
   	 <span style="color:red">TOGETHER WITH PAYMENT</span> AND WITH AFFILIATION STAMP.<br/>
   	 <span style="color:red">FOR THOSE WHO PAID THROUGH ONLINE PAYMENT,<br/> 
   	 PLEASE ATTACH YOUR PAYMENT SLIP TOGETHER WITH YOUR ENTRY FORM. <br/>
    	FOR THOSE WHO WANT TO PAY BY MONEY ORDER/POSTAL ORDER/BANK CHEQUE, <br/>
    	PLEASE ATTACH YOUR PAYMENT TOGETHER WITH YOUR ENTRY FORM. <br/>
    <br/>
    	REMINDER : MONEY ORDER/POSTAL ORDER/BANK CHEQUE MUST BE PAYABLE TO  'UNIVERSITI SAINS MALAYSIA'</span>
    	<br/><br/>
    </li>

	<li>
	You are allowed to register maximum of 2 teams per category.<br/> 
	However, players are not permitted to play in other team/s in the same category.
	<br/><br/>
	</li>
	
	<li>
	The dateline for the entries with payment is on <strong>15th October 2012</strong>. 
	<span style="color:red">Late registration will not be entertained.</span><br/><br/><br/>
	</li>

</ol>
PLEASE TAKE NOTE THAT, ALL GAMES WILL BE PLAYED ON  FIELD ONLY EXCEPT FOR IPT CATEGORY!
<br/><br/>
For enquiries, please contact : - 
<br/><br/>
THE SECRETARIAT<br/>
PESTA HOKI USM - PENANG INTERNATIONAL 2012<br/>
SPORT OFFICE<br/>
UNIVERSITI SAINS MALAYSIA<br/>
11800 MINDEN, PENANG, MALAYSIA.<br/>
TEL : 604-653 3268 / 3271 / 2133<br/>
FAX : 604-657 0302<br/>
E-MAIL : pestahoki@usm.my<br/>
HP: DHARVIND BALAN (016-645 6842) (ONLY OFFICE HOURS) CALL OR SMS<br/>
WEB : www.pestahoki.usm.my<br/>






<!-- END -->
<div style="font-size:14px; text-align:center; padding-top:5px; padding-bottom:5px; border-bottom:solid 1px #000; border-top:solid 1px #000;">
<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg');?>"
style="font-size: 14px; padding:5px; font-weight:bold;"> 
Cancel</a>

&nbsp;&nbsp;
|
&nbsp;&nbsp;

<a href="<?php echo JRoute::_('index.php?option=com_pestahokionlinereg&view=pestahokionlinereg&task=register');?>"
style="font-size: 14px; padding:5px; font-weight:bold;"> 
PROCEED &raquo;</a>
</div>