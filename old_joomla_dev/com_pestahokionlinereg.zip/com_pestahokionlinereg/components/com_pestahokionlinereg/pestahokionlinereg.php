<?php
/**
 * Joomla! 1.5 component pestahoki online reg
 *
 * @version $Id: pestahokionlinereg.php 2012-06-12 02:29:36 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage pestahoki online reg
 * @license GNU/GPL
 *
 * Pestahoki USM online registration
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';
require_once JPATH_COMPONENT.DS.'onlinesystem.php';
require_once JPATH_COMPONENT.DS.'onlinesystemadmin.php';

$view = JRequest::getVar( 'view' , 'null' );
if ($view !='pestahokionlinereg' )
	$view = $view;
else 
	$view = '';
$controllerClass = 'PestahokionlineregController'.ucfirst($view);
// Initialize the controller
$controller = new $controllerClass; //PestahokionlineregController();
$controller->execute( JRequest::getCmd('task') );

// Redirect if set by the controller
$controller->redirect();
?>