function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      oldonload();
      func();
    }
  }
}

function prepareInputsForHints() {
	var inputs = document.getElementsByTagName("input");
	for (var i=0; i<inputs.length; i++){
		// test to see if the hint span exists first
		if (inputs[i].parentNode.getElementsByTagName("span")[0]) {
			// the span exists!  on focus, show the hint
			inputs[i].onfocus = function () {
				this.parentNode.getElementsByTagName("span")[0].style.display = "block";
			}
			// when the cursor moves away from the field, hide the hint
			inputs[i].onblur = function () {
				this.parentNode.getElementsByTagName("span")[0].style.display = "none";
			}
		}
	}
	// repeat the same tests as above for selects
	var selects = document.getElementsByTagName("select");
	for (var k=0; k<selects.length; k++){
		if (selects[k].parentNode.getElementsByTagName("span")[0]) {
			selects[k].onfocus = function () {
				this.parentNode.getElementsByTagName("span")[0].style.display = "block";
			}
			selects[k].onblur = function () {
				this.parentNode.getElementsByTagName("span")[0].style.display = "none";
			}
		}
	}
}
addLoadEvent(prepareInputsForHints);

function data_change(field)
{
		var check = true;
		var value = field.value; //get characters
		//check that all characters are digits, ., -, or ""
		for(var i=0;i < field.value.length; ++i)
		{
				 var new_key = value.charAt(i); //cycle through characters
				 if(((new_key < "0") || (new_key > "9")) && 
							!(new_key == ""))
				 {
							check = false;
							break;
				 }
		}
		//apply appropriate colour based on value
		if(!check)
		{
				 field.style.backgroundColor = "red";
		}
		else
		{
				 field.style.backgroundColor = "white";
		}
}
		 
		 
function numbersonly(e) {
	var unicode=e.charCode? e.charCode : e.keyCode;
	if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57) //if not a number 
			return false //disable key press
		}
} 

function check_email(str) {	
	var at="@"
	var dot="."
	var lat=str.indexOf(at)
	var lstr=str.length
	var ldot=str.indexOf(dot)
	if (str.indexOf(at)==-1){  return false	}
	if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){  return false	}
	if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){ return false}
	if (str.indexOf(at,(lat+1))!=-1){ return false }
	if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){ return false }
	if (str.indexOf(dot,(lat+2))==-1){ return false }
	if (str.indexOf(" ")!=-1){return false }
	return true					
}
	
function checking() {
	var frm = document.getElementById('registration');
	
	var s;
	s=confirm('Are you sure to submit this form ?');
	alert(s);
	alert(frm.name.value);
	//return false;
	if(s==true){
		var errmsg='';
		/*if(frm.team_name.value=='' || frm.team_name.value == null){
			errmsg += 'Name Of Team\n';
		}*/
			if(frm.name.value=='' || frm.name.value == null){
			errmsg += 'Team Manager Name\n';
		}
		
			if(frm.address.value==''){ errmsg += 'Address\n';}
			if(frm.poscode.value==''){ errmsg += 'Postcode\n';}
			if(frm.country.value==''){ errmsg += 'Country\n';}
			if(frm.email.value==''){ errmsg += 'E-mail\n'; }
			
			if(frm.office.value==''){ errmsg += 'Office Number\n'; }
			if(frm.mobile.value==''){ errmsg += 'Mobile Number\n'; }
			if(frm.fax.value==''){ errmsg += 'Fax Number\n'; }
			if(frm.residence.value==''){ errmsg += 'Residence Number\n'; }	
			
			
			/*if(frm.category.value==''){ errmsg += 'Category\n'; }
			if(frm.payment.value==''){ errmsg += 'Payment Method\n'; }*/
			

				if (check_email(frm.email.value)==false)
				{errmsg += '\nPlease enter valid e-mail address\n(e.g: someone@someone.net)';}
				
			if(errmsg.length != 0){
				var retMsg = 'Please fill-in this field(s):\n' + errmsg;
				alert(retMsg);
				return false;
			}else{
				//if(document.registration.onsubmit())
				 //{
				 	//document.registration.submit();
					//document.getElementById('registration').submit();
				 //}else{
				//	 alert('gila laa');
				 //}
				
				return true;
			}
	}else{
		return false;
	}
}