<?php
/**
 * Joomla! 1.5 component pestahoki online reg
 *
 * @version $Id: pestahokionlinereg.php 2012-06-12 02:29:36 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage pestahoki online reg
 * @license GNU/GPL
 *
 * Pestahoki USM online registration
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport('joomla.application.component.model');

class PestahokionlineregModelPestahokionlinereg extends JModel {
    function __construct() {
		parent::__construct();
    }
}
?>