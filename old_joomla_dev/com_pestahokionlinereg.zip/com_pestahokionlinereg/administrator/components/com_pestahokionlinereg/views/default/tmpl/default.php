<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('pestahoki online reg'), 'generic.png');
JToolBarHelper::preferences('com_pestahokionlinereg');
?>
<!-- Deafult administrator message -->
This is the default administrator view of your component. To edit it please edit the file:<br />
/administrator/components/com_pestahokionlinereg/views/default/tmpl/default.php