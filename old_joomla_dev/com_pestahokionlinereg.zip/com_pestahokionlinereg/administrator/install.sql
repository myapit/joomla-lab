--CREATE TABLE IF  NOT EXISTS `#__phconfig` (
--	`id` SMALLINT NOT NULL AUTO_INCREMENT,
--	`cfgname` VARCHAR(20) NOT NULL,
--	`cfgvalue` VARCHAR(50) NOT NULL,
--	primary key(id)
--);

--DELETE FROM `#__phconfig`;
--INSERT INTO `#__phconfig` (`cfgname`, `cfgvalue`)
--VALUES('BEGIN_REGISTER','2012-07-10'),
--('END_REGISTER', '2012-10-15');

--CREATE TABLE IF NOT EXISTS `#__phpin` (
--  `pin_id` varchar(6) NOT NULL,
--  `email` varchar(50) NOT NULL ,
--  `name` varchar(255) NOT NULL,
--  `address` varchar(255) NOT NULL,
--  `postcode` varchar(10) NOT NULL,
--  `state` varchar(200) NOT NULL,
--  `town` varchar(200) NOT NULL,
--  `country` varchar(50) NOT NULL,
--  `tel_office` varchar(20) NOT NULL,  
--  `tel_mobile` varchar(20) NOT NULL,  
--  `tel_residence` varchar(20) NOT NULL,  
--  `fax` varchar(20) NOT NULL,    
--  `pin_status` enum('0','1') NOT NULL DEFAULT '1',
--  `pin_log` text NULL,
--  primary key (pin_id),
--  UNIQUE (email)
--);

--DROP TABLE IF EXISTS #__phcategory;
--CREATE TABLE IF NOT EXISTS `#__phcategory` (
--	`cat_auto` smallint not null,
--	`cat_id` varchar(32) NOT NULL,
--	`cat_name` varchar(100) NOT NULL,
--	`cat_price_myr` float(6) NOT NULL,
--	`cat_price_usd` float(6) NOT NULL,
--	`cat_limit` int NOT NULL DEFAULT '0',
--	`cat_status` enum('0','1') NOT NULL DEFAULT '1',
--	`cat_log` text NULL,
--	primary key(cat_id)
--);
--delete from `#__phcategory`;
--insert into `#__phcategory` (cat_auto, cat_id,cat_name,cat_price_myr,cat_price_usd,cat_limit,cat_status,cat_log)
--values('1','5226760a62a7571bc16c617e55c1df0c','BOY\'S UNDER - 12','150.00','50.00','26','1',''),
--('2','27e2f989cc3ee281a889418b04edaeaa','GIRL\'S UNDER - 12','150.00','50.00','22','1',''),

--('3','971992cf1ea6132f56e8d5f4c29c2cec','BOY\'S UNDER - 15','200.00','65.00','22','1',''),
--('4','0fa3ed1a548b1b264b9bb13c94f2ab81','GIRL\'S UNDER - 15','200.00','65.00','14','1',''),


--('5','14fdb9d16db3eb2d5d84dcb857463f82','JUNIOR MEN\'S UNDER - 18','200.00','65.00','22','1',''),
--('6','7f1ade799e1044a9ce7691bca6a264ea','JUNIOR WOMEN\'S UNDER - 18','200.00','65.00','14','1',''),

--('7','bce488efbc4ec2c21147bec93e0b5951','INS. OF HIGHER LEARNING - MEN','300.00','95.00','20','1',''),
--('8','dce488efbc4ec2c22157bec93e0b5959','INS. OF HIGHER LEARNING - WOMEN','300.00','95.00','16','1',''),

--('9','6a524ef2a870efaffdb50451db86edca','MEN\'S OPEN','300.00','95.00','72','1',''),
--('10','1fd4d4ba89460b43afc94752d4a80144','WOMEN\'S OPEN','300.00','95.00','32','1','');

--CREATE TABLE IF NOT EXISTS `#__phteam` (
--	`team_id` varchar(32) NOT NULL,
--	`team_name` varchar(100) NOT NULL,--
--	`pin_id` varchar(6) NOT NULL,
--	`cat_id` varchar(32) NOT NULL,
--	`team_status` enum('0','1') NOT NULL DEFAULT '1',
--	`payment` enum('0','1') NOT NULL DEFAULT '0',
--	`team_log` text NULL,
--	primary key(team_id)
--) ;

--CREATE TABLE IF NOT EXISTS `#__phpayment` (
--	`pay_id` varchar(32) NOT NULL,
--	`team_id` varchar(32) NOT NULL,
--	`pay_approve` varchar(200) NOT NULL,
--	`pay_ref1` varchar(200) NOT NULL,
--	`pay_ref2` varchar(200) NOT NULL,
--	`pay_amount` float(6) NOT NULL default '0.00',
--	`pay_getstatus` int NOT NULL default '100',
--	`pay_message` varchar(250) NOT NULL default '',
--	`pay_status` enum('0','1') NOT NULL DEFAULT '1',
--	`pay_log` text NULL,
--	primary key(team_id)
--) ;


--create table if not exists `#__phtransaction` (
--	trans_id varchar(32) not null,
--	team_id varchar(32) NOT NULL,
--	pin_id varchar(6) NOT NULL,
--	trans_approvecode varchar(250) not null,
--	trans_ref1 varchar(250) not null ,
--	trans_epnum varchar(250) not null,
--	trans_amount varchar(10) not null,
--	trans_status varchar(100) not null,
--	trans_message varchar(250) not null,
--	trans_log text null,
--	trans_date datetime not null
--);


