<?php defined('_JEXEC') or die('Restricted access'); ?>
<script language="javascript" type="text/javascript">
<!--
function submitbutton(pressbutton) {
	var form = document.adminForm;
	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}
 
	// do field validation
	<?php
		$editor =& JFactory::getEditor();
	?>
	var text = <?php echo $editor->getContent( 'content' );	?>
	if (form.greeting.value == '') {
		return alert ( "<?php echo JText::_( 'Greeting must have some text', true ); ?>" );
	} else if (text == '') {
		return alert ( "<?php echo JText::_( 'Content must have some text', true ); ?>");
	}
	<?php echo $editor->save( 'content' ); ?>
	submitform(pressbutton);
}
//-->
</script>
 
<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Details' ); ?></legend>
 
		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="greeting">
					<?php echo JText::_( 'Greeting' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="greeting" id="greeting" size="25" maxlength="25" value="<?php echo $this->greeting;?>" />
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="content">
					<?php echo JText::_( 'Content' ); ?>:
				</label>
			</td>
			<td>
				<?php
					$editor =& JFactory::getEditor();
					echo $editor->display('content', $this->content, '550', '400', '60', '20', false);
				?>
			</td>
		</tr>
	</table>
	</fieldset>
</div>
<div class="clr"></div>
 
<input type="hidden" name="option" value="com_hello" />
<input type="hidden" name="id" value="<?php echo $this->id; ?>" />
<input type="hidden" name="task" value="save" />
<input type="hidden" name="controller" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
<button type="button" onclick="submitbutton('save')"><?php echo JText::_('Save') ?></button>
<button type="button" onclick="submitbutton('cancel')"><?php echo JText::_('Cancel') ?></button>
</form>