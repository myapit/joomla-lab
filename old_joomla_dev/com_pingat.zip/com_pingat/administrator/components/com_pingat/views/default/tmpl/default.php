<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('pingat'), 'generic.png');
JToolBarHelper::preferences('com_pingat');
?>
<!-- Deafult administrator message -->
This is the default administrator view of your component. To edit it please edit the file:<br />
/administrator/components/com_pingat/views/default/tmpl/default.php