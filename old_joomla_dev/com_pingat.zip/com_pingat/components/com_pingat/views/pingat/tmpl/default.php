<?php defined('_JEXEC') or die('Restricted access'); ?>

<!-- Deafult message -->
This is the default view of your component. To edit it please edit the file:<br />
/components/com_pingat/views/default/tmpl/default.php