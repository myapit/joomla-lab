<?php defined('_JEXEC') or die('Restricted access'); ?>

<table border="0" width="100%" id="table1">
	<tr>
		<td colspan="5" align="center"><b><font face="Verdana" size="2">KELAB JASA BUDI<BR>UNIVERSITI SAINS MALAYSIA</font></b></td>
	</tr>
	<tr>
		<td colspan="5">&nbsp;</td>

	</tr>
	<tr>
		<td colspan="5">
		<p align="center"><b><font face="Verdana" size="2">BORANG PERMOHONAN UNTUK MENJADI AHLI</font></b></td>
	</tr>
	<tr>
		<td width="12%"><font face="Verdana" size="2">Kepada :</font></td>
		<td width="38%" colspan="2">&nbsp;</td>

		<td width="1%">&nbsp;</td>
		<td width="48%">&nbsp;</td>
	</tr>
	<tr>
		<td width="12%">&nbsp;</td>
		<td width="38%" colspan="2"><font face="Verdana" size="2">Setiausaha<br>Kelab Jasa Budi<br>d/a Rumah Alumni<br>
		Universiti Sains Malaysia<br>11800 USM, Pulau Pinang</font></td>

		<td width="1%">&nbsp;</td>
		<td width="48%">&nbsp;</td>
	</tr>
	<tr>
		<td width="12%">&nbsp;</td>
		<td width="38%" colspan="2">&nbsp;</td>
		<td width="1%">&nbsp;</td>
		<td width="48%">&nbsp;</td>
	</tr>

	<tr>
		<td width="12%">&nbsp;</td>
		<td width="8%"><font face="Verdana" size="2">Urusetia :</font></td>
		<td width="30%" align="right"><font face="Verdana" size="2">Telefon 
		</font> </td>
		<td width="1%" align="center"><font face="Verdana" size="2">:</font></td>
		<td width="48%"><font face="Verdana" size="2">019 - 4113044</font></td>

	</tr>
	<tr>
		<td width="12%">&nbsp;</td>
		<td width="8%">&nbsp;</td>
		<td width="30%" align="right"><font face="Verdana" size="2">Email </font> </td>
		<td width="1%" align="center"><font face="Verdana" size="2">:</font></td>
		<td width="48%"><font face="Verdana" size="2">khalidmdisa@yahoo.com</font></td>

	</tr>	
	<tr>
		<td width="84%" colspan="5">&nbsp;</td>
	</tr>
	<tr>
		<td width="84%" colspan="5"><font face="Verdana" size="2">Saya memohon untuk menjadi ahli dan 
		bersetuju mematuhi segala peraturan Kelab ini dan pindaan-pindaan yang 
		akan diluluskan kemudian.</font></td>
	</tr>
	<tr>
		<td width="84%" colspan="5">&nbsp;</td>

	</tr>
	<tr>
		<td width="84%" colspan="5"><font face="Verdana" size="2">Maklumat diri saya adalah seperti berikut :</font></td>
	</tr>
	<tr>
		<td width="84%" colspan="5">
		
		<table border="0" width="100%" id="table2">
			<tr>

				<td width="41%"><font face="Verdana" size="2">Nama Penuh</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td colspan="4"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">No. KP</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="24%" colspan="2"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
				<td width="32%" colspan="2" rowspan="4" valign="top">
					
					<img src="images/no_photo1.jpg" align="right">					
					
				</td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Jantina</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="24%" colspan="2"><b><font face="Verdana" size="2">
				&nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Tarikh Lahir</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="24%" colspan="2"><b><font face="Verdana" size="2"> &nbsp;</font></b></td>

			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Tempat Lahir</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="24%" colspan="2"><b><font face="Verdana" size="2"></font></b>&nbsp;</td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Warganegara</font></td>

				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4"><b><font face="Verdana" size="2"></font></b>&nbsp;</td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Alamat Rumah</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4"><b><font face="Verdana" size="2">&nbsp;</font></b></td>

			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Poskod</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
				<td width="5%"><font face="Verdana" size="2">Telefon</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="31%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Fax</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
				<td width="5%"><font face="Verdana" size="2">Email</font></td>

				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="31%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Jawatan Terakhir</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4"><b><font face="Verdana" size="2">&nbsp;</font></b></td>

			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Jabatan</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="41%" valign="top"><font face="Verdana" size="2">Tarikh Bersara / Tamat 
				Perkhidmatan</font></td>

				<td width="1%" valign="top"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4" valign="top"><b><font face="Verdana" size="2">
				 &nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="98%" colspan="6">&nbsp;</td>
			</tr>
			<tr>

				<td width="99%" colspan="6"><b><font face="Verdana" size="2">JIKA MASIH 
				BEKERJA :</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Pekerjaan</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>

			<tr>
				<td width="41%" valign="top"><font face="Verdana" size="2">Alamat Tempat 
				Kerja/Pejabat</font></td>
				<td width="1%" valign="top"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4" valign="top"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Poskod</font></td>

				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
				<td width="5%"><font face="Verdana" size="2">Telefon</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="31%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>
			<tr>

				<td width="41%"><font face="Verdana" size="2">Fax</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
				<td width="5%"><font face="Verdana" size="2">Email</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="31%"><b><font face="Verdana" size="2">&nbsp;</font></b></td>
			</tr>

			<tr>
				<td width="96%" colspan="6">&nbsp;</td>
			</tr>
			<!--<tr>
				<td width="41%"><font face="Verdana" size="2">Fail Gambar</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4">
				<font color="#000080"><input type="file" name="gambar" size="20"></font></td>
			</tr>-->
			<tr>
				<td width="96%" colspan="6">&nbsp;</td>
			</tr>
			<tr>
				<td width="96%" colspan="6"><font face="Verdana" size="2">

				Disertakan Wang Tunai/Cek/MO. No: </font>
				<b><font face="Verdana" size="2">&nbsp;</font></b><font face="Verdana" size="2">
				bernilai : RM25.00 untuk 
				bayaran yuran ahli seumur hidup (RM25) dan kad ahli (RM5).</font></td>
			</tr>
			<tr>
				<td width="96%" colspan="6">&nbsp;</td>
			</tr>
			<tr>

				<td width="96%" colspan="6"><font face="Verdana" size="2">Tarikh : 19 Oct 2011</font></td>
			</tr>
			
			<tr>
				<td width="96%" colspan="6" align="center">
					<form method="POST" action="borang_keahlian_print.asp" target="_blank">				
						<input type="hidden" value="1" name="print">				
						<input type="hidden" value="sdsd" name="ahli">
						
						<input type="submit" value="CETAK" name="B2">
										
					</form></td>

			</tr>
		</table>
		
		</td>
	</tr>
	
</table>