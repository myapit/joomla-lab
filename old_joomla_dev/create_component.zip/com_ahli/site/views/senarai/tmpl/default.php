<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<p style="line-height: 150%"><font face="Verdana" size="2"><b>KEAHLIAN</b></font></p>
          <table border="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%" colspan="2">
                <font face="Verdana" size="2">Keahlian dibuka kepada bukan sahaja ahli-ahli yang telah
bersara secara wajib atau pilihan tetapi juga kepada mereka yang pernah
berkhidmat dengan Universiti Sains Malaysia</font>

              </td>
            </tr>
            <tr>
              <td width="49%">
              <font size="2" face="Arial">
              Jumlah ahli setakat ini  :<b><font color="#0000FF"> 313</font></b> orang</font>

              </td>
              <td width="51%">
                <form method="POST" action="/jasabudi/default.asp?menu=3">
                  <p style="line-height: 150%" align="right"><input type="text" name="carian" size="20"><input type="submit" value="Cari" name="B1"></p>
                  <input type="hidden" name="flag" value="1">
                </form>
              </td>
            </tr>
            <tr>

            <center>
              <td width="100%" colspan="2">
                <div align="center">
                  <table border="0" cellpadding="2" cellspacing="0" width="100%" style="border-collapse: collapse" bordercolor="#111111" height="1">
                    <tr>
                      <td width="100%" style="border-top-style: none; border-top-width: medium" height="22">
                        <div align="center">
                        <table border="0" cellpadding="2" cellspacing="1" width="100%" style="border-top-width: 0; border-bottom-width: 0">
                             <tr>

                            <td width="5%" valign="top" style="border-style: solid; border-width: 1">
                              <b><font face="Verdana" size="2">Bil.</font></b></td>
								<td width="93%" valign="top" style="border-style: solid; border-width: 1">
								<b><font face="Verdana" size="2">Nama Ahli</font></b></td>
                            </tr>

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">

                              <font face="Verdana" size="2">1</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=363" style="text-decoration: none">A. Rahman Bin Ismail</a></font></td>
                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">2</font></td>

								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=270" style="text-decoration: none">A. Rhaffor Bin Hj. Mahmod </a></font></td>
                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">3</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">

								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=534" style="text-decoration: none">Ab Aziz Bin Daud</a></font></td>
                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">4</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">

								<a href="default.asp?menu=13&id=462" style="text-decoration: none">Ab Majid Bin Ismail</a></font></td>
                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">5</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=426" style="text-decoration: none">Ab. Kadir Bin Awang Mat</a></font></td>

                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">6</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=533" style="text-decoration: none">Ab. Kadir Bin Haji Ab. Rahman</a></font></td>
                            </tr>

                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">7</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=513" style="text-decoration: none">Ab. Razak Bin Ismail</a></font></td>
                            </tr>
                            

                            <tr>

                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">8</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=277" style="text-decoration: none">Abd Rahim Bin Mohamad Kamel</a></font></td>
                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">

                              <font face="Verdana" size="2">9</font></td>
								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=517" style="text-decoration: none">Abdul Aziz Bin Musa</a></font></td>
                            </tr>
                            

                            <tr>
                            <td width="5%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                              <font face="Verdana" size="2">10</font></td>

								<td width="94%" valign="top" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
								<font face="Verdana" size="2">
								<a href="default.asp?menu=13&id=542" style="text-decoration: none">Abdul Hadi Bin Ismail</a></font></td>
                            </tr>
                            

                          </table>
                        </div>
                      </center>
                      </td>

                    </tr>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <td width="100%" colspan="2">
          <table border="0" cellspacing="0" width="100%">
            <tr>

              <td width="52%">
        <form method="POST" action="/jasabudi/default.asp?menu=3">
          <p><select size="1" name="p" style="font-family: Verdana; font-size: 8pt">
	
<option selected  value="1">   Laman&nbsp;1    dari&nbsp;29	
<option value="2">   Laman&nbsp;2    dari&nbsp;29	
<option value="3">   Laman&nbsp;3    dari&nbsp;29	

<option value="4">   Laman&nbsp;4    dari&nbsp;29	
<option value="5">   Laman&nbsp;5    dari&nbsp;29	
<option value="6">   Laman&nbsp;6    dari&nbsp;29	
<option value="7">   Laman&nbsp;7    dari&nbsp;29	
<option value="8">   Laman&nbsp;8    dari&nbsp;29	

<option value="9">   Laman&nbsp;9    dari&nbsp;29	
<option value="10">   Laman&nbsp;10    dari&nbsp;29	
<option value="11">   Laman&nbsp;11    dari&nbsp;29	
<option value="12">   Laman&nbsp;12    dari&nbsp;29	
<option value="13">   Laman&nbsp;13    dari&nbsp;29	

<option value="14">   Laman&nbsp;14    dari&nbsp;29	
<option value="15">   Laman&nbsp;15    dari&nbsp;29	
<option value="16">   Laman&nbsp;16    dari&nbsp;29	
<option value="17">   Laman&nbsp;17    dari&nbsp;29	
<option value="18">   Laman&nbsp;18    dari&nbsp;29	

<option value="19">   Laman&nbsp;19    dari&nbsp;29	
<option value="20">   Laman&nbsp;20    dari&nbsp;29	
<option value="21">   Laman&nbsp;21    dari&nbsp;29	
<option value="22">   Laman&nbsp;22    dari&nbsp;29	
<option value="23">   Laman&nbsp;23    dari&nbsp;29	

<option value="24">   Laman&nbsp;24    dari&nbsp;29	
<option value="25">   Laman&nbsp;25    dari&nbsp;29	
<option value="26">   Laman&nbsp;26    dari&nbsp;29	
<option value="27">   Laman&nbsp;27    dari&nbsp;29	
<option value="28">   Laman&nbsp;28    dari&nbsp;29	

<option value="29">   Laman&nbsp;29    dari&nbsp;29
          </select> <input type="submit" value=" Ok " name="Go" style="font-size: 8pt; font-family: Verdana"><input type="hidden" name="idform" size="20" value=""><input type="hidden" name="topik" size="20" value=""></p>
        </form>
              </td>
              <td width="32%">

            </center>
              </td>

              <td width="16%">

        <form method="POST" action="/jasabudi/default.asp?menu=3">
        <input type = "hidden" name="p" value="2">

            </center>
  </center>
        <p align="right"><input type="submit" value="Berikut" name="Next" style="font-family: Verdana; font-size: 8pt"><input type="hidden" name="idform" size="20" value=""><input type="hidden" name="topik" size="20" value="">
          </p>
        </form>

            <center>
            



              </td>
            </tr>
          </table>
              </td>
            </tr>
          </table>
            </td>
          </tr>

          
        </table>