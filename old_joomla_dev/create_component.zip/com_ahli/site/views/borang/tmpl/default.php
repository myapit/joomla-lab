<?php defined('_JEXEC') or die('Restricted access'); ?>

<table border="0" width="100%" id="table1">
	<tr>
		<td colspan="5" align="center"><b><font face="Verdana" size="2">KELAB JASA BUDI<BR>UNIVERSITI SAINS MALAYSIA</font></b></td>
	</tr>
	<tr>
		<td colspan="5">&nbsp;</td>
	</tr>
	<tr>

		<td colspan="5">
		<p align="center"><b><font face="Verdana" size="2">BORANG PERMOHONAN UNTUK MENJADI AHLI</font></b></td>
	</tr>
	<tr>
		<td width="12%"><font face="Verdana" size="2">Kepada :</font></td>
		<td width="38%" colspan="2">&nbsp;</td>
		<td width="1%">&nbsp;</td>
		<td width="48%">&nbsp;</td>

	</tr>
	<tr>
		<td width="12%">&nbsp;</td>
		<td width="38%" colspan="2"><font face="Verdana" size="2">Setiausaha<br>Kelab Jasa Budi<br>d/a Rumah Alumni<br>
		Universiti Sains Malaysia<br>11800 USM, Pulau Pinang</font></td>
		<td width="1%">&nbsp;</td>

		<td width="48%">&nbsp;</td>
	</tr>
	<tr>
		<td width="12%">&nbsp;</td>
		<td width="38%" colspan="2">&nbsp;</td>
		<td width="1%">&nbsp;</td>
		<td width="48%">&nbsp;</td>
	</tr>
	<tr>

		<td width="12%">&nbsp;</td>
		<td width="8%"><font face="Verdana" size="2">Urusetia :</font></td>
		<td width="30%" align="right"><font face="Verdana" size="2">Telefon 
		</font> </td>
		<td width="1%" align="center"><font face="Verdana" size="2">:</font></td>
		<td width="48%"><font face="Verdana" size="2">019 - 4113044</font></td>
	</tr>

	<tr>
		<td width="12%">&nbsp;</td>
		<td width="8%">&nbsp;</td>
		<td width="30%" align="right"><font face="Verdana" size="2">Email </font> </td>
		<td width="1%" align="center"><font face="Verdana" size="2">:</font></td>
		<td width="48%"><font face="Verdana" size="2">khalidmdisa@yahoo.com</font></td>
	</tr>	
	<tr>

		<td width="84%" colspan="5">&nbsp;</td>
	</tr>
	<tr>
		<td width="84%" colspan="5"><font face="Verdana" size="2">Saya memohon untuk menjadi ahli dan 
		bersetuju mematuhi segala peraturan Kelab ini dan pindaan-pindaan yang 
		akan diluluskan kemudian.</font></td>
	</tr>
	<tr>
		<td width="84%" colspan="5">&nbsp;</td>
	</tr>

	<tr>
		<td width="84%" colspan="5"><font face="Verdana" size="2">Maklumat diri saya adalah seperti berikut :</font></td>
	</tr>
	<tr>
		<td width="84%" colspan="5">
		<form method="POST" action="index.php?option=com_ahli&task=save" enctype="multipart/form-data">
		<table border="0" width="100%" id="table2">
			
			<tr>

				<td width="41%"><font face="Verdana" size="2">Nama Penuh</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td colspan="4"><input type="text" name="nama" size="45">*</td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">No. KP</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="56%" colspan="4">
				<input type="text" name="nokp" size="12">*</td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Jantina</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="56%" colspan="4"><select size="1" name="jantina">

				<option selected value="0">Sila pilih</option>
				<option value="L">Lelaki</option>
				<option value="P">Perempuan</option>				
				</select></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Tarikh Lahir</font></td>

				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="56%" colspan="4">
				<select size="1" name="hari_lahir">
				<option value="0" selected>Hari</option>
				
				<option value="1">1</option>
				
				<option value="2">2</option>
				
				<option value="3">3</option>

				
				<option value="4">4</option>
				
				<option value="5">5</option>
				
				<option value="6">6</option>
				
				<option value="7">7</option>
				
				<option value="8">8</option>
				
				<option value="9">9</option>

				
				<option value="10">10</option>
				
				<option value="11">11</option>
				
				<option value="12">12</option>
				
				<option value="13">13</option>
				
				<option value="14">14</option>
				
				<option value="15">15</option>

				
				<option value="16">16</option>
				
				<option value="17">17</option>
				
				<option value="18">18</option>
				
				<option value="19">19</option>
				
				<option value="20">20</option>
				
				<option value="21">21</option>

				
				<option value="22">22</option>
				
				<option value="23">23</option>
				
				<option value="24">24</option>
				
				<option value="25">25</option>
				
				<option value="26">26</option>
				
				<option value="27">27</option>

				
				<option value="28">28</option>
				
				<option value="29">29</option>
				
				<option value="30">30</option>
				
				<option value="31">31</option>
				
				</select> 
				<select size="1" name="bulan_lahir">
				<option value="0" selected>Bulan</option>

				
				<option value="1">1</option>
				
				<option value="2">2</option>
				
				<option value="3">3</option>
				
				<option value="4">4</option>
				
				<option value="5">5</option>
				
				<option value="6">6</option>

				
				<option value="7">7</option>
				
				<option value="8">8</option>
				
				<option value="9">9</option>
				
				<option value="10">10</option>
				
				<option value="11">11</option>
				
				<option value="12">12</option>

				
				</select>
				<select size="1" name="tahun_lahir">
				<option value="0" selected>Tahun</option>
				
				<option value="1940">1940</option>
				
				<option value="1941">1941</option>
				
				<option value="1942">1942</option>
				
				<option value="1943">1943</option>

				
				<option value="1944">1944</option>
				
				<option value="1945">1945</option>
				
				<option value="1946">1946</option>
				
				<option value="1947">1947</option>
				
				<option value="1948">1948</option>
				
				<option value="1949">1949</option>

				
				<option value="1950">1950</option>
				
				<option value="1951">1951</option>
				
				<option value="1952">1952</option>
				
				<option value="1953">1953</option>
				
				<option value="1954">1954</option>
				
				<option value="1955">1955</option>

				
				<option value="1956">1956</option>
				
				<option value="1957">1957</option>
				
				<option value="1958">1958</option>
				
				<option value="1959">1959</option>
				
				<option value="1960">1960</option>
				
				<option value="1961">1961</option>

				
				<option value="1962">1962</option>
				
				<option value="1963">1963</option>
				
				<option value="1964">1964</option>
				
				<option value="1965">1965</option>
				
				<option value="1966">1966</option>
				
				<option value="1967">1967</option>

				
				<option value="1968">1968</option>
				
				<option value="1969">1969</option>
				
				<option value="1970">1970</option>
				
				<option value="1971">1971</option>
				
				<option value="1972">1972</option>
				
				<option value="1973">1973</option>

				
				<option value="1974">1974</option>
				
				<option value="1975">1975</option>
				
				<option value="1976">1976</option>
				
				<option value="1977">1977</option>
				
				<option value="1978">1978</option>
				
				<option value="1979">1979</option>

				
				<option value="1980">1980</option>
				
				<option value="1981">1981</option>
				
				<option value="1982">1982</option>
				
				<option value="1983">1983</option>
				
				<option value="1984">1984</option>
				
				<option value="1985">1985</option>

				
				<option value="1986">1986</option>
				
				<option value="1987">1987</option>
				
				<option value="1988">1988</option>
				
				<option value="1989">1989</option>
				
				<option value="1990">1990</option>
				
				<option value="1991">1991</option>

				
				<option value="1992">1992</option>
				
				<option value="1993">1993</option>
				
				<option value="1994">1994</option>
				
				<option value="1995">1995</option>
				
				<option value="1996">1996</option>
				
				<option value="1997">1997</option>

				
				<option value="1998">1998</option>
				
				<option value="1999">1999</option>
				
				<option value="2000">2000</option>
				
				<option value="2001">2001</option>
				
				<option value="2002">2002</option>
				
				<option value="2003">2003</option>

				
				<option value="2004">2004</option>
				
				<option value="2005">2005</option>
				
				<option value="2006">2006</option>
				
				<option value="2007">2007</option>
				
				<option value="2008">2008</option>
				
				<option value="2009">2009</option>

				
				<option value="2010">2010</option>
				
				<option value="2011">2011</option>
				
				</select></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Tempat Lahir</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="57%" colspan="4">
				<input type="text" name="tmpt_lahir" size="30"></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Warganegara</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4">
				<input type="text" name="warganegara" size="20"></td>

			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Alamat Rumah</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4">
				<input type="text" name="alamat" size="45"></td>
			</tr>
			<tr>

				<td width="41%"><font face="Verdana" size="2">Poskod</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%"><input type="text" name="poskod" size="5"></td>
				<td width="5%"><font face="Verdana" size="2">Telefon</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="31%">
				<input type="text" name="tel" size="12"></td>

			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Fax</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%">
				<input type="text" name="fax" size="12"></td>
				<td width="5%"><font face="Verdana" size="2">Email</font></td>

				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="31%">
				<input type="text" name="email" size="15">*</td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Jawatan Terakhir</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="57%" colspan="4">
				<input type="text" name="jawatanlps" size="30"></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Jabatan</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4">
				<input type="text" name="jabatan" size="40"></td>

			</tr>
			<tr>
				<td width="41%" valign="top"><font face="Verdana" size="2">Tarikh Bersara / Tamat 
				Perkhidmatan</font></td>
				<td width="1%" valign="top"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4" valign="top">
				<select size="1" name="hari_bsara">
				<option value="0" selected>Hari</option>

				
				<option value="1">1</option>
				
				<option value="2">2</option>
				
				<option value="3">3</option>
				
				<option value="4">4</option>
				
				<option value="5">5</option>
				
				<option value="6">6</option>

				
				<option value="7">7</option>
				
				<option value="8">8</option>
				
				<option value="9">9</option>
				
				<option value="10">10</option>
				
				<option value="11">11</option>
				
				<option value="12">12</option>

				
				<option value="13">13</option>
				
				<option value="14">14</option>
				
				<option value="15">15</option>
				
				<option value="16">16</option>
				
				<option value="17">17</option>
				
				<option value="18">18</option>

				
				<option value="19">19</option>
				
				<option value="20">20</option>
				
				<option value="21">21</option>
				
				<option value="22">22</option>
				
				<option value="23">23</option>
				
				<option value="24">24</option>

				
				<option value="25">25</option>
				
				<option value="26">26</option>
				
				<option value="27">27</option>
				
				<option value="28">28</option>
				
				<option value="29">29</option>
				
				<option value="30">30</option>

				
				<option value="31">31</option>
				
				</select> 
				<select size="1" name="bulan_bsara">
				<option value="0" selected>Bulan</option>
				
				<option value="1">1</option>
				
				<option value="2">2</option>
				
				<option value="3">3</option>

				
				<option value="4">4</option>
				
				<option value="5">5</option>
				
				<option value="6">6</option>
				
				<option value="7">7</option>
				
				<option value="8">8</option>
				
				<option value="9">9</option>

				
				<option value="10">10</option>
				
				<option value="11">11</option>
				
				<option value="12">12</option>
				
				</select>
				<select size="1" name="tahun_bsara">
				<option value="0" selected>Tahun</option>
				
				<option value="1960">1960</option>

				
				<option value="1961">1961</option>
				
				<option value="1962">1962</option>
				
				<option value="1963">1963</option>
				
				<option value="1964">1964</option>
				
				<option value="1965">1965</option>
				
				<option value="1966">1966</option>

				
				<option value="1967">1967</option>
				
				<option value="1968">1968</option>
				
				<option value="1969">1969</option>
				
				<option value="1970">1970</option>
				
				<option value="1971">1971</option>
				
				<option value="1972">1972</option>

				
				<option value="1973">1973</option>
				
				<option value="1974">1974</option>
				
				<option value="1975">1975</option>
				
				<option value="1976">1976</option>
				
				<option value="1977">1977</option>
				
				<option value="1978">1978</option>

				
				<option value="1979">1979</option>
				
				<option value="1980">1980</option>
				
				<option value="1981">1981</option>
				
				<option value="1982">1982</option>
				
				<option value="1983">1983</option>
				
				<option value="1984">1984</option>

				
				<option value="1985">1985</option>
				
				<option value="1986">1986</option>
				
				<option value="1987">1987</option>
				
				<option value="1988">1988</option>
				
				<option value="1989">1989</option>
				
				<option value="1990">1990</option>

				
				<option value="1991">1991</option>
				
				<option value="1992">1992</option>
				
				<option value="1993">1993</option>
				
				<option value="1994">1994</option>
				
				<option value="1995">1995</option>
				
				<option value="1996">1996</option>

				
				<option value="1997">1997</option>
				
				<option value="1998">1998</option>
				
				<option value="1999">1999</option>
				
				<option value="2000">2000</option>
				
				<option value="2001">2001</option>
				
				<option value="2002">2002</option>

				
				<option value="2003">2003</option>
				
				<option value="2004">2004</option>
				
				<option value="2005">2005</option>
				
				<option value="2006">2006</option>
				
				<option value="2007">2007</option>
				
				<option value="2008">2008</option>

				
				<option value="2009">2009</option>
				
				<option value="2010">2010</option>
				
				<option value="2011">2011</option>
				
				</select></td>
			</tr>
			<tr>
				<td width="98%" colspan="6">&nbsp;</td>

			</tr>
			<tr>
				<td width="99%" colspan="6"><b><font face="Verdana" size="2">JIKA MASIH 
				BEKERJA :</font></b></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Pekerjaan</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="57%" colspan="4">
				<input type="text" name="jawatanskrg" size="30"></td>
			</tr>
			<tr>
				<td width="41%" valign="top"><font face="Verdana" size="2">Alamat Tempat 
				Kerja/Pejabat</font></td>
				<td width="1%" valign="top"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4" valign="top">
				<input type="text" name="pejabat" size="45"></td>

			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Poskod</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%"><input type="text" name="poskodpej" size="5"></td>
				<td width="5%"><font face="Verdana" size="2">Telefon</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>

				<td width="31%">
				<input type="text" name="telpej" size="12"></td>
			</tr>
			<tr>
				<td width="41%"><font face="Verdana" size="2">Fax</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="18%">
				<input type="text" name="faxpej" size="12"></td>

				<td width="5%"><font face="Verdana" size="2">Email</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="31%">
				<input type="text" name="emailpej" size="15"></td>
			</tr>
			<tr>
				<td width="96%" colspan="6">&nbsp;</td>
			</tr>

			<tr>
				<td width="41%"><font face="Verdana" size="2">Fail Gambar</font></td>
				<td width="1%"><font face="Verdana" size="2">:</font></td>
				<td width="57%" colspan="4">
				<font color="#000080"><input type="file" name="gambar" size="20"></font></td>
			</tr>
			<tr>
				<td width="96%" colspan="6">&nbsp;</td>

			</tr>
			<tr>
				<td width="96%" colspan="6"><font face="Verdana" size="2">
				Disertakan Wang Tunai/Cek/MO. No: </font>
				<input type="text" name="nocek" size="15"><font face="Verdana" size="2">
				untuk 
				bayaran yuran ahli seumur hidup (RM25) dan kad ahli (RM5).</font></td>
			</tr>
			<tr>

				<td width="96%" colspan="6">&nbsp;</td>
			</tr>
			<tr>
				<td width="96%" colspan="6"><font face="Verdana" size="2">Tarikh : 18 Oct 2011</font></td>
			</tr>
			
			<tr>
				<td width="96%" colspan="6" align="center">
			<input type="submit" value="SUBMIT" name="B1"></td>

			</tr>
		</table>
		</form>
		</td>
	</tr>
	
</table>