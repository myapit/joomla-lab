 <div class="gantry-width-90 gantry-width-block">
 	<strong><span style="font-size: 14pt;">Senarai SubKursus</span></strong>
</div>
<div class="clear">&nbsp;</div>
<br/>
<?php
$data = JRequest::getVar('data');

echo "<table cellpadding='4' cellspacing='4' border='1' style='font-size:11px;'>
		<tr>
		<th>Bil</th>
		<th>Kod</th>
		<th>Subjek</th>
		</tr>";
$bil = 0;
while ($row = sybase_fetch_array($data))
{
	$bil++;
	echo "<tr>";
	echo "<td>".$bil."</td>";
	echo "<td>".strtoupper($row['kodsijil'])."</td>";
	echo "<td style='word-wrap: break-word; width:50%;'>".strtoupper($row['kursus'])."</td>";
	echo "</tr>";
}
echo "</table>";
echo "<p><a href='#' onclick='javascript:history(-1);'>&laquo; Kembali</a>";
?>
