<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the pestahoki online reg component
 */
class PlkViewSenaraisubjek extends JView 
{
	function display($tpl = null) 
	{
        $id = JRequest::getVar('kod');
		$model =& JModel::getInstance( 'model_plk', 'PlkModel' );
		$res = $model->get_subkursus($id);

		JRequest::setVar('data', $res);

        parent::display($tpl);
    }
}
?>