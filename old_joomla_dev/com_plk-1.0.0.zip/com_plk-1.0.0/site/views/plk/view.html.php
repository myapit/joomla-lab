<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the pestahoki online reg component
 */
class PlkViewPlk extends JView 
{
	function display($tpl = null) 
	{
        
		$model =& JModel::getInstance( 'model_plk', 'PlkModel' );
		$res = $model->get_plk();

		JRequest::setVar('data', $res);

        parent::display($tpl);
    }
}
?>