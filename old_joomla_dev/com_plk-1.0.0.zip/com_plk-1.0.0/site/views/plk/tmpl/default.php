 <div class="gantry-width-90 gantry-width-block">
 	<strong><span style="font-size: 14pt;">Senarai Pusat Latihan Komputer</span></strong>
</div>
<div class="clear">&nbsp;</div>
<br/>
<?php
$model =& JModel::getInstance( 'model_plk', 'PlkModel' );
$data= $model->get_plk();

echo "<table cellpadding='4' cellspacing='4' border='1' style='font-size:11px;'>
		<tr>
		<th width=\"4%\">Bil</th>
		<th width=\"25%\">Pusat Latihan Komputer</th>
		<th>Alamat</th>
		</tr>";
$bil = 0;
while ($row = sybase_fetch_array($data))
{
	$bil++;
	
	$telefon = trim($row['no_telefon']);
	$faks    = trim($row['faks']);
	$emel    = trim($row['emel']);
	$laman_web = trim($row['laman_web']);
	$facebook  = trim($row['facebook']);
	$twitter   = trim($row['twitter']);
	
	$alamat  = strtoupper($row['alamat']);
	$telefon = empty($telefon)? "-":$telefon;
	$faks    = empty($faks)? "-":$faks;
	
	$emel      = empty($emel)?      "":JRoute::_('<div style="line-height:12px;"><img src="'.JURI::root().'components/com_plk/assets/images/email.png" sytle="height:12px; width:12px;margin-left:4px; margin-right:4px;">&nbsp;<a href="mailto:'.$emel.'">'.$emel.'</a></div>');
	$laman_web = empty($laman_web)? "":JRoute::_('<div style="line-height:12px;"><img src="'.JURI::root().'components/com_plk/assets/images/web.png" sytle="height:12px; width:12px;margin-left:4px; margin-right:4px;">&nbsp;<a target="_blank" href="'.$laman_web.'">'.$laman_web.'</a></div>');
	$facebook  = empty($facebook)?  "":JRoute::_('<div style="line-height:12px;"><img src="'.JURI::root().'components/com_plk/assets/images/facebook.png" sytle="height:12px; width:12px;margin-left:4px; margin-right:4px;">&nbsp;<a target="_blank" href="'.$facebook.'">'.$facebook.'</a></div>');
	$twitter   = empty($twitter)?   "":JRoute::_('<div style="line-height:12px;"><img src="'.JURI::root().'components/com_plk/assets/images/twitter.png.png" sytle="height:12px; width:12px;margin-left:4px; margin-right:4px;">&nbsp;<a target="_blank" href="'.$twitter.'">'.$twitter.'</a></div>');
	
	
	echo "<tr>";
	echo "<td valign=center>".$bil."</td>";
	echo "<td>".strtoupper($row['plk'])."</td>";
	echo "<td style='word-wrap: break-word; width:50%;'>".strtoupper($row['alamat'])."<br>
		TEL : ".$telefon."&nbsp;&nbsp;&nbsp;FAKS : ".$faks."
		$emel
		$laman_web
		$facebook
		$twitter</td>";
	echo "</tr>";
}
echo "</table>";
?>
