<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=senarai_kursus.xls");



$data = JRequest::getVar('data');
$model =& JModel::getInstance( 'model_plk', 'PlkModel' );


$bil = 0; $temp = ""; $temp1 = "";
$total_rows = sybase_num_rows($data);
$num_in_row = $total_rows / 2;
echo "<table><tr><td colspan=3>Senarai Kursus Program Pendidikan Berterusan PPB</td></tr></table>";
echo "<table cellpadding='4' cellspacing='4' border='1' style='font-size:12px; margin-left:40px; margin-right:40px;' width='800px'>
<tr>
<th width='8%'>Bil</th>
<th width='25%'>Kod Kursus</th>
<th>Nama Kursus</th>
</tr>";
while ($row = sybase_fetch_array($data))
{
	$bil++;
	$id = $row['kod'];
	$res = $model->get_subkursus($id);
	$tmp = "";
	$tmp .= "<table cellpadding='0' cellspacing='0' border='1' style=' margin-left:15px; font-size:12px;' width='500px'>
	<tr>
	<th width='7%'>Bil</th>
	<th width='20%'>Kod</th>
	<th>Subjek</th>
	</tr>";
	$jum_subjek = @sybase_num_rows($res);

	$bilx = 0;
	while ($rowx = sybase_fetch_array($res) )
	{
		$bilx++;
		$tmp .= "<tr>";
		$tmp .= "<td align=center>".$bilx.".</td>";
		$tmp .= "<td>".strtoupper($rowx['kodsijil'])."</td>";
		$tmp .= "<td style='word-wrap: break-word; 70%'>".strtoupper($rowx['kursus'])."</td>";
		$tmp .= "</tr>";
	}
	$tmp .= "</table>";

	switch($jum_subjek) {
		case '0':
			$url = strtoupper($row['pakejkemahiran']);
			$tmp = "";
			break;
		default:
			$url = "<div class='moreInfoWrapperPLK'>
			<div class='divTogglePLK'><a style='cursor:pointer';>".strtoupper($row['pakejkemahiran'])."</a></div>
			<div class='moreInfoPLK'></div>
			</div>";
	}
	echo "<tr>
	<td align=center>".$bil.".</td>
	<td align=center>".strtoupper($row['kod'])."</td>
	<td>
	".$url."
	</td>
	</tr>";
}
echo "</table>";

/*
 remove
*/

?>
