<?php
/**
 * @version     1.0.0
 * @package     com_plk
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      hafeez <mhafeez@usm.my> - http://enovate.usm.my
 */

defined('_JEXEC') or die;

abstract class PlkHelper
{
	public static function myFunction()
	{
		$result = 'Something';
		return $result;
	}

}

