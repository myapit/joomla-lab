<?php
/**
 * @version     1.0.0
 * @package     com_plk
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      hafeez <mhafeez@usm.my> - http://enovate.usm.my
 */
 
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

class PlkController extends JController
{
	function display()
	{
		$config = & JModel::getInstance('model_plk','PlkModel');
		
		JRequest::setVar('layout','term_of_service');
		parent::display();
	}
	
	function output_excel()
	{
		$model = & JModel::getInstance('model_plk','PlkModel');

		JRequest::setVar('layout', 'excel_format' );
		parent::display();
	}
}