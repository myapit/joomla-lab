<?php

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');


class PlkModelModel_plk extends JModel 
{
	var $_connection = "";
	//var $_result     = "";

	function __construct()
	{	
		$server = "ccacad2.usm.my";
		$port   = "5000";
		$user   = "pbbreadonly";
		$pass   = "pbbreadonly";
		$dbase  = "[dbppb]";
		
		$connection = @sybase_pconnect($server.":".$port, $user, $pass) or die('Sybase Connection Failed');
		$this->_connection = $connection;
		$db = @sybase_select_db($dbase, $connection) or die('Sybase Database Failed');	
	}


	function get_plk()
	{
		$query =  "SELECT noahli, plk, alamat, no_telefon, faks, emel, status, laman_web, facebook, twitter FROM d_plk WHERE status='1' ORDER BY plk ASC";
		$result = @sybase_query($query, $this->_connection);
		return $result;
	}


	function get_kursus()
	{
		$query =  "SELECT status, kod, pakejkemahiran, pakej FROM d_kursus WHERE status = 'Y' ORDER  BY pakejkemahiran ASC";
		$result = @sybase_query($query, $this->_connection);
		return $result;
	}


	function get_subkursus($id=NULL)
	{
		if ($id != NULL) 
		{
			$query =  "SELECT status, kodlink, kodsijil, kursus, harga_seunit FROM d_pkursus WHERE kodlink='$id' ORDER BY kursus ASC";
			$result = @sybase_query($query, $this->_connection);
			return $result;
		} else {
			return false;
		}
	}
			
}

?>
