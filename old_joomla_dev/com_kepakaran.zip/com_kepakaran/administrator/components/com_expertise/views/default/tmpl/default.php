<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('Directory Of Expertise'), 'generic.png');
JToolBarHelper::preferences('com_expertise');
JSubMenuHelper::addEntry(JText::_('School'), 'index.php?option=com_expertise' );
JSubMenuHelper::addEntry(JText::_('Front-End Users'), 'index.php?option=com_expertise&c=users' );
$key = md5(microtime());
$usr = &JFactory::getUser();
$log = $usr->username."|".$_SERVER['REMOTE_ADDR']."|".date('Y-m-d H:i:s');

if(JRequest::getCmd('c')!='users') {
  if(JRequest::getCmd('action')=='') {
    echo '<div>
    <h1>List of Schools</h1>
    <fieldset><legend>Add New School</legend>
    <form name="" method="post" action="">
    School Name <input type="text" name="school" id="school" size="60" maxlength="200" />
    <input type="submit" name="save" value="save" id="save">
    </form>
    </fieldset>';
    if(JRequest::getCmd('save')=='save')
    {
       $db = &JFactory::getDBO();
        $sql = "select * from myexp_school where s_sname = '".JRequest::getVar('school')."'";
        $db->setQuery($sql);
        $res = $db->loadAssocList();
        if(count($res)==0)
        {
          $data = new stdClass();
          $data->s_pkeys = $key;
          $data->s_sname = JRequest::getVar('school');
          $data->s_slogs  = $log;
          $db = JFactory::getDBO();
          $db->insertObject( 'myexp_school', $data);
          echo JText::_( 'Data Saved' );
        }else{
          echo JText::_( 'Data Already Exists' );
        }
    } 
  } //new
  
  if(JRequest::getCmd('action')=='edit'){
    if(JRequest::getCmd('key')!=''){
      if(JRequest::getCmd('update')=='update'){
        $data = new stdClass();
        $data->s_pkeys = JRequest::getCmd('key');
        $data->s_sname = JRequest::getVar('school');
        $data->s_slogs  = $log;
        $db = JFactory::getDBO();
        $db->updateObject( 'myexp_school', $data, 's_pkeys');
        echo JText::_( 'Updated' );
      }
      
      $sqlu = "select * from myexp_school where s_pkeys='".JRequest::getCmd('key')."'";
      $dbu = &JFactory::getDBO();
      $dbu->setQuery($sqlu);
      $resu = $dbu->loadAssocList();
      if(count($resu)>0){
        foreach($resu as $ro){
              echo '<div>
              <h1>List of Schools</h1>
              <fieldset><legend>Update School</legend>
              <form name="" method="post" action="">
              School Name 
              <input type="text" name="school" id="school" size="60" maxlength="200" value="'.$ro['s_sname'].'" />
              <input type="submit" name="update" value="update" id="update">
              </form>
              </fieldset>';
        }
      }else{
        echo JText::_('Data not found');
      }
    }
  }//edit
  
  if(JRequest::getCmd('action')=='delete'){
    if(JRequest::getCmd('key')!=''){
      $dbd = &JFactory::getDBO();
      $sql = "delete from myexp_school where s_pkeys='".JRequest::getCmd('key')."'";
      $dbd->setQuery($sql);
      if($dbd->query()){
        echo JText::_('Delete Success');
      }else{
        echo JText::_('Delete Failed');
      }
    }
  }//delete

  echo '<fieldset><legend>List</legend>
  <table width="100%" cellpadding="2" cellspacing="2" border="1">
  <tr>
  	<th>#</th><th>School Name</th><th>Actions</th>
  </tr>';

  $db = &JFactory::getDBO();
  $sql = "select * from myexp_school order by s_sname asc";
  $db->setQuery($sql);
  $res = $db->loadAssocList();
  $c=0;
  foreach($res as $ro)
  {
    ++$c;
    $delete = JRoute::_('index.php?option=com_expertise&key='.$ro['s_pkeys'])."&action=delete";
    $link_view = "";//<a href=\"".JRoute::_('index.php?option=com_expertise&key='.$ro['s_pkeys'])."&action=view\">View Expertise</a>";
    $link_edit = "<a href=\"".JRoute::_('index.php?option=com_expertise&key='.$ro['s_pkeys'])."&action=edit\">Edit School Name</a>";
    $link_del  = "<a href=\"javascript: window.location.href='$delete';\" onclick=\"return confirm('Are you sure to delete the record.');\">Delete School Name</a>";
    echo "<tr>";
    echo "<td>".$c."</td><td>".$ro['s_sname']."</td><td>$link_view $link_edit | $link_del</td>";
    echo "</tr>";
  }

  echo '</table>
  </fieldset>
  </div>';
}
//users
if(JRequest::getCmd('c')=='users'){
   if(JRequest::getCmd('assign')=='assign') {
       $sql = "select * from myexp_eusers where u_users='".JRequest::getVar('user')."'";
       $db = JFactory::getDBO();
       $db->setQuery($sql);
       $res = $db->loadAssocList();
       if(count($res)==0){  
         $data = new stdClass();
         $data->u_users = JRequest::getVar('user');
         $data->u_satus = '1';
         $db = JFactory::getDBO();
         $db->insertObject( 'myexp_eusers', $data);
         echo JText::_( 'User Assigned.' );
       }else{
         echo JText::_('User Already Assigned');
       }
   }
  $db = &JFactory::getDBO();
  $sql = "select id,name,username from #__users";
  $db->setQuery($sql);
  $res = $db->loadAssocList();
  echo JText::_('<h1>Assign Front-End Users</h1>');
  echo JText::_('<p>');
  echo '<form name="" method="post" action="">';
  echo "Assign new user : ";
  echo JText::_('<select name="user">');
  foreach($res as $ro){
    echo JText::_('<option value="'.$ro['id'].'">'.$ro['name'].'</option>');
  }
  echo JText::_('</select>');
  echo '&nbsp;<input type="submit" name="assign" value="assign" id="assign">';
  echo '</form>';
  echo JText::_('</p>');
   
  $sql = "select * from myexp_eusers es inner join #__users us on es.u_users=us.id";
  $db->setQuery($sql);
  $res = $db->loadAssocList();
  echo "<p>";
  echo "<h4>Assigned Users</h4>";
  foreach($res as $ro){
    echo $ro['name']."<br>";
  }
  echo "</p>";
}
?>


