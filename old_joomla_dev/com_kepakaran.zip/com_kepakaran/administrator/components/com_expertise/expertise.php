<?php
/**
 * Joomla! 1.5 component expertise
 *
 * @version $Id: expertise.php 2010-08-03 01:06:00 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage expertise
 * @license Copyright (c) 2010 - All Rights Reserved
 *
 * Directory of Expertise :: USM
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Define constants for all pages
 */
define( 'COM_EXPERTISE_DIR', 'images'.DS.'expertise'.DS );
define( 'COM_EXPERTISE_BASE', JPATH_ROOT.DS.COM_EXPERTISE_DIR );
define( 'COM_EXPERTISE_BASEURL', JURI::root().str_replace( DS, '/', COM_EXPERTISE_DIR ));

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';

// Require the base controller
require_once JPATH_COMPONENT.DS.'helpers'.DS.'helper.php';

// Initialize the controller
$controller = new ExpertiseController( );

// Perform the Request task
$controller->execute( JRequest::getCmd('task'));
$controller->redirect();
?>