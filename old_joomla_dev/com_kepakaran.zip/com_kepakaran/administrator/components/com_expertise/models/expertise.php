<?php
/**
 * Joomla! 1.5 component expertise
 *
 * @version $Id: expertise.php 2010-08-03 01:06:00 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage expertise
 * @license Copyright (c) 2010 - All Rights Reserved
 *
 * Directory of Expertise :: USM
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport('joomla.application.component.model');

class ExpertiseModelExpertise extends JModel {
    function __construct() {
		parent::__construct();
    }
}
?>