<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php
// turn off the WSDL cache
ini_set("soap.wsdl_cache_enabled", "0");

$client = new SoapClient("http://10.202.1.83/wsexpertise/ExpertiseService.asmx?wsdl");

$department = $client->GetDepartment();

var_dump($department);
print("<p>Directory of Expertise</p>");

print("Department<br><br>");

foreach ($department->GetDepartmentResult->Department as $value) {
	//print("$value->Id <a href=expertise.php?exp=$value->Id>$value->Name </a><br>");
	print("<a href=expertise.php?exp=$value->Id>$value->Name </a><br>");

}

?>

