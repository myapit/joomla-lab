<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
// turn off the WSDL cache
ini_set("soap.wsdl_cache_enabled", "0");

$client = new SoapClient("http://10.202.1.83/wsexpertise/ExpertiseService.asmx?wsdl");

$departmentId = $_GET["exp"];

$staffs = $client->GetStaff(array("DeptId" => $departmentId));

print("<a href=expertiseclient.php>Return</a> <br><br>");

?>

<p>Directory of Expertise</p>

<table border="1" width="100%">
	<tr>
		<td>#</td>
		<td>Name</td>
		<td>Expertise</td>
	</tr>
	<?php  
	$x = 1;
	foreach ($staffs->GetStaffResult->Staff as $value) { ?>
	<tr>
		<td><?php echo $x; ?>&nbsp;</td>
		<td>
			<a href="http://10.206.1.224/smus/hcms/IR/cv_ak.asp?nopeng=<?php echo $value->StaffId; ?>">
				<?php echo $value->Name; ?>
			</a>	
			<br>
			<?php  
		$v = gettype($value->Qualifications->Qualification);
		//echo $v;
		//var_dump($value->Qualifications->Qualification->Name);
		//var_dump($value->Qualifications);
		if($value->Qualifications->Qualification) {
			if ($v == "object") {
				echo $value->Qualifications->Qualification->Name;
			}else if($value->Qualifications->Qualification!=NULL){
				$qualificationCount = count($value->Qualifications->Qualification);		
				$l = 1;
				foreach ($value->Qualifications->Qualification as $qualificationValue) { 
					echo "$qualificationValue->Name";
					if ($l < $qualificationCount )	 {
						echo ", ";
					}
					
					$l++;
				}
			}
		}  elseif ($value->Qualifications->Qualification == NULL) {
			echo "&nbsp;";
		}
		?>
		</td>
		<td>
		<?php  
		$v = gettype($value->Expertises->Expertise);
		//echo $v;
		//var_dump($value->Expertises->Expertise->Name);
		if($value->Expertises->Expertise) {
			if ($v == "object") {
				echo $value->Expertises->Expertise->Name;
			}else{
				$expertiseCount = count($value->Expertises->Expertise);		
				$k = 1;
				foreach ($value->Expertises->Expertise as $expertiseValue) { 
					echo "$expertiseValue->Name";
					if ($k < $expertiseCount)	 {
						echo ", ";
					}
					
					$k++;
				}
			}
		}  elseif ($value->Expertises->Expertise == NULL) {
			echo "&nbsp;";
		}
		?>

		</td>
	</tr>
	<?php 
		$x++;
	} ?>
</table>

