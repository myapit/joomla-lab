<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
$ctl_user    = JFactory::getUser();
$ctl_type    = $ctl_user->usertype;
$var_userid  = $ctl_user->id;
$ctl_search  = JRequest::getCmd('search_expertise');
$ctl_task    = JRequest::getCmd('task');
$dat_exp     = JRequest::getCmd('exp');
$key         = md5(microtime());

$sql = "select * from myexp_eusers where u_users='$var_userid' and u_satus='1'";
$db =& JFactory::getDBO();
$db->setQuery($sql);
$result = $db->loadAssocList(); //loadObject();

if(count($result)==0 && $ctl_user->usertype != "Super Administrator")
{
	echo "<span style='color:red'>Access Denied !</span>";
}else{
	// Begin Admin
	if(JRequest::getCmd('submit_form')=='Submit')
	{
		$school = JRequest::getCmd('school');
		$ename  = JRequest::getCmd('ename');
		$expert = JRequest::getCmd('expert');
		$cert   = JRequest::getCmd('cert');		
		$log    = $ctl_user->username."|".$_SERVER['REMOTE_ADDR']."|".date('Y-m-d H:i:s');
		
		if(JRequest::getVar('ename')=='' || JRequest::getVar('expert')=='' || JRequest::getVar('cert')==''){
		  echo JText::_('Please fill-in all fields.');
		  view_input_form();
		}else{
  		$data = new stdClass();
  		$data->e_pkeys = $key;
  		$data->s_pkeys = JRequest::getCmd('school');
      $data->e_ename = substr(strtoupper(JRequest::getVar('ename')),0,250);
      $data->e_expet = ucwords(JRequest::getVar('expert'));
      $data->e_ecert = JRequest::getVar('cert');
      $data->e_phone = substr(JRequest::getVar('phone'),0,150);
      $data->e_email = substr(JRequest::getVar('email'),0,200);
  		$data->e_elogs = $log;
  		$db = JFactory::getDBO();
  		if($db->insertObject('myexp_expert',$data)){
    		echo JText::_('<p><div>');
    		echo JText::_('Record Saved');
    		echo JText::_("<br>Name:".strtoupper(JRequest::getVar('ename')));
    		echo JText::_('</div></p>');
  		}else{
  		  echo JText::_('<div>Failed to save record.</div>');
  		}
  		view_input_form();
		}
	}else{
		view_input_form();
	}
	// End Admin
}

function view_input_form()
{
?>
<div class="rt-joomla">
<div class="edit-article">

<form method="post" name="" action="">
<fieldset><legend>Add New Expertise</legend>
<br>
<table class="adminform">
<tr>
	<td><label for="title">School</label></td>
	<td>
  	<select name="school" class="inputbox">
      <?php
      $sql = "select * from myexp_school order by s_sname asc";
      $db =& JFactory::getDBO();
      $db->setQuery($sql);
      $result = $db->loadAssoclist();
      foreach($result as $row)
      {
      	echo "<option value=\"".$row['s_pkeys']."\">".$row['s_sname']."</option>";
      }
      ?>
      </select>
     </td>
 </tr>
 <tr>
 	<td><label for="title">Name</label></td>
 	<td><input type="text" name="ename" id="ename" size="60" maxlength="250" class="inputbox"/></td>
 </tr>
 <tr>
  <td><label for="title">Phone</label></td>
  <td><input type="text" name="phone" id="phone" size="60" maxlength="150" class="inputbox" value=""/><small>e.g: 010-5555555</small></td>
 </tr>
 <tr>
  <td><label for="title">E-mail</label></td>
  <td><input type="text" name="email" id="email" size="60" maxlength="250" class="inputbox" value=""/><small>e.g: someone@world.net</small></td>
 </tr>
 <tr>
 	<td valign="top"><label>Certificates</label></td>
 	<td><textarea name="cert" id="cert" cols="60" rows="5" class="inputbox"></textarea><small>Split each certificates with ","</small></td>
 </tr>
 <tr>
 	<td valign="top"><label>Expertise</label></td>
 	<td><textarea name="expert" cols="60" rows="5" class="inputbox"></textarea><small>Split each certificates with ","</small></td>
 </tr>
 <tr>
 	<td colspan="3">
 		<input type="submit" name="submit_form" id="submit_form" value="Submit" class="button">
 		&nbsp;
 		<?php
 		//echo "<button class=\"button\" onclick=\"window.location.href='".JRoute::_('index.php?option=com_expertise&task=task')."';\">
		//	Return</button>"; 	
 		?>
 	</td>
 </tr>
</table>
</fieldset>
</form>
</div>
</div>
<?php
}
?>
