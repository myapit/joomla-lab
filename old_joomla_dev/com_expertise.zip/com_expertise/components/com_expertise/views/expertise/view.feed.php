<?php
/**
 * Joomla! 1.5 component expertise
 *
 * @version $Id: view.feed.php 2010-08-03 01:06:00 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage expertise
 * @license Copyright (c) 2010 - All Rights Reserved
 *
 * Directory of Expertise :: USM
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

/**
 * Feed View class for the expertise component
 */
class ExpertiseViewExpertise extends JView {
	function display($tpl = null) {
        parent::display($tpl);
    }
}
?>