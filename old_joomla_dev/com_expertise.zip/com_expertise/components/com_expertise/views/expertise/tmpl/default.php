<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
$ctl_user    = JFactory::getUser();
$ctl_type    = $ctl_user->usertype;
$ctl_search  = JRequest::getCmd('search_expertise');
$ctl_task    = JRequest::getCmd('task');
$dat_exp     = JRequest::getCmd('exp');
$var_userid  = $ctl_user->id;
$sqls = "select * from myexp_eusers where u_users='$var_userid' and u_satus='1'";
$dbs =& JFactory::getDBO();
$dbs->setQuery($sql);
$results = $dbs->loadAssocList();
?>
<script language="javascript">
function submit_search() {
	//var $search_text;
	$search_text = document.getElementById('search_expertise');
	
	if($search_text.value.length <= 3){
		alert('Please enter more than 3 characters to start search.');
		$search_text.focus();
		return false;
	}else{
		document.frmexpertise.submit();
		return true;
	}
}
</script>
<p>
The directory of expertise provides search facilities based on name, 
qualifications and expertise of USM academic staff.<br> 
The list is usually updated on a periodical basis.
</p>
<div>
	<form id="frmexpertise" name="frmexpertise" method="post" action="<?php echo JRoute::_('index.php?option=com_expertise'); ?>" onsubmit="return submit_search();">
	<fieldset><legend><strong>Search Expertise :</strong></legend>
	<input type="text" name="search_expertise" id="search_expertise" value="" size="50%" class="inputbox"/>
	<input type="button" class="button" id="btn_expertise" name="btn_expertise" value="Search" onclick="submit_search();" />
	<input type="hidden" name="task" value="search">
	</fieldset>
	</form>
</div>

<?php 
if(count($results)>0 || $ctl_user->usertype == "Super Administrator") {
  $admin = JRoute::_('index.php?option=com_expertise&view=expertisefrontend');
  echo "<div>";
  echo "<button class='button' onclick=\"window.location.href='".$admin."';\">ADD NEW EXPERTISE</button>";
  echo "</div>";
}
?>
<div id="result_expertise">
<?php
if($ctl_task != 'view') {

	$db =& JFactory::getDBO();
	//$sql = "SELECT * FROM myexp_school LEFT JOIN myexp_expert ON myexp_school.s_pkeys=myexp_expert.s_pkeys ORDER BY myexp_school.s_sname ASC";
	$sql = "SELECT * FROM myexp_school ORDER BY s_sname ASC";
	$db->setQuery($sql);
	$result = $db->loadAssocList(); //loadObject();
?>
<table cellpadding="2" cellspacing="2" width="80%">
<!--- <tr>
	<th>#</th>
	<th>School's Name</th>
	<th>View</th>
</tr>
-->
<?php
$cc=0;
echo "<tr><td colspan=2><hr></td></tr>";
foreach($result as $row)
{
	++$cc;
	$links = JRoute::_('index.php?option=com_expertise&task=view&exp='.$row['s_pkeys']);
	echo "<tr>
    		<td>".$cc."</td>
    		<td><a href=\"".$links."\">".$row['s_sname']."</a></td>
    		<!-- <td><a href=\"".$links."\">Details</a></td> -->
    		</tr>";
}
	echo "<tr><td colspan=2 style='border-bottom:solid 1px #000'>&nbsp;</td></tr>";
?>
</table>
<?php
}else{
  //do nothing
}
?>
</div>
