<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
$ctl_user    = JFactory::getUser();
$ctl_type    = $ctl_user->usertype;
$var_userid  = $ctl_user->id;

//echo "<button onclick=\"window.location.href='".JRoute::_('index.php?option=com_expertise')."';\">Return</button>";
$sql = "select * from myexp_eusers where u_users='$var_userid' and u_satus='1'";
$db =& JFactory::getDBO();
$db->setQuery($sql);
$result = $db->loadAssocList(); //loadObject();

if(count($result)==0 && $ctl_user->usertype != "Super Administrator")
{
	echo "<span style='color:red'>Access Denied !</span>";
}else{
	if(JRequest::getVar('submit_form')!='' && JRequest::getCmd('exp')==JRequest::getCmd('id')){
		$school = JRequest::getCmd('school');
		$ename  = JRequest::getCmd('ename');
		$expert = JRequest::getCmd('expert');
		$cert   = JRequest::getCmd('cert');		
		$log    = $ctl_user->username."|".$_SERVER['REMOTE_ADDR']."|".date('Y-m-d H:i:s')."|UPDATE";
		
		$data = new stdClass();
		$data->e_pkeys = JRequest::getCmd('exp');
		$data->s_pkeys = JRequest::getCmd('school');
		$data->e_ename = substr(strtoupper(JRequest::getVar('ename')),0,250);
		$data->e_expet = ucwords(JRequest::getVar('expert'));
		$data->e_ecert = JRequest::getVar('cert');
		$data->e_phone = substr(JRequest::getVar('phone'),0,150);
		$data->e_email = substr(JRequest::getVar('email'),0,200);
		$data->e_elogs = $log;
		$db = JFactory::getDBO();
		if($db->updateObject('myexp_expert',$data,'e_pkeys')) {
			echo JText::_( '<span style=color:green>Record Updated.</span>' );
			echo "<div><button onclick=\"history.go(-2);\">Return</button></div>";
			view_input_form();
		}else{
			echo JText::_('<span style=color:red>Update Failed.</span>');
		}
	}elseif(JRequest::getCmd('task')=='delete'){
	  $sqls ="select * from myexp_expert where e_pkeys='".JRequest::getCmd('e')."'";
    $dbs = & JFactory::getDBO();
    $dbs->setQuery($sqls);
    $res = $dbs->loadAssocList($sqls);
    if(count($res)>0){
	   $sql = "delete from myexp_expert where e_pkeys='".JRequest::getCmd('e')."'";
	   $db = &JFactory::getDBO();
	   $db->setQuery($sql);
	   if($db->query()){
	     echo "<p>";
	     echo "<div style=\"color:green;\">Record Deleted.</div>";
	     echo "<div><button onclick=\"history.go(-1);\">Return</button></div>";
	     echo "</p>";
	   }else{
	     echo "<div style=\"color:red;\">Delete Failed.</div>";
	   }
    }else{
      echo "Process Failed. Data not exist !";
    }
	}else{
	  view_input_form();
	}
}

function view_input_form()
{
 //$returnbtn = "<button onclick=\"window.location.href='".JRoute::_('index.php?option=com_expertise')."';\">Return</button>";
  $sqls ="select * from myexp_expert where e_pkeys='".JRequest::getCmd('exp')."'";
  $dbs = & JFactory::getDBO();
  $dbs->setQuery($sqls);
  $res = $dbs->loadAssocList($sqls);
  
  foreach($res as $record) {
  	$nama = $record['e_ename'];
  	$cert = $record['e_ecert'];
  	$expt = $record['e_expet'];
  	$eid  = $record['e_pkeys'];
  	$pid  = $record['s_pkeys'];
  	$phone = $record['e_phone'];
  	$email = $record['e_email'];
  }
  	
  $sql = "select * from myexp_school";
  $db =& JFactory::getDBO();
  $db->setQuery($sql);
  $result = $db->loadAssoclist();
?>
<div class="rt-joomla">
<div class="edit-article">

<form method="post" name="" action="">
<input type="hidden" name="id" value="<?php echo JRequest::getCmd('exp'); ?>">
<fieldset><legend>Edit Expertise</legend>
<br>
<table class="adminform">
<tr>
  <td><label for="title">School :</label></td>
  <td>
    <select name="school" class="inputbox">
      <?php
      $sql = "select * from myexp_school order by s_sname asc";
      $db =& JFactory::getDBO();
      $db->setQuery($sql);
      $result = $db->loadAssoclist();
      foreach($result as $row)
      {
        echo "<option value=\"".$row['s_pkeys']."\">".$row['s_sname']."</option>";
      }
      ?>
      </select>
     </td>
 </tr>
 <tr>
  <td><label for="title">Name :</label></td>
  <td><input type="text" name="ename" id="ename" size="60" maxlength="250" class="inputbox" value="<?php echo $nama; ?>"/></td>
 </tr>
 <tr>
  <td><label for="title">Phone :</label></td>
  <td><input type="text" name="phone" id="phone" size="60" maxlength="150" class="inputbox" value="<?php echo $phone; ?>"/><small>e.g: 010-5555555</small></td>
 </tr>
 <tr>
  <td><label for="title">E-mail :</label></td>
  <td><input type="text" name="email" id="email" size="60" maxlength="250" class="inputbox" value="<?php echo $email; ?>"/><small>e.g: someone@world.net</small></td>
 </tr>
 <tr>
  <td><label>Certificates :</label></td>
  <td><textarea name="cert" id="cert" cols="60" rows="5" class="inputbox"><?php echo $cert; ?></textarea><small>Spit each certificates with ","</small></td>
 </tr>
 <tr>
  <td><label>Expertise :</label></td>
  <td><textarea name="expert" cols="60" rows="5" class="inputbox"><?php echo $expt; ?></textarea><small>Spit each certificates with ","</small></td>
 </tr>
 <tr>
  <td colspan="3">
  <input type="submit" class="button" name="submit_form" id="submit_form" value="Update Record">&nbsp;
  <input type="button" class="button" name="cancel_form" id="cancel_form" value="Cancel" onclick="history.go(-1);">
  <input type="button" class="button" name="return_form" id="return_form" value="Return" onclick="window.location.href='<?php echo JRoute::_('index.php?option=com_expertise'); ?>'">
  </td>
 </tr>
</table>
</fieldset>
</form>
</div>
</div>
<?php
}
?>