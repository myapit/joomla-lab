<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
$var_search = JRequest::getString('search_expertise');
$db = & JFactory::getDBO();

$ctl_user    = JFactory::getUser();
$ctl_type    = $ctl_user->usertype;
$var_userid  = $ctl_user->id;
$sqls = "select * from myexp_eusers where u_users='$var_userid' and u_satus='1'";
$dbs =& JFactory::getDBO();
$dbs->setQuery($sql);
$results = $dbs->loadAssocList();

if($var_search){
  $sql = "SELECT * FROM myexp_expert WHERE 
					e_ename LIKE '%$var_search%' OR
					e_ecert LIKE '%$var_search%' OR
					e_expet LIKE '%$var_search%' ORDER BY s_pkeys ASC";

  $db->setQuery($sql);
  $res = $db->loadAssocList();
	echo "<div>Search Keyword <strong>$var_search</strong> Total: <strong>".count($res)."</strong> results found.</div>";
	echo "<h5>Search Result</h5>";
	echo "<button onclick=\"window.location.href='".JRoute::_('index.php?option=com_expertise')."';\">
				Return</button>";

  if(count($res)=='0'){
    /**/
		echo "<table cellpadding=2 cellspacing=2 width=100% border=0>";
		echo "<tr><th>#</th><th>Name</th><th>Expertise</th></tr>";
		echo "<tr><td colspan=3 style='border-bottom:solid 1px #000'>&nbsp;</td></tr>";
		echo "<tr><td colspan=3> - No Record(s) Found- </td></tr>";
		echo "</tr>";
		echo "</table>";
		/**/
  }else{
		/*$school = get_school($var_search);
    if($school){
			foreach($school as $ro){
				echo "<h3>".$ro['s_sname']."</h3>";
			}
		}*/
		$tmpdata = "";
		echo "<table cellpadding=2 cellspacing=2 width=100% border=0>";
		echo "<tr><th>#</th><th>Name</th><th>Expertise</th></tr>";
		//echo "<tr><td colspan=3 style='border-bottom:solid 1px #000; height:10px;'>&nbsp;</td></tr>";
		$cc = 0;
		foreach($res as $row){
			$id = $row['s_pkeys'];
			$school = get_school($id);
			if(count($school)>0){
				foreach($school as $ro) {					
					if($tmpdata == "" || $tmpdata != $id) {
						$tmpdata = $id;
						echo "<tr><td colspan=3 style='text-align:center;background-color:#000;color:#fff;font-weight:bold;'>".$ro['s_sname']."</td></tr>";
					}//elseif($tmpdata == $id){
					
					//echo "<h3></h3>";
				}
			}else{
				//echo "<tr><td colspan=3 style='border-bottom:solid 1px #000'>xxx</td></tr>"; 
			}
      echo "<tr>";
			echo "<td valign=top width=3%>".++$cc."</td>";
			echo "<td valign=top><strong>".$row['e_ename']."</strong><br>".$row['e_ecert']."";
		  if($row['e_phone']!=null || $row['e_phone']!=''){
        echo "<br>Phone : ".$row['e_phone'];
      }
      if($row['e_email']!=null || $row['e_email']!=''){
        echo "<br>E-mail : <a href='mailto:".$row['e_email'].">".$row['e_email']."</a>";
      }
		  if(count($results)>0 || $ctl_user->usertype == "Super Administrator") {
				$edit = JRoute::_('index.php?option=com_expertise&task=edit&exp='.$row['e_pkeys']);
				echo "<br>&raquo;<a href=\"".$edit."\">Edit Record</a>";
				$edit = JRoute::_('index.php?option=com_expertise&task=delete&e='.$row['e_pkeys']);
        echo "<br>&raquo;<a href=\"".$edit."\" onclick=\"return confirm('Are you sure to delete this record ?\\nThis will permanently delete record.');\">Delete Record</a>";
			}
			echo "</td>";
			echo "<td valign=top>".$row['e_expet']."</td>";
			echo "</tr>";
			
			echo "<tr><td colspan=3 style='border-bottom:solid 1px #000'>&nbsp;</td></tr>";
    }
		//echo "<tr><td colspan=3 style='border-bottom:solid 1px #000'>&nbsp;</td></tr>";
		echo "</table>";
  }
}
/*****/


function search_form(){
  echo "<hr>";
  echo '<form method="get" action="">
  <label>Search Expertise</label>
  <input type="text" name="search_expertise" id="search_expertise" size="40"/>
  <input type="submit" id="btn_expertise" name="btn_expertise" value="Search" />
  </form>
  ';
}

function get_school($id=''){
  $sql1 = "select * from myexp_school";
  $sql2 = "select * from myexp_school where s_pkeys='$id'";
  ($id=='')?$key=$sql1:$key=$sql2;
  $db = &JFactory::getDBO();
  $db->setQuery($key);  
  return $db->loadAssocList();
}

function search_result($search_text){
  $sql = "select * from myexp_expert where e_ename like '%".$search_text."%' 
  		OR e_expert like '%".$search_text."%' 
  		OR e_ecert like '%".$search_text."%' GROUP BY s_pkeys";
  $db = &Jfactory::getDBO();
  $db->setQuery($sql);
  return $db->loadObjectList();
}


# process search after submit
/*
if(JRequest::getCmd('search_expertise') ==''){
  $res = search_result(JRequest::getVar('search_expertise'));
  if(count($res)!=0){
    foreach($res as $row){
      echo $row['e_name'].$row['e_expert'].$row['e_ecert'];
      echo "<br>";
    }
  }else{
    echo "no data found";   
  }
}//end
*/
?>