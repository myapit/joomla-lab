drop table `myexp_school`;
drop table `myexp_expert`;
drop table `myexp_eusers`;

