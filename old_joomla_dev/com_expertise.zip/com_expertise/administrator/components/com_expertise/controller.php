<?php
/**
 * Joomla! 1.5 component expertise
 *
 * @version $Id: controller.php 2010-08-03 01:06:00 svn $
 * @author hafeez
 * @package Joomla
 * @subpackage expertise
 * @license Copyright (c) 2010 - All Rights Reserved
 *
 * Directory of Expertise :: USM
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.controller' );
require_once( JPATH_COMPONENT.DS.'helpers'.DS.'helper.php' );

/**
 * expertise Controller
 *
 * @package Joomla
 * @subpackage expertise
 */
class ExpertiseController extends JController {
    /**
     * Constructor
     * @access private
     * @subpackage expertise
     */
    function __construct() {
        //Get View
        if(JRequest::getCmd('view') == '') {
            JRequest::setVar('view', 'default');
        }
        $this->item_type = 'Default';
        parent::__construct();
    }
}
?>