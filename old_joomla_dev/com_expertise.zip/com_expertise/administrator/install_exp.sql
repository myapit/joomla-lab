CREATE TABLE IF NOT EXISTS `myexp_school` (
`s_pkeys` VARCHAR(32) NOT NULL ,
`s_sname` VARCHAR(255) NOT NULL ,
`s_slogs` TEXT NOT NULL ,
PRIMARY KEY ( `s_pkeys`)
)ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('771d70a4f2571de5b45e39b62fdd2c8d','ADVANCED MEDICAL AND DENTAL INSTITUTE','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('4f80d9ed33f8d695df188e40c7c93153','CENTRE FOR ARCHAEOLOGICAL RESEARCH MALAYSIA','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('68c5309c091502d2ae38085674dbe5bb','CENTRE FOR DRUG RESEARCH','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('77e710046bea94892e1a92d67f6a970b','CENTRE FOR INSTRUCTIONAL TECHNOLOGY AND MULTIMEDIA','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('87430f074074e7112dec658760c08399','CENTRE FOR MARINE AND COASTAL STUDIES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('fe4025e5ca94e0c13a7a564e880723a0','CENTRE FOR POLICY RESEARCH','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('f570ba44e570c36894ba7609b38f8559','COLLABORATIVE MICROELECTRONIC DESIGN EXCELLENCE CENTRE','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('eb24b9ebf76ec47b526758099bb0a2bb','DOPING CONTROL CENTRE','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('d9a04a1692ab719098ee5ea0c318d932','INSTITUTE FOR RESEARCH IN MOLECULAR MEDICINE','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('0134ec858b1854653261ec966031433b','NATIONAL POISON CENTRE','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('3e7e6699f1a730d5c97b6ae6c9e13152','RIVER ENGINEERING AND URBAN DRAINAGE RESEARCH CENTRE','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('b224b89f0219d7b60f3c751f18d5c10a','SCHOOL OF AEROSPACE ENGINEERING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('816afaa9cc36a0f3c7c48cf602135d6a','SCHOOL OF ARTS','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('f19ba7b3f40dc4efb5e33a7f68c38c4d','SCHOOL OF BIOLOGICAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('274af5ddc683af1feeec539d84c770f0','SCHOOL OF CHEMICAL ENGINEERING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('be89d031883c823a29fb3b711bd9e4e2','SCHOOL OF CHEMICAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('45316b30f2bc18a7a36d3ddc855075bd','SCHOOL OF CIVIL ENGINEERING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('b5d595f34cb2678050fcfb0a553d2ffb','SCHOOL OF COMMUNICATION','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('e3ca5e057d8a1d9f0ebdb31571d7aca8','SCHOOL OF COMPUTER SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('85909ada8965e2caa436ada8809736ff','SCHOOL OF DENTAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('70bd3bafbb6ab36762921aa83392e1a4','SCHOOL OF DISTANCE EDUCATION','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('2b100b1c5a6212aed1c36fbf6906bf67','SCHOOL OF EDUCATIONAL STUDIES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('ce027d4b1bba05fad3a44feb2d7f2032','SCHOOL OF ELECTRICAL AND ELECTRONIC ENGINEERING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('f5853bd4260395b394d9020b849a349c','SCHOOL OF HEALTH SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('e1a03a78c4439b93bfafd205a941e4e3','SCHOOL OF HOUSING, BUILDING AND PLANNING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('4d4c3b924e98c53dca6f62e5fc828393','SCHOOL OF HUMANITIES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('0adffdd5c427c4f535a4aa57b99e0ced','SCHOOL OF INDUSTRIAL TECHNOLOGY','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('d6047835186663ab09c1c020c27d4315','SCHOOL OF LANGUAGES, LITERACIES AND TRANSLATION','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('af1430b70ba22ccbaefa2dd38fdf56c4','SCHOOL OF MANAGEMENT','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('7b754f9d592ad85c232adb6366514309','SCHOOL OF MATERIALS AND MINERAL RESOURCES ENGINEERING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('4a24ee4e4c0ac519ff094780359b1e70','SCHOOL OF MATHEMATICAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('372b1e7a56667925159195a416f809bc','SCHOOL OF MECHANICAL ENGINEERING','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('0dc10113c79fc7485c9d0cf38ecaafff','SCHOOL OF MEDICAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('dbfe258af9b26e81f64a1ee3b3002703','SCHOOL OF PHARMACEUTICAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('5683d7c1548d8ad200ecfc76a082c982','SCHOOL OF PHYSICS','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('6948d617b4c0c8fa63033cd02ba272c6','SCHOOL OF SOCIAL SCIENCES','INSTALLER');
INSERT INTO myexp_school(s_pkeys,s_sname,s_slogs)
values('c5bb4dae5dffae1aff88cb7b5d630970','WOMEN DEVELOPMENT RESEARCH CENTRE','INSTALLER');


CREATE TABLE IF NOT EXISTS  `myexp_expert` (
`e_pkeys` VARCHAR(32) NOT NULL ,
`s_pkeys` VARCHAR(32) NOT NULL ,
`e_ename` VARCHAR(255) NOT NULL ,
`e_ecert` TEXT NOT NULL ,
`e_expet` TEXT NOT NULL ,
`e_phone` VARCHAR(150) NULL,
`e_email` VARCHAR(150) NULL,
`e_elogs` TEXT NOT NULL ,
PRIMARY KEY ( `e_pkeys`)
)ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `myexp_eusers` (
`u_users` VARCHAR(32) NOT NULL ,
`u_satus` VARCHAR(32) NOT NULL
)ENGINE=MyISAM DEFAULT CHARSET=latin1;

