<?php
/**
 * Joomla! 1.5 component Direktori Kepakaran
 *
 * @version $Id: view.html.php 2012-04-01 21:21:15 svn $
 * @author mhafeez
 * @package Joomla
 * @subpackage Direktori Kepakaran
 * @license GNU/GPL
 *
 * Direktori Kepakaran WEB USM PROTOTYPE
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport( 'joomla.application.component.view');
class DirektorikepakaranViewDefault extends JView {
    function display($tpl = null) {
        parent::display($tpl);
    }
}
?>