<?php
/**
 * Joomla! 1.5 component Direktori Kepakaran
 *
 * @version $Id: direktorikepakaran.php 2012-04-01 21:21:15 svn $
 * @author mhafeez
 * @package Joomla
 * @subpackage Direktori Kepakaran
 * @license GNU/GPL
 *
 * Direktori Kepakaran WEB USM PROTOTYPE
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';

// Initialize the controller
$controller = new DirektorikepakaranController();
$controller->execute( null );

// Redirect if set by the controller
$controller->redirect();
?>